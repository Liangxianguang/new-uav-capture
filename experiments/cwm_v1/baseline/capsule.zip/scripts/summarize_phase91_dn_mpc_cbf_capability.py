"""Summarize a completed capability run without rerunning any scene."""
import argparse
import collections
import json
from pathlib import Path
import numpy as np

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('output', type=Path)
args = parser.parse_args()
root = args.output.resolve()
progress = json.loads((root / 'progress.json').read_text())
assert progress['complete'], 'Evaluation is still running'
rows = [json.loads(line) for line in (root / 'episodes.jsonl').read_text().splitlines()]
assert len(rows) == progress['total']
assert len({(r['level'], r['episode_index']) for r in rows}) == len(rows)
stats = {level: {'latencies': [], 'cbf_intervention_steps': 0, 'control_steps': 0} for level in [5, 6]}
with (root / 'steps.jsonl').open() as handle:
    for line in handle:
        step = json.loads(line)
        s = stats[step['level']]
        s['latencies'].append(step['total_control_latency_ms'])
        s['cbf_intervention_steps'] += step['cbf_action_correction_norm'] > 1e-6
        s['control_steps'] += 1
details = {}
for level in [5, 6]:
    subset = [r for r in rows if r['level'] == level]
    stats_level = stats[level]
    successes = [r['capture_time_seconds'] for r in subset if r['safe_capture_success']]
    details[str(level)] = {
        **progress['levels'][str(level)],
        'termination_counts': dict(collections.Counter(r['termination_reason'] for r in subset)),
        'control_latency_ms': {str(p): float(np.percentile(stats_level['latencies'], p)) for p in [50, 95, 99]},
        'mean_success_capture_seconds': float(np.mean(successes)) if successes else None,
        'cbf_intervention_step_fraction': stats_level['cbf_intervention_steps'] / stats_level['control_steps'],
        'planner_fallback_steps': sum(r['planner_fallback_count'] for r in subset),
        'candidate_budget_mismatch_steps': sum(r['candidate_budget_mismatch_steps'] for r in subset),
        'failure_episode_indices': [r['episode_index'] for r in subset if not r['safe_capture_success']],
        'physical_outcome_rates_finite': all(np.isfinite(value) for key, value in progress['levels'][str(level)].items() if key.endswith('_rate')),
    }
(root / 'analysis.json').write_text(json.dumps(details, indent=2))
lines = [
    '# DN-MPC + local CBF 实测能力（2026-10-05）', '',
    '版本：本机保留的 Phase2 GRU seed745101 + Phase4 distributed_delayed DN-MPC + local CBF。不是缺失权重的 Phase16 GRU-both 复测。', '',
    '固定开发验证场景：Level5 和 Level6 各128场；250步上限，dt=0.1秒，捕获半径0.8米，双方边界余量0.3米。未使用 locked-test。', '',
    '| 难度 | 场数 | 安全捕获 | 碰撞 | 防守方越界 | 超时 | 目标无效/越界/障碍违规 |',
    '|---|---:|---:|---:|---:|---:|---|',
]
for level in [5, 6]:
    s = details[str(level)]
    pct = lambda k: f"{100 * s[k]:.2f}%"
    lines.append(f"| Level{level} | {s['episodes']} | {pct('safe_capture_success_rate')} | {pct('collision_rate')} | {pct('boundary_violation_rate')} | {pct('timeout_rate')} | {pct('target_invalid_episode_rate')}/{pct('target_boundary_violation_rate')}/{pct('target_obstacle_violation_rate')} |")
lines += ['', '## 控制和场景参数', '']
for level in [5, 6]:
    s = details[str(level)]
    lines.append(f"- Level{level}：成功场景平均捕获用时 {s['mean_success_capture_seconds']:.2f} 秒；控制耗时 p50/p95/p99 为 {s['control_latency_ms']['50']:.2f}/{s['control_latency_ms']['95']:.2f}/{s['control_latency_ms']['99']:.2f} 毫秒；CBF 修改动作的步占比 {100*s['cbf_intervention_step_fraction']:.2f}%；planner fallback {s['planner_fallback_steps']} 步。")
lines += [
    '', '- Level5：3个障碍，速度系数0.45。Level6：4–5个障碍，速度系数0.5–0.6，包含观测/执行扰动。早期原配置速度系数0.55。',
    '- 预测器采用自己的原始252维输入、最近3个障碍槽；物理障碍仍全部保留，规划器和CBF仍读取原场景障碍。这与RL的5槽编码不同。',
    '- DN-MPC保持原Phase4参数：4轮局部迭代、2步消息延迟、8步规划时域；预测每步刷新，GRU K=1。CBF安全余量恢复为原配置0.35米；物理任务的双方边界余量保持0.3米。',
    '- 每个难度只有一个固定窗口、一个预测器训练种子。本结果用于能力诊断，不能据此宣布所有难度泛化、正式多种子胜出，或两窗口训练晋级通过。',
    '- 耗时在两个CUDA训练同时运行的机器上测得，属于CPU实测，不能直接作为与GPU RL推理的等硬件延迟比较。',
    '', '## 复现文件', '',
    '`manifest.json`保存权重、代码、环境和规划配置；`scenes.jsonl`保存冻结场景；`episodes.jsonl`保存逐场结果；`steps.jsonl`保存逐步诊断；`trajectories/`保存轨迹；`analysis.json`保存统计。',
]
(root / 'REPORT.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(json.dumps(details, indent=2))
