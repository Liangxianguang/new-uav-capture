"""Development capability audit of retained Phase2 GRU + delayed DN-MPC + local CBF.

Uses frozen Phase91 records and physical environment, and the predictor's own
original 252-column encoder contract. This is NOT a Phase16 GRU-both replication.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import sys
import time
from pathlib import Path
import numpy as np
import torch
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
sys.path.insert(0, str(ROOT / 'scripts'))
import evaluate_minimax_mpc as evaluator
from evaluate_rule_teacher_phase87 import load_environment
from encirclement3d.observation_encoding import policy_observations
from encirclement3d.showcase import scenario_from_metadata
from encirclement3d.distributed_dn_mpc import DistributedDNMPCConfig
from encirclement3d.minimax_mpc import MinimaxMPCConfig


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--episodes-per-stage', type=int, default=128)
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    checkpoint = ROOT / 'models/formal_phase2_v3/gru_baseline_seed745101.pt'
    frozen_manifest = json.loads((checkpoint.parent / 'manifest.json').read_text())
    expected = next(item['sha256'] for item in frozen_manifest['artifacts'] if item['file'] == checkpoint.name)
    assert sha(checkpoint) == expected, 'Frozen predictor hash mismatch'
    config_path = ROOT / 'configs/phase91_mappo_pursuit_first_v9.yaml'
    scenes = ROOT / 'results/phase91_zero_cbf_curriculum_v5/validation/scenes.jsonl'
    planner_path = ROOT / 'configs/phase4_dn_mpc.yaml'
    environment = load_environment(config_path)
    original = yaml.safe_load((ROOT / 'configs/capture_radius_pursuit_central_v4_flee.yaml').read_text())
    mpc = yaml.safe_load(planner_path.read_text())
    selected = []
    for level, variant in [(5, 'mixed_three_evasive'), (6, 'dense_mixed')]:
        records = [json.loads(line) for line in scenes.read_text().splitlines() if line.strip()]
        records = sorted([r for r in records if r['variant'] == variant], key=lambda r: (r['mirror_group_id'], r['mirror_pair_member']))
        assert len(records) >= args.episodes_per_stage
        chosen = records[:args.episodes_per_stage]
        assert args.episodes_per_stage % 2 == 0
        groups = {}
        for record in chosen:
            assert 'development' in record['scene_block']
            groups.setdefault(record['mirror_group_id'], []).append(record)
            selected.append({'level': level, **record})
        # L5's fixed development pool contains singleton scene IDs; L6 is paired.
        if level == 6:
            assert all(len(group) == 2 for group in groups.values()), 'Incomplete mirror pairs'
    (output / 'scenes.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in selected))
    model = evaluator.model_from_checkpoint(checkpoint, torch.device('cpu'))
    # Encode with original feature order and nearest-three obstacle slots,
    # without removing any physical obstacle or altering the planner inputs.
    def predictor_encoder(env, observation=None):
        saved = {key: env.pursuit[key] for key in ['max_observation_obstacles', 'include_uncertainty_features', 'include_prediction_features']}
        saved_task = dict(env.task)
        try:
            for key in saved:
                env.pursuit[key] = original['task']['pursuit'][key]
            env.task.update(policy_obstacle_geometry=original['task']['policy_obstacle_geometry'], policy_clearance_features=False, policy_role_slot_features=False, policy_route_intent_features=False)
            features = policy_observations(env, observation)
            assert features.size == model[3]['model_config']['input_dim'] == 252
            return features
        finally:
            env.pursuit.update(saved)
            env.task.clear()
            env.task.update(saved_task)
    evaluator.policy_observations = predictor_encoder
    # Preserve the original controller parameter while retaining the matched
    # physical environment and its 0.3m boundary outcome definition.
    original_filter_class = evaluator.PursuitCBFSafetyFilter
    class OriginalMarginFilter(original_filter_class):
        def __init__(self, env, *a, **kw):
            super().__init__(env, *a, **kw)
            self.margin = float(original['task']['pursuit']['safety_margin'])
    evaluator.PursuitCBFSafetyFilter = OriginalMarginFilter
    base_env_class = evaluator.CaptureRadiusPursuit3DEnv
    last_info = {}
    class AuditEnv(base_env_class):
        def step(self, *a, **kw):
            result = super().step(*a, **kw)
            last_info.clear()
            last_info.update(result[-1])
            return result
    evaluator.CaptureRadiusPursuit3DEnv = AuditEnv
    distributed = DistributedDNMPCConfig.from_mapping({**mpc['distributed'], 'communication_mode': 'delayed'})
    manifest = {
        'algorithm': 'phase2_gru_seed745101_distributed_delayed_dn_mpc_local_cbf',
        'phase16_replication': False, 'locked_test_used': False,
        'checkpoint_sha256': expected, 'predictor_input_dim': 252,
        'cbf_safety_margin_m': float(original['task']['pursuit']['safety_margin']),
        'predictor_encoder': 'original shape-aware nearest-three obstacle slots; uncertainty on; prediction/clearance/role/route features off',
        'physical_obstacles_unchanged': True, 'episodes_per_stage': args.episodes_per_stage,
        'prediction_refresh_interval_steps': 1, 'num_samples': 1, 'sampling_steps': 8,
        'distributed': distributed.__dict__, 'environment': environment,
        'planner': mpc['planner'], 'sha256': {str(p.relative_to(ROOT)): sha(p) for p in [checkpoint, config_path, scenes, planner_path, ROOT / 'src/encirclement3d/pursuit_env.py', ROOT / 'src/encirclement3d/distributed_dn_mpc.py', ROOT / 'src/encirclement3d/pursuit_controllers.py', Path(__file__), ROOT / 'scripts/evaluate_minimax_mpc.py']},
    }
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    rows = []
    started = time.time()
    with (output / 'episodes.jsonl').open('w') as episode_file, (output / 'steps.jsonl').open('w') as step_file:
        for index, record in enumerate(selected):
            config = copy.deepcopy(environment)
            config['task']['pursuit'].update(copy.deepcopy(record['pursuit_overrides']))
            config['task']['pursuit']['target_motion_mode'] = record['target_motion_mode']
            execution = copy.deepcopy(record['execution'])
            if 'command_noise_std_mps' in execution:
                execution['command_noise_std'] = execution.pop('command_noise_std_mps')
            config.setdefault('dynamics', {}).setdefault('execution', {}).update(execution)
            config['world']['max_steps'] = 250
            config['experiments'] = [{'obstacle_count': record['obstacle_count'], 'target_speed_scale': record['target_speed_scale']}]
            assert config['task']['pursuit']['capture_radius'] == 0.8
            assert config['task']['pursuit']['defender_boundary_margin'] == 0.3
            assert config['task']['pursuit']['target_boundary_margin'] == 0.3
            row, steps = evaluator.run_episode(config, seed=record['episode_seed'], method='distributed_delayed', planner_config=MinimaxMPCConfig.from_mapping(mpc['planner']), candidate_source='checkpoint', checkpoint_data=model, device=torch.device('cpu'), num_samples=1, sampling_steps=8, sampling_seed=745102 + record['episode_index'] * 1000, projection_iterations=4, use_local_cbf=True, safety_layer='local_cbf', prediction_refresh_interval_steps=1, distributed_config=distributed, scenario=scenario_from_metadata(record['scenario']), validate_scenario=False, record_history=True, trajectory_path=output / 'trajectories' / f"level{record['level']}_{record['episode_index']}.npz")
            row.update(level=record['level'], episode_index=record['episode_index'], mirror_group_id=record['mirror_group_id'], mirror_pair_member=record['mirror_pair_member'], boundary_violation=bool(last_info.get('defender_boundary_violation', False)))
            rows.append(row)
            episode_file.write(json.dumps(row) + '\n')
            episode_file.flush()
            for step in steps:
                step_file.write(json.dumps({'level': record['level'], 'episode_index': record['episode_index'], **step}) + '\n')
            step_file.flush()
            summaries = {}
            for level in [5, 6]:
                subset = [r for r in rows if r['level'] == level]
                if subset:
                    keys = ['safe_capture_success', 'capture_event', 'collision', 'boundary_violation', 'timeout', 'target_invalid_episode', 'target_boundary_violation', 'target_obstacle_violation']
                    summaries[str(level)] = {'episodes': len(subset), **{key + '_rate': float(np.mean([r[key] for r in subset])) for key in keys}, 'mean_total_control_latency_ms': float(np.mean([r['mean_total_control_latency_ms'] for r in subset]))}
            progress = {'completed': len(rows), 'total': len(selected), 'elapsed_seconds': time.time() - started, 'complete': len(rows) == len(selected), 'levels': summaries}
            (output / 'progress.json').write_text(json.dumps(progress, indent=2))
            print(json.dumps(progress), flush=True)
            del steps
    (output / 'summary.json').write_text(json.dumps(progress, indent=2))


if __name__ == '__main__':
    main()
