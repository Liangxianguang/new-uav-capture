"""V8 pursuit actor with risk-gated, bounded teammate correction.

This is an experimental architecture, not a collision guarantee or a CBF.
The V7 policy and observation contract remain unchanged.
"""
from __future__ import annotations

import math
import torch
from torch import nn
from torch.distributions import Normal
from .learning import RecurrentCentralizedSharedActorCritic
from .pursuit_env import pursuit_settings


class PursuitFirstActorCritic(RecurrentCentralizedSharedActorCritic):
    architecture = "pursuit_first_bounded_team_v8"

    def configure(self, environment: dict, settings: dict) -> None:
        pursuit = pursuit_settings(environment['task'])
        self.team_start = (11 + 4 * int(pursuit['include_uncertainty_features'])
                           + 4 * int(pursuit['include_prediction_features']))
        self.extent = float(environment['world']['half_extent_xy'])
        self.speed = float(environment['agents']['defender_max_speed'])
        self.drone_radius = float(environment['agents']['drone_radius'])
        self.correction_fraction = float(settings.get('team_correction_fraction', 0.25))
        self.warning_distance = float(settings.get('team_warning_distance_m', 3.0))
        self.lookahead = float(settings.get('team_lookahead_seconds', 1.0))
        self.smoothness_coef = float(settings.get('action_smoothness_coef', 0.05))
        self.has_team_clearance = bool(environment['task'].get('policy_clearance_features', False))
        if not 0 < self.correction_fraction < 1:
            raise ValueError('team_correction_fraction must be between zero and one')
        if self.warning_distance <= 2*self.drone_radius or self.lookahead <= 0 or self.smoothness_coef < 0:
            raise ValueError('Invalid V8 collision-risk or smoothness settings')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.team_correction = nn.Sequential(nn.Linear(18, 64), nn.Tanh(), nn.Linear(64, 3))
        nn.init.zeros_(self.team_correction[-1].weight)
        nn.init.zeros_(self.team_correction[-1].bias)

    def _actor_step(self, local: torch.Tensor, hidden: torch.Tensor):
        # Keep target, obstacle and boundary inputs; teammates cannot drive
        # the pursuit branch or its recurrent state.
        main = local.clone()
        main[:, self.team_start:self.team_start+18] = 0
        if self.has_team_clearance:
            main[:, -1] = 0  # V7's appended nearest-teammate clearance.
        next_hidden = self.actor_gru(self.actor_gru_encoder(main), hidden)
        main_raw = self.actor_base_mean(self.actor_base_body(main)) + self.actor_residual_mean(next_hidden)
        team = local[:, self.team_start:self.team_start+18]
        relative_position = team[:, :9].reshape(-1, 3, 3) * self.extent
        relative_velocity = team[:, 9:].reshape(-1, 3, 3) * self.speed
        closest_time = (-(relative_position*relative_velocity).sum(-1)
                        / relative_velocity.square().sum(-1).clamp_min(1e-6)).clamp(0, self.lookahead)
        future_distance = (relative_position + closest_time[..., None]*relative_velocity).norm(dim=-1)
        gate = ((self.warning_distance-future_distance)
                / (self.warning_distance-2*self.drone_radius)).clamp(0, 1).amax(-1, keepdim=True)
        correction = torch.tanh(self.team_correction(team))
        correction = correction / correction.norm(dim=-1, keepdim=True).clamp_min(1)
        normalized = (torch.tanh(main_raw) + self.correction_fraction*gate*correction).clamp(-0.999999, 0.999999)
        return torch.atanh(normalized), next_hidden

    def distribution_step(self, local_observations, hidden_state, reset_mask=None):
        if local_observations.ndim != 2 or local_observations.shape[-1] != self.local_observation_dim:
            raise ValueError('Invalid V8 observation dimensions')
        if hidden_state is None:
            hidden_state = self.initial_actor_hidden(local_observations.shape[0], device=local_observations.device)
        if reset_mask is not None:
            mask = torch.as_tensor(reset_mask, device=hidden_state.device, dtype=hidden_state.dtype)
            hidden_state = hidden_state * (1-mask[..., None] if mask.ndim else 1-mask)
        mean, hidden = self._actor_step(local_observations, hidden_state)
        return Normal(mean, self.log_std.exp().expand_as(mean)), hidden

    def evaluate_actions_sequence(self, local_observations, initial_hidden, reset_masks,
                                  scaled_actions, action_scale, pre_tanh_actions=None):
        batch, length, defenders, features = local_observations.shape
        if features != self.local_observation_dim or initial_hidden.shape != (batch, defenders, self.hidden_dim):
            raise ValueError('Invalid V8 sequence dimensions')
        # Match rollout's four-agent matrix shape. Near the bounded actor's
        # atanh clamp, tiny CUDA GEMM differences from batching episodes can
        # become material differences in Gaussian log probabilities.
        if batch > 1:
            episodes = [self.evaluate_actions_sequence(
                local_observations[i:i+1], initial_hidden[i:i+1],
                reset_masks[i:i+1], scaled_actions[i:i+1], action_scale,
                pre_tanh_actions=None if pre_tanh_actions is None else pre_tanh_actions[i:i+1]
            ) for i in range(batch)]
            return tuple(torch.cat([episode[k] for episode in episodes], dim=0) for k in range(3))
        hidden = initial_hidden
        logps, entropies, means = [], [], []
        for index in range(length):
            hidden = hidden * (1-reset_masks[:, index, None, None])
            mean, next_hidden = self._actor_step(local_observations[:, index].reshape(-1, features),
                                                hidden.reshape(-1, self.hidden_dim))
            hidden = next_hidden.reshape(batch, defenders, self.hidden_dim)
            mean = mean.reshape(batch, defenders, self.action_dim)
            distribution = Normal(mean, self.log_std.exp().expand_as(mean))
            # Training passes original Gaussian samples, never inverse-tanh
            # reconstructed samples. Fallback is for legacy BC callers only.
            raw = (pre_tanh_actions[:, index] if pre_tanh_actions is not None else
                   torch.atanh((scaled_actions[:, index]/action_scale).clamp(-.999999, .999999)))
            logps.append(self._squashed_log_probability(distribution, raw).sum(-1))
            entropies.append(distribution.entropy().sum(-1))
            means.append(mean)
        return torch.stack(logps, 1), torch.stack(entropies, 1), torch.stack(means, 1)

    @staticmethod
    def _squashed_log_probability(distribution, raw_actions):
        # Numerically stable log(1-tanh(x)^2), including saturated samples.
        correction = 2*(math.log(2)-raw_actions-torch.nn.functional.softplus(-2*raw_actions))
        return distribution.log_prob(raw_actions)-correction

    def actor_parameters(self):
        return super().actor_parameters() + list(self.team_correction.parameters())

    def migrate_v7(self, state_dict):
        result = self.load_state_dict(state_dict, strict=False)
        expected = {'team_correction.0.weight', 'team_correction.0.bias',
                    'team_correction.2.weight', 'team_correction.2.bias'}
        if set(result.missing_keys) != expected or result.unexpected_keys:
            raise ValueError(f'Incompatible source checkpoint: {result}')
        # Main input masking changes behavior intentionally. Do not restore
        # old optimizer moments or old curriculum gate passes.
        return sorted(result.missing_keys)
