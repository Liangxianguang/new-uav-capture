"""Independent IPPO repair: predictive reward and boundary-aware role features."""
import numpy as np
from .pursuit_env import CaptureRadiusPursuit3DEnv, TETRAHEDRON_DIRECTIONS
from .observation_encoding import policy_observations as original_observations

def slots(env, observation):
    beliefs=np.asarray(observation['target_belief_positions'],dtype=np.float64)
    offsets=np.zeros((4,3)); offsets[1:]=TETRAHEDRON_DIRECTIONS[1:]*1.25
    erosion=float(env.agents['drone_radius'])+float(env.pursuit['defender_boundary_margin'])
    return np.clip(beliefs+offsets,env.lower+erosion+0.5,env.upper-erosion-0.5)

def policy_observations(env, observation=None, *, route_helper=None):
    obs=env.observe() if observation is None else observation
    base=original_observations(env,obs,route_helper=route_helper)
    delta=(slots(env,obs)-np.asarray(obs['defender_positions']))/float(env.world['half_extent_xy'])
    return np.concatenate([base,delta,np.eye(4)],axis=1).astype(np.float32)

class RepairEnv(CaptureRadiusPursuit3DEnv):
    def step(self,*args,**kwargs):
        before=self.observe(); positions=self.defender_positions.copy(); velocities=self._clip_rows(np.asarray(args[0] if args else kwargs["defender_actions"],dtype=np.float64),float(self.agents["defender_max_speed"]))
        goal=slots(self,before)
        old_potential=-float(np.mean(np.minimum(np.linalg.norm(positions-goal,axis=1),16.0)))/16.0
        erosion=float(self.agents['drone_radius'])+float(self.pursuit['defender_boundary_margin'])
        boundary=team=obstacle=0.0
        # Sample the complete one-second velocity ray, including current state.
        for t in np.linspace(0.,1.,11):
            future=positions+t*velocities
            clearance=min(float(np.min(future-(self.lower+erosion))),float(np.min(self.upper-erosion-future)))
            boundary=max(boundary,float(np.clip((1.-clearance),0.,1.)))
            for i in range(4):
                for j in range(i):
                    c=float(np.linalg.norm(future[i]-future[j]))-2*float(self.agents['drone_radius'])
                    team=max(team,float(np.clip((1.-c),0.,1.)))
                for o in self.obstacles:
                    c=float(self._obstacle_clearance(future[i],o))-float(self.agents['drone_radius'])
                    obstacle=max(obstacle,float(np.clip(1.-c,0.,1.)))
        obs,reward,terminated,truncated,info=super().step(*args,**kwargs)
        new_potential=0. if terminated else -float(np.mean(np.minimum(np.linalg.norm(self.defender_positions-slots(self,obs),axis=1),16.0)))/16.0
        components={'predictive_boundary':-0.5*boundary,'predictive_team':-0.5*team,'predictive_obstacle':-0.5*obstacle,'role_progress':2.0*(0.99*new_potential-old_potential)}
        info['reward_components'].update(components)
        return obs,reward+sum(components.values()),terminated,truncated,info
