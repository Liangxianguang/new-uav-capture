"""Independent one-step safety certificate checks for the velocity benchmark.

The checker intentionally does not call the QP implementation.  It recomputes
the next state and all geometric margins from the public observation, so a
solver diagnostic cannot certify an action that violates the actual contract.
This is a one-step certificate under the supplied velocity-level assumptions,
not a learned CLBF or a real-flight guarantee.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

import numpy as np

from encirclement3d.execution_dynamics import (
    CommandAuthorityDirective,
    apply_command_authority,
    command_authority_directive,
    command_authority_from_observation,
    parameters_from_observation,
    reachable_tube_radii,
    queue_from_observation,
    rollout_execution,
    rollout_execution_with_action_jacobian,
)


def _unit(value: np.ndarray, fallback: np.ndarray | None = None) -> np.ndarray:
    vector = np.asarray(value, dtype=np.float64)
    norm = float(np.linalg.norm(vector))
    if norm > 1.0e-12:
        return vector / norm
    if fallback is not None:
        return np.asarray(fallback, dtype=np.float64).copy()
    return np.zeros_like(vector)


def _obstacle_geometry(obstacle: Any) -> tuple[str, np.ndarray, float, float, np.ndarray | None]:
    if isinstance(obstacle, Mapping):
        return (
            str(obstacle.get("shape", "cylinder")),
            np.asarray(obstacle["center_xy"], dtype=np.float64),
            float(obstacle.get("radius", 0.0)),
            float(obstacle["height"]),
            None if obstacle.get("half_extents_xy") is None else np.asarray(obstacle["half_extents_xy"], dtype=np.float64),
        )
    return (
        str(obstacle.shape),
        np.asarray(obstacle.center_xy, dtype=np.float64),
        float(obstacle.radius),
        float(obstacle.height),
        None if obstacle.half_extents_xy is None else np.asarray(obstacle.half_extents_xy, dtype=np.float64),
    )


def _signed_obstacle_clearance(position: np.ndarray, obstacle: Any) -> float:
    """Return signed distance to a finite cylinder or axis-aligned box."""

    point = np.asarray(position, dtype=np.float64)
    shape, center_xy, radius, height, half_extents_xy = _obstacle_geometry(obstacle)
    if shape == "cylinder":
        delta_xy = point[:2] - center_xy
        radial_gap = float(np.linalg.norm(delta_xy) - radius)
        if 0.0 <= point[2] <= height:
            return radial_gap
        nearest_z = 0.0 if point[2] < 0.0 else height
        vertical_gap = abs(float(point[2]) - nearest_z)
        if radial_gap <= 0.0:
            return vertical_gap
        return float(np.hypot(radial_gap, vertical_gap))

    if half_extents_xy is None:
        half_extents_xy = np.array([radius, radius], dtype=np.float64)
    center = np.array([center_xy[0], center_xy[1], 0.5 * height], dtype=np.float64)
    half = np.array([half_extents_xy[0], half_extents_xy[1], 0.5 * height], dtype=np.float64)
    signed_axes = np.abs(point - center) - half
    outside = np.maximum(signed_axes, 0.0)
    outside_norm = float(np.linalg.norm(outside))
    if outside_norm > 1.0e-12:
        return outside_norm
    return -float(np.min(-signed_axes))


def _signed_obstacle_clearance_and_gradient(position: np.ndarray, obstacle: Any) -> tuple[float, np.ndarray]:
    """Return signed obstacle clearance and one deterministic local gradient."""

    point = np.asarray(position, dtype=np.float64)
    shape, center_xy, radius, height, half_extents_xy = _obstacle_geometry(obstacle)
    if shape == "cylinder":
        delta_xy = point[:2] - center_xy
        radial_norm = float(np.linalg.norm(delta_xy))
        radial_gap = radial_norm - radius
        radial_gradient = _unit(
            np.array([delta_xy[0], delta_xy[1], 0.0], dtype=np.float64),
            fallback=np.array([1.0, 0.0, 0.0], dtype=np.float64),
        )
        if 0.0 <= point[2] <= height:
            return radial_gap, radial_gradient
        nearest_z = 0.0 if point[2] < 0.0 else height
        vertical_delta = float(point[2] - nearest_z)
        vertical_gap = abs(vertical_delta)
        vertical_gradient = np.array([0.0, 0.0, -1.0 if vertical_delta < 0.0 else 1.0], dtype=np.float64)
        if radial_gap <= 0.0:
            return vertical_gap, vertical_gradient
        distance = float(np.hypot(radial_gap, vertical_gap))
        if distance <= 1.0e-12:
            return 0.0, radial_gradient
        return distance, (radial_gap * radial_gradient + vertical_gap * vertical_gradient) / distance

    if half_extents_xy is None:
        half_extents_xy = np.array([radius, radius], dtype=np.float64)
    center = np.array([center_xy[0], center_xy[1], 0.5 * height], dtype=np.float64)
    half = np.array([half_extents_xy[0], half_extents_xy[1], 0.5 * height], dtype=np.float64)
    delta = point - center
    signed_axes = np.abs(delta) - half
    outside = np.maximum(signed_axes, 0.0)
    outside_norm = float(np.linalg.norm(outside))
    if outside_norm > 1.0e-12:
        gradient = (outside * np.sign(delta)) / outside_norm
        return outside_norm, gradient
    axis = int(np.argmax(signed_axes))
    gradient = np.zeros(3, dtype=np.float64)
    gradient[axis] = 1.0 if delta[axis] >= 0.0 else -1.0
    return -float(np.min(-signed_axes)), gradient


@dataclass(frozen=True)
class SafetyCertificateResult:
    """Auditable result of an independent one-step safety check."""

    valid: bool
    status: str
    current_state_safe: bool
    next_state_safe: bool
    current_min_barrier_m: float
    next_min_barrier_m: float
    maximum_action_norm_mps: float
    maximum_action_change_mps: float
    barrier_values_m: dict[str, float]
    violations: tuple[str, ...]
    assumptions: dict[str, float]

    def as_dict(self) -> dict[str, Any]:
        return {
            "valid": self.valid,
            "status": self.status,
            "current_state_safe": self.current_state_safe,
            "next_state_safe": self.next_state_safe,
            "current_min_barrier_m": self.current_min_barrier_m,
            "next_min_barrier_m": self.next_min_barrier_m,
            "maximum_action_norm_mps": self.maximum_action_norm_mps,
            "maximum_action_change_mps": self.maximum_action_change_mps,
            "barrier_values_m": dict(self.barrier_values_m),
            "violations": list(self.violations),
            "assumptions": dict(self.assumptions),
        }


@dataclass(frozen=True)
class ExecutionRolloutCertificateResult:
    """Independent multi-step certificate for the shared execution contract."""

    valid: bool
    status: str
    current_state_safe: bool
    rollout_state_safe: bool
    horizon_steps: int
    minimum_robust_barrier_m: float
    minimum_nominal_barrier_m: float
    barrier_values_m: dict[str, float]
    nominal_barrier_values_m: dict[str, float]
    violations: tuple[str, ...]
    assumptions: dict[str, float]

    def as_dict(self) -> dict[str, Any]:
        return {
            "valid": self.valid,
            "status": self.status,
            "current_state_safe": self.current_state_safe,
            "rollout_state_safe": self.rollout_state_safe,
            "horizon_steps": self.horizon_steps,
            "minimum_robust_barrier_m": self.minimum_robust_barrier_m,
            "minimum_nominal_barrier_m": self.minimum_nominal_barrier_m,
            "barrier_values_m": dict(self.barrier_values_m),
            "nominal_barrier_values_m": dict(self.nominal_barrier_values_m),
            "violations": list(self.violations),
            "assumptions": dict(self.assumptions),
        }


@dataclass(frozen=True)
class SweptVolumeCertificateResult:
    """Continuous-time sampled swept-volume safety certificate."""

    valid: bool
    status: str
    current_state_safe: bool
    swept_volume_safe: bool
    horizon_steps: int
    subdivisions_per_step: int
    sample_count: int
    minimum_robust_barrier_m: float
    minimum_nominal_barrier_m: float
    violations: tuple[str, ...]
    assumptions: dict[str, float]

    def as_dict(self) -> dict[str, Any]:
        return {
            "valid": self.valid,
            "status": self.status,
            "current_state_safe": self.current_state_safe,
            "swept_volume_safe": self.swept_volume_safe,
            "horizon_steps": self.horizon_steps,
            "subdivisions_per_step": self.subdivisions_per_step,
            "sample_count": self.sample_count,
            "minimum_robust_barrier_m": self.minimum_robust_barrier_m,
            "minimum_nominal_barrier_m": self.minimum_nominal_barrier_m,
            "violations": list(self.violations),
            "assumptions": dict(self.assumptions),
        }


@dataclass(frozen=True)
class ContinuousSegmentCertificateResult:
    """Conservative all-points check for piecewise-linear benchmark segments.

    The lower bound follows from the 1-Lipschitz signed-distance and pairwise
    separation barriers.  It certifies the interpolation implied by the
    benchmark position update, not an unmodeled real-airframe trajectory.
    """

    valid: bool
    status: str
    current_state_safe: bool
    continuous_segment_safe: bool
    horizon_steps: int
    segment_count: int
    minimum_robust_barrier_m: float
    minimum_nominal_barrier_m: float
    violations: tuple[str, ...]
    assumptions: dict[str, float]

    def as_dict(self) -> dict[str, Any]:
        return {
            "valid": self.valid,
            "status": self.status,
            "current_state_safe": self.current_state_safe,
            "continuous_segment_safe": self.continuous_segment_safe,
            "horizon_steps": self.horizon_steps,
            "segment_count": self.segment_count,
            "minimum_robust_barrier_m": self.minimum_robust_barrier_m,
            "minimum_nominal_barrier_m": self.minimum_nominal_barrier_m,
            "violations": list(self.violations),
            "assumptions": dict(self.assumptions),
        }


@dataclass(frozen=True)
class ExecutionRecoverabilityResult:
    """Certificate for the part of a queued execution that cannot be changed yet.

    ``prefix_admissible`` only means that the immutable queue prefix remains
    inside the current robust contract.  It is not a proof that a future
    action exists for the complete preview horizon.
    """

    status: str
    current_state_safe: bool
    prefix_admissible: bool
    abort_required: bool
    immutable_prefix_horizon_steps: int
    minimum_current_robust_barrier_m: float
    minimum_prefix_robust_barrier_m: float
    minimum_robust_barrier_m: float
    violations: tuple[str, ...]
    assumptions: dict[str, float]

    def as_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "current_state_safe": self.current_state_safe,
            "prefix_admissible": self.prefix_admissible,
            "abort_required": self.abort_required,
            "immutable_prefix_horizon_steps": self.immutable_prefix_horizon_steps,
            "minimum_current_robust_barrier_m": self.minimum_current_robust_barrier_m,
            "minimum_prefix_robust_barrier_m": self.minimum_prefix_robust_barrier_m,
            "minimum_robust_barrier_m": self.minimum_robust_barrier_m,
            "violations": list(self.violations),
            "assumptions": dict(self.assumptions),
        }


def _barriers(
    positions: np.ndarray,
    obstacles: list[Any] | tuple[Any, ...],
    lower: np.ndarray,
    upper: np.ndarray,
    radius: float,
    effective_margin: float,
) -> dict[str, float]:
    values: dict[str, float] = {}
    for defender_index, position in enumerate(positions):
        for obstacle_index, obstacle in enumerate(obstacles):
            values[f"obstacle[{obstacle_index}]/{defender_index}"] = (
                _signed_obstacle_clearance(position, obstacle) - radius - effective_margin
            )
        for axis in range(3):
            values[f"boundary_lower[{axis}]/{defender_index}"] = (
                position[axis] - lower[axis] - radius - effective_margin
            )
            values[f"boundary_upper[{axis}]/{defender_index}"] = (
                upper[axis] - position[axis] - radius - effective_margin
            )
    minimum_distance = 2.0 * radius + effective_margin
    for first in range(len(positions)):
        for second in range(first + 1, len(positions)):
            values[f"inter_agent[{first},{second}]"] = (
                float(np.linalg.norm(positions[first] - positions[second])) - minimum_distance
            )
    return values


def check_one_step_safety(
    observation: Mapping[str, Any],
    safe_actions: np.ndarray,
    *,
    dt: float,
    drone_radius: float,
    max_speed_mps: float,
    max_acceleration_mps2: float,
    safety_margin_m: float,
    robust_margin_m: float,
    tolerance: float = 1.0e-6,
    action_change_limit_mps: float | None = None,
    enforce_action_change: bool = True,
) -> SafetyCertificateResult:
    """Check current and next-step geometry plus velocity/action limits."""

    positions = np.asarray(observation["defender_positions"], dtype=np.float64)
    velocities = np.asarray(observation.get("defender_velocities", np.zeros_like(positions)), dtype=np.float64)
    actions = np.asarray(safe_actions, dtype=np.float64)
    if positions.ndim != 2 or positions.shape[-1] != 3 or velocities.shape != positions.shape:
        raise ValueError("defender positions and velocities must have shape [defenders, 3]")
    if actions.shape != positions.shape:
        raise ValueError("safe_actions must have shape [defenders, 3]")
    if not np.isfinite(positions).all() or not np.isfinite(velocities).all():
        raise ValueError("observation state must be finite")

    lower = np.asarray(observation["world_lower_bounds"], dtype=np.float64)
    upper = np.asarray(observation["world_upper_bounds"], dtype=np.float64)
    obstacles = list(observation.get("obstacles", ()))
    effective_margin = float(safety_margin_m) + float(robust_margin_m)
    current = _barriers(positions, obstacles, lower, upper, float(drone_radius), effective_margin)

    assumptions = {
        "dt_seconds": float(dt),
        "drone_radius_m": float(drone_radius),
        "max_speed_mps": float(max_speed_mps),
        "max_acceleration_mps2": float(max_acceleration_mps2),
        "safety_margin_m": float(safety_margin_m),
        "robust_margin_m": float(robust_margin_m),
        "tolerance_m": float(tolerance),
        "action_change_check_enabled": float(bool(enforce_action_change)),
        "action_change_limit_mps": float(
            max_acceleration_mps2 * dt if action_change_limit_mps is None else action_change_limit_mps
        ),
    }
    if not np.isfinite(actions).all():
        return SafetyCertificateResult(
            valid=False,
            status="invalid_non_finite_action",
            current_state_safe=bool(min(current.values(), default=float("inf")) >= -float(tolerance)),
            next_state_safe=False,
            current_min_barrier_m=float(min(current.values(), default=float("inf"))),
            next_min_barrier_m=float("-inf"),
            maximum_action_norm_mps=float("inf"),
            maximum_action_change_mps=float("inf"),
            barrier_values_m=current,
            violations=("non_finite_action",),
            assumptions=assumptions,
        )

    next_positions = positions + float(dt) * actions
    next_barriers = _barriers(next_positions, obstacles, lower, upper, float(drone_radius), effective_margin)
    barrier_values = {f"current/{key}": value for key, value in current.items()}
    barrier_values.update({f"next/{key}": value for key, value in next_barriers.items()})
    current_minimum = float(min(current.values(), default=float("inf")))
    next_minimum = float(min(next_barriers.values(), default=float("inf")))
    action_norms = np.linalg.norm(actions, axis=1)
    action_changes = np.abs(actions - velocities)
    maximum_action_norm = float(np.max(action_norms, initial=0.0))
    maximum_action_change = float(np.max(action_changes, initial=0.0))
    violations: list[str] = []
    if current_minimum < -float(tolerance):
        violations.append("current_state_outside_safe_set")
    if next_minimum < -float(tolerance):
        violations.append("next_state_outside_safe_set")
    if maximum_action_norm > float(max_speed_mps) + float(tolerance):
        violations.append("speed_limit")
    change_limit = float(max_acceleration_mps2) * float(dt) if action_change_limit_mps is None else float(action_change_limit_mps)
    if enforce_action_change and maximum_action_change > change_limit + float(tolerance):
        violations.append("action_change_limit")
    current_state_safe = current_minimum >= -float(tolerance)
    next_state_safe = next_minimum >= -float(tolerance)
    valid = not violations
    return SafetyCertificateResult(
        valid=valid,
        status="valid" if valid else "invalid",
        current_state_safe=current_state_safe,
        next_state_safe=next_state_safe,
        current_min_barrier_m=current_minimum,
        next_min_barrier_m=next_minimum,
        maximum_action_norm_mps=maximum_action_norm,
        maximum_action_change_mps=maximum_action_change,
        barrier_values_m=barrier_values,
        violations=tuple(violations),
        assumptions=assumptions,
    )


def _robust_barriers(
    positions: np.ndarray,
    obstacles: list[Any] | tuple[Any, ...],
    lower: np.ndarray,
    upper: np.ndarray,
    radius: float,
    effective_margin: float,
    uncertainty_radii: np.ndarray,
) -> tuple[dict[str, float], dict[str, float]]:
    nominal = _barriers(positions, obstacles, lower, upper, radius, effective_margin)
    robust: dict[str, float] = {}
    for name, value in nominal.items():
        if name.startswith("inter_agent["):
            indices = name.removeprefix("inter_agent[").removesuffix("]").split(",")
            uncertainty = float(uncertainty_radii[int(indices[0])] + uncertainty_radii[int(indices[1])])
        else:
            uncertainty = float(uncertainty_radii[int(name.rsplit("/", 1)[-1])])
        robust[name] = float(value - uncertainty)
    return nominal, robust


def _barrier_position_gradients(
    positions: np.ndarray,
    names: list[str],
    obstacles: list[Any] | tuple[Any, ...],
    lower: np.ndarray,
    upper: np.ndarray,
    radius: float,
    effective_margin: float,
) -> np.ndarray:
    """Return subgradients of geometric barriers with respect to positions."""

    points = np.asarray(positions, dtype=np.float64)
    gradients = np.zeros((len(names), points.size), dtype=np.float64)
    for row, name in enumerate(names):
        if name.startswith("obstacle["):
            obstacle_index, defender_index = name.removeprefix("obstacle[").removesuffix("").split("]/")
            obstacle = obstacles[int(obstacle_index)]
            _, local_gradient = _signed_obstacle_clearance_and_gradient(
                points[int(defender_index)], obstacle
            )
            gradients[row, int(defender_index) * 3 : int(defender_index) * 3 + 3] = local_gradient
        elif name.startswith("boundary_lower["):
            axis, defender_index = name.removeprefix("boundary_lower[").split("]/")
            gradients[row, int(defender_index) * 3 + int(axis)] = 1.0
        elif name.startswith("boundary_upper["):
            axis, defender_index = name.removeprefix("boundary_upper[").split("]/")
            gradients[row, int(defender_index) * 3 + int(axis)] = -1.0
        elif name.startswith("inter_agent["):
            first, second = name.removeprefix("inter_agent[").removesuffix("]").split(",")
            first_index = int(first)
            second_index = int(second)
            relative = points[first_index] - points[second_index]
            normal = _unit(relative, fallback=np.array([1.0, 0.0, 0.0], dtype=np.float64))
            gradients[row, first_index * 3 : first_index * 3 + 3] = normal
            gradients[row, second_index * 3 : second_index * 3 + 3] = -normal
        else:
            raise ValueError(f"Unknown barrier name: {name}")
    return gradients


def _barriers_with_position_gradients(
    positions: np.ndarray,
    obstacles: list[Any] | tuple[Any, ...],
    lower: np.ndarray,
    upper: np.ndarray,
    radius: float,
    effective_margin: float,
    *,
    include_gradients: bool,
) -> tuple[dict[str, float], np.ndarray | None]:
    """Evaluate geometric barriers and, optionally, their position gradients.

    The continuous-segment contract evaluates the same geometry repeatedly at
    adjacent segment endpoints.  Keeping the value and gradient calculation in
    one pass avoids recomputing obstacle geometry and pairwise normals while
    preserving the ordering used by ``_barriers`` and the QP Jacobian.
    """

    points = np.asarray(positions, dtype=np.float64)
    values: dict[str, float] = {}
    gradient_rows: list[np.ndarray] = []
    point_dimension = int(points.size)

    def append(name: str, value: float, gradient: np.ndarray | None = None) -> None:
        values[name] = float(value)
        if include_gradients:
            assert gradient is not None
            gradient_rows.append(np.asarray(gradient, dtype=np.float64).reshape(point_dimension))

    for defender_index, position in enumerate(points):
        for obstacle_index, obstacle in enumerate(obstacles):
            if include_gradients:
                clearance, clearance_gradient = _signed_obstacle_clearance_and_gradient(position, obstacle)
            else:
                clearance = _signed_obstacle_clearance(position, obstacle)
                clearance_gradient = None
            append(
                f"obstacle[{obstacle_index}]/{defender_index}",
                clearance - float(radius) - float(effective_margin),
                _embed_position_gradient(
                    defender_index,
                    clearance_gradient,
                    point_dimension,
                ) if include_gradients else None,
            )
        for axis in range(3):
            lower_gradient = np.zeros(point_dimension, dtype=np.float64) if include_gradients else None
            upper_gradient = np.zeros(point_dimension, dtype=np.float64) if include_gradients else None
            if include_gradients:
                assert lower_gradient is not None and upper_gradient is not None
                lower_gradient[defender_index * 3 + axis] = 1.0
                upper_gradient[defender_index * 3 + axis] = -1.0
            append(
                f"boundary_lower[{axis}]/{defender_index}",
                position[axis] - lower[axis] - float(radius) - float(effective_margin),
                lower_gradient,
            )
            append(
                f"boundary_upper[{axis}]/{defender_index}",
                upper[axis] - position[axis] - float(radius) - float(effective_margin),
                upper_gradient,
            )

    minimum_distance = 2.0 * float(radius) + float(effective_margin)
    for first in range(len(points)):
        for second in range(first + 1, len(points)):
            relative = points[first] - points[second]
            separation = float(np.linalg.norm(relative))
            if include_gradients:
                normal = _unit(relative, fallback=np.array([1.0, 0.0, 0.0], dtype=np.float64))
                pair_gradient = np.zeros(point_dimension, dtype=np.float64)
                pair_gradient[first * 3 : first * 3 + 3] = normal
                pair_gradient[second * 3 : second * 3 + 3] = -normal
            else:
                pair_gradient = None
            append(
                f"inter_agent[{first},{second}]",
                separation - minimum_distance,
                pair_gradient,
            )

    gradients = None if not include_gradients else np.stack(gradient_rows, axis=0)
    return values, gradients


def _embed_position_gradient(
    defender_index: int,
    local_gradient: np.ndarray | None,
    point_dimension: int,
) -> np.ndarray:
    """Embed a 3D obstacle gradient in the flattened defender state."""

    assert local_gradient is not None
    embedded = np.zeros(point_dimension, dtype=np.float64)
    embedded[defender_index * 3 : defender_index * 3 + 3] = local_gradient
    return embedded


def _robustify_barriers(
    nominal: dict[str, float],
    uncertainty_radii: np.ndarray,
) -> dict[str, float]:
    """Subtract the per-defender reachable-tube radii from barrier values."""

    robust: dict[str, float] = {}
    for name, value in nominal.items():
        if name.startswith("inter_agent["):
            indices = name.removeprefix("inter_agent[").removesuffix("]").split(",")
            uncertainty = float(uncertainty_radii[int(indices[0])] + uncertainty_radii[int(indices[1])])
        else:
            uncertainty = float(uncertainty_radii[int(name.rsplit("/", 1)[-1])])
        robust[name] = float(value - uncertainty)
    return robust


def _continuous_segment_barrier_data(
    positions: np.ndarray,
    rollout_positions: list[np.ndarray] | tuple[np.ndarray, ...],
    uncertainty: np.ndarray,
    obstacles: list[Any] | tuple[Any, ...],
    lower: np.ndarray,
    upper: np.ndarray,
    radius: float,
    effective_margin: float,
    *,
    continuous_segment_subdivisions: int = 4,
    position_jacobians: list[np.ndarray] | tuple[np.ndarray, ...] | None = None,
) -> tuple[dict[str, float], dict[str, float], np.ndarray | None]:
    """Build the conservative continuous-segment barrier contract.

    Each action segment receives ``continuous_segment_subdivisions`` internal
    samples and is therefore split into one more linear subsegments. For each
    subsegment the lower bound is the minimum of its robust endpoint barriers
    minus half the local relative path length.
    This is a 1-Lipschitz bound for the geometric barriers and is materially
    tighter than applying half of the full action-segment path to every step.
    The same sampled contract is used by the independent certificate and the
    optional local Jacobian exposed to the execution-aware QP.
    """

    internal_samples = int(continuous_segment_subdivisions)
    if internal_samples <= 0:
        raise ValueError("continuous_segment_subdivisions must be positive")
    subdivisions = internal_samples + 1

    nominal_values: dict[str, float] = {}
    robust_values: dict[str, float] = {}
    gradients: list[np.ndarray] = []
    action_dimension = 0 if position_jacobians is None else int(position_jacobians[0].shape[1])
    previous = np.asarray(positions, dtype=np.float64)
    previous_jacobian = (
        None
        if position_jacobians is None
        else np.zeros_like(np.asarray(position_jacobians[0], dtype=np.float64))
    )
    for step_index, endpoint_value in enumerate(rollout_positions):
        endpoint = np.asarray(endpoint_value, dtype=np.float64)
        endpoint_jacobian = None if position_jacobians is None else np.asarray(position_jacobians[step_index])
        assert previous_jacobian is not None or position_jacobians is None
        motion = endpoint - previous
        endpoint_delta_jacobian = (
            None
            if position_jacobians is None
            else endpoint_jacobian - previous_jacobian
        )
        # Cache all internal sample geometries once.  Adjacent subsegments
        # share endpoints, so this removes the previous 2*N endpoint passes.
        sample_positions: list[np.ndarray] = []
        sample_jacobians: list[np.ndarray] | None = [] if position_jacobians is not None else None
        sample_nominal: list[dict[str, float]] = []
        sample_robust: list[dict[str, float]] = []
        sample_gradients: list[np.ndarray] | None = [] if position_jacobians is not None else None
        for sample_index in range(subdivisions + 1):
            fraction = float(sample_index) / float(subdivisions)
            sample_position = previous + fraction * motion
            sample_positions.append(sample_position)
            if position_jacobians is None:
                sample_jacobian = None
            else:
                assert endpoint_delta_jacobian is not None and previous_jacobian is not None
                sample_jacobian = previous_jacobian + fraction * endpoint_delta_jacobian
                assert sample_jacobians is not None
                sample_jacobians.append(sample_jacobian)
            nominal, gradients_at_position = _barriers_with_position_gradients(
                sample_position,
                obstacles,
                lower,
                upper,
                float(radius),
                float(effective_margin),
                include_gradients=position_jacobians is not None,
            )
            sample_nominal.append(nominal)
            sample_robust.append(_robustify_barriers(nominal, uncertainty[step_index]))
            if position_jacobians is not None:
                assert sample_gradients is not None and gradients_at_position is not None
                sample_gradients.append(gradients_at_position)

        for subdivision in range(1, subdivisions + 1):
            segment_start = sample_positions[subdivision - 1]
            segment_end = sample_positions[subdivision]
            start_nominal = sample_nominal[subdivision - 1]
            end_nominal = sample_nominal[subdivision]
            start_robust = sample_robust[subdivision - 1]
            end_robust = sample_robust[subdivision]
            if position_jacobians is None:
                segment_start_jacobian = segment_end_jacobian = None
            else:
                assert sample_jacobians is not None
                segment_start_jacobian = sample_jacobians[subdivision - 1]
                segment_end_jacobian = sample_jacobians[subdivision]
            names = list(end_nominal)
            if position_jacobians is not None:
                assert segment_start_jacobian is not None and segment_end_jacobian is not None
                assert sample_gradients is not None
                start_position_gradients = sample_gradients[subdivision - 1]
                end_position_gradients = sample_gradients[subdivision]
                start_action_jacobian = start_position_gradients @ segment_start_jacobian
                end_action_jacobian = end_position_gradients @ segment_end_jacobian
            else:
                start_action_jacobian = end_action_jacobian = None

            local_motion = segment_end - segment_start
            local_motion_norms = np.linalg.norm(local_motion, axis=1)
            for name_index, name in enumerate(names):
                if name.startswith("inter_agent["):
                    first, second = name.removeprefix("inter_agent[").removesuffix("]").split(",")
                    first_index, second_index = int(first), int(second)
                    half_path = 0.5 * float(
                        local_motion_norms[first_index] + local_motion_norms[second_index]
                    )
                    if position_jacobians is None:
                        half_path_gradient = None
                    else:
                        first_gradient = np.zeros(action_dimension, dtype=np.float64)
                        second_gradient = np.zeros(action_dimension, dtype=np.float64)
                        if local_motion_norms[first_index] > 1.0e-12:
                            first_gradient = (
                                local_motion[first_index] / local_motion_norms[first_index]
                            ) @ (segment_end_jacobian[first_index * 3 : first_index * 3 + 3] - segment_start_jacobian[first_index * 3 : first_index * 3 + 3])
                        if local_motion_norms[second_index] > 1.0e-12:
                            second_gradient = (
                                local_motion[second_index] / local_motion_norms[second_index]
                            ) @ (segment_end_jacobian[second_index * 3 : second_index * 3 + 3] - segment_start_jacobian[second_index * 3 : second_index * 3 + 3])
                        half_path_gradient = 0.5 * (first_gradient + second_gradient)
                else:
                    defender_index = int(name.rsplit("/", 1)[-1])
                    half_path = 0.5 * float(local_motion_norms[defender_index])
                    if position_jacobians is None or local_motion_norms[defender_index] <= 1.0e-12:
                        half_path_gradient = (
                            None if position_jacobians is None else np.zeros(action_dimension, dtype=np.float64)
                        )
                    else:
                        half_path_gradient = 0.5 * (
                            local_motion[defender_index] / local_motion_norms[defender_index]
                        ) @ (segment_end_jacobian[defender_index * 3 : defender_index * 3 + 3] - segment_start_jacobian[defender_index * 3 : defender_index * 3 + 3])
                robust_start_value = float(start_robust[name])
                robust_end_value = float(end_robust[name])
                nominal_start_value = float(start_nominal[name])
                nominal_end_value = float(end_nominal[name])
                use_start = robust_start_value <= robust_end_value
                key = f"step[{step_index + 1}]/segment[{subdivision}]/continuous/{name}"
                nominal_values[key] = float(min(nominal_start_value, nominal_end_value) - half_path)
                robust_values[key] = float(min(robust_start_value, robust_end_value) - half_path)
                if position_jacobians is not None:
                    base_gradient = start_action_jacobian[name_index] if use_start else end_action_jacobian[name_index]
                    gradients.append(np.asarray(base_gradient, dtype=np.float64) - half_path_gradient)
        previous = endpoint
        previous_jacobian = endpoint_jacobian
    jacobian = None if position_jacobians is None else np.stack(gradients, axis=0)
    return nominal_values, robust_values, jacobian


def execution_barrier_values(
    observation: Mapping[str, Any],
    action: np.ndarray,
    *,
    dt: float,
    drone_radius: float,
    safety_margin_m: float,
    robust_margin_m: float,
    horizon_steps: int | None = None,
    swept_substeps: int = 4,
    reachable_tube_multiplier: float = 1.0,
    continuous_segment_constraints: bool = False,
    continuous_segment_subdivisions: int = 4,
    command_authority: CommandAuthorityDirective | Mapping[str, Any] | None = None,
) -> tuple[dict[str, float], dict[str, float], dict[str, float]]:
    """Return nominal and uncertainty-robust barriers along executed rollout."""

    positions = np.asarray(observation["defender_positions"], dtype=np.float64)
    velocities = np.asarray(observation.get("defender_velocities", np.zeros_like(positions)), dtype=np.float64)
    actions = np.asarray(action, dtype=np.float64)
    if positions.ndim != 2 or positions.shape[-1] != 3 or velocities.shape != positions.shape:
        raise ValueError("defender positions and velocities must have shape [defenders, 3]")
    if actions.shape != positions.shape:
        raise ValueError("action must have shape [defenders, 3]")
    lower = np.asarray(observation["world_lower_bounds"], dtype=np.float64)
    upper = np.asarray(observation["world_upper_bounds"], dtype=np.float64)
    obstacles = list(observation.get("obstacles", ()))
    parameters = parameters_from_observation(observation, dt)
    queue = queue_from_observation(observation, positions.shape[0])
    queue, directive, overridden_slots = apply_command_authority(
        queue,
        command_authority,
        allowed_mode=command_authority_from_observation(observation),
    )
    preview_steps = max(1, len(queue) + 1) if horizon_steps is None else int(horizon_steps)
    if preview_steps <= 0:
        raise ValueError("horizon_steps must be positive")
    if int(swept_substeps) <= 0:
        raise ValueError("swept_substeps must be positive")
    rollout_positions, _rollout_velocities, _steps = rollout_execution(
        positions,
        velocities,
        queue,
        actions,
        parameters,
        horizon_steps=preview_steps,
    )
    uncertainty = reachable_tube_radii(
        parameters,
        positions.shape[0],
        preview_steps,
        multiplier=reachable_tube_multiplier,
    )
    if continuous_segment_constraints:
        if int(continuous_segment_subdivisions) <= 0:
            raise ValueError("continuous_segment_subdivisions must be positive")
        internal_samples = int(continuous_segment_subdivisions)
        subsegments = internal_samples + 1
        nominal_values, robust_values, _ = _continuous_segment_barrier_data(
            positions,
            rollout_positions,
            uncertainty,
            obstacles,
            lower,
            upper,
            float(drone_radius),
            float(safety_margin_m) + float(robust_margin_m),
            continuous_segment_subdivisions=int(continuous_segment_subdivisions),
        )
        assumptions = {
            "dt_seconds": float(dt),
            "horizon_steps": float(preview_steps),
            "action_delay_steps": float(parameters.action_delay_steps),
            "command_noise_bound_mps": float(parameters.command_noise_bound_mps),
            "tracking_alpha": float(parameters.tracking_alpha),
            "drag_gain": float(parameters.drag_gain),
            "max_speed_mps": float(parameters.max_speed_mps),
            "max_acceleration_mps2": float(parameters.max_acceleration_mps2),
            "mass_scale": float(parameters.mass_scale),
            "continuous_segment_constraints": 1.0,
            "continuous_segment_subdivisions": float(internal_samples),
            "continuous_segment_internal_samples": float(internal_samples),
            "continuous_segment_subsegments": float(subsegments),
            "command_authority_mode": float(
                {"immutable": 0, "replace_nonexecuting": 1, "flush_pending": 2}[directive.mode]
            ),
            "emergency_brake_requested": float(directive.emergency_brake),
            "queue_override_slots": float(overridden_slots),
            "reachable_tube_multiplier": float(reachable_tube_multiplier),
        }
        return nominal_values, robust_values, assumptions
    nominal_values: dict[str, float] = {}
    robust_values: dict[str, float] = {}
    for step_index, (future_positions, radii) in enumerate(zip(rollout_positions, uncertainty), start=1):
        previous_positions = positions if step_index == 1 else rollout_positions[step_index - 2]
        individual_gaps = np.linalg.norm(future_positions - previous_positions, axis=1) / float(swept_substeps)
        for subdivision in range(1, int(swept_substeps) + 1):
            fraction = float(subdivision) / float(swept_substeps)
            sample_positions = previous_positions + fraction * (future_positions - previous_positions)
            nominal, robust = _robust_barriers(
                sample_positions,
                obstacles,
                lower,
                upper,
                float(drone_radius),
                float(safety_margin_m) + float(robust_margin_m),
                radii,
            )
            for name, value in nominal.items():
                if name.startswith("inter_agent["):
                    first, second = name.removeprefix("inter_agent[").removesuffix("]").split(",")
                    gap = float(individual_gaps[int(first)] + individual_gaps[int(second)])
                else:
                    gap = float(individual_gaps[int(name.rsplit("/", 1)[-1])])
                key = f"step[{step_index}]/sweep[{subdivision}]/{name}"
                nominal_values[key] = float(value - gap)
                robust_values[key] = float(robust[name] - gap)
    assumptions = {
        "dt_seconds": float(dt),
        "horizon_steps": float(preview_steps),
        "action_delay_steps": float(parameters.action_delay_steps),
        "command_noise_bound_mps": float(parameters.command_noise_bound_mps),
        "tracking_alpha": float(parameters.tracking_alpha),
        "drag_gain": float(parameters.drag_gain),
        "max_speed_mps": float(parameters.max_speed_mps),
        "max_acceleration_mps2": float(parameters.max_acceleration_mps2),
        "mass_scale": float(parameters.mass_scale),
        "swept_substeps": float(swept_substeps),
        "command_authority_mode": float(
            {"immutable": 0, "replace_nonexecuting": 1, "flush_pending": 2}[directive.mode]
        ),
        "emergency_brake_requested": float(directive.emergency_brake),
        "queue_override_slots": float(overridden_slots),
        "reachable_tube_multiplier": float(reachable_tube_multiplier),
    }
    return nominal_values, robust_values, assumptions


def assess_execution_recoverability(
    observation: Mapping[str, Any],
    *,
    dt: float,
    drone_radius: float,
    safety_margin_m: float,
    robust_margin_m: float,
    horizon_steps: int | None = None,
    reachable_tube_multiplier: float = 1.0,
    tolerance: float = 1.0e-6,
    command_authority: CommandAuthorityDirective | Mapping[str, Any] | None = None,
) -> ExecutionRecoverabilityResult:
    """Classify whether an immutable queued prefix already requires abort.

    Under immutable authority, every queued command is fixed until it is
    executed.  A ``replace_nonexecuting`` emergency brake leaves only the
    command due on the current tick fixed; ``flush_pending`` with an emergency
    brake removes the fixed prefix.  Without an emergency directive, queued
    commands remain fixed because no replacement has been authorized.  The
    check evaluates exactly that prefix with the shared nonlinear execution
    rollout and therefore avoids claiming that a future action can repair an
    already committed command.
    """

    positions = np.asarray(observation["defender_positions"], dtype=np.float64)
    if positions.ndim != 2 or positions.shape[-1] != 3:
        raise ValueError("defender_positions must have shape [defenders, 3]")
    lower = np.asarray(observation["world_lower_bounds"], dtype=np.float64)
    upper = np.asarray(observation["world_upper_bounds"], dtype=np.float64)
    obstacles = list(observation.get("obstacles", ()))
    queued = queue_from_observation(observation, positions.shape[0])
    allowed_mode = command_authority_from_observation(observation)
    directive = command_authority_directive(command_authority, allowed_mode=allowed_mode)
    effective_queue, _resolved, overridden_slots = apply_command_authority(
        queued,
        directive,
        allowed_mode=allowed_mode,
    )
    preview_steps = max(1, len(effective_queue) + 1) if horizon_steps is None else int(horizon_steps)
    if preview_steps <= 0:
        raise ValueError("horizon_steps must be positive")
    if directive.emergency_brake:
        if directive.mode == "flush_pending":
            immutable_prefix_steps = 0
        elif directive.mode == "replace_nonexecuting":
            immutable_prefix_steps = min(len(queued), 1)
        else:
            immutable_prefix_steps = len(queued)
    else:
        immutable_prefix_steps = len(queued)
    immutable_prefix_steps = min(int(immutable_prefix_steps), preview_steps)

    current_values = _barriers(
        positions,
        obstacles,
        lower,
        upper,
        float(drone_radius),
        float(safety_margin_m) + float(robust_margin_m),
    )
    current_minimum = float(min(current_values.values(), default=float("inf")))
    prefix_values: dict[str, float] = {}
    if immutable_prefix_steps > 0:
        _nominal, prefix_values, _assumptions = execution_barrier_values(
            observation,
            np.zeros_like(positions),
            dt=dt,
            drone_radius=drone_radius,
            safety_margin_m=safety_margin_m,
            robust_margin_m=robust_margin_m,
            horizon_steps=immutable_prefix_steps,
            reachable_tube_multiplier=reachable_tube_multiplier,
            command_authority=directive,
        )
    prefix_minimum = float(min(prefix_values.values(), default=float("inf")))
    minimum = min(current_minimum, prefix_minimum)
    tolerance_value = float(tolerance)
    current_safe = current_minimum >= -tolerance_value
    prefix_safe = prefix_minimum >= -tolerance_value
    violations: list[str] = []
    if not current_safe:
        violations.append("current_state_outside_robust_safe_set")
    if immutable_prefix_steps > 0 and not prefix_safe:
        violations.append("immutable_execution_prefix_outside_robust_safe_set")
    abort_required = bool(violations)
    status = "abort_required" if abort_required else "prefix_admissible"
    return ExecutionRecoverabilityResult(
        status=status,
        current_state_safe=current_safe,
        prefix_admissible=bool(current_safe and prefix_safe),
        abort_required=abort_required,
        immutable_prefix_horizon_steps=int(immutable_prefix_steps),
        minimum_current_robust_barrier_m=float(current_minimum),
        minimum_prefix_robust_barrier_m=float(prefix_minimum),
        minimum_robust_barrier_m=float(minimum),
        violations=tuple(violations),
        assumptions={
            "dt_seconds": float(dt),
            "horizon_steps": float(preview_steps),
            "queued_command_count": float(len(queued)),
            "immutable_prefix_horizon_steps": float(immutable_prefix_steps),
            "pending_command_authority": float(
                {"immutable": 0, "replace_nonexecuting": 1, "flush_pending": 2}[directive.mode]
            ),
            "emergency_brake_requested": float(directive.emergency_brake),
            "queue_override_slots": float(overridden_slots),
            "current_min_robust_barrier_m": float(current_minimum),
            "prefix_min_robust_barrier_m": float(prefix_minimum),
            "reachable_tube_multiplier": float(reachable_tube_multiplier),
        },
    )


def execution_barrier_values_with_action_jacobian(
    observation: Mapping[str, Any],
    action: np.ndarray,
    *,
    dt: float,
    drone_radius: float,
    safety_margin_m: float,
    robust_margin_m: float,
    horizon_steps: int | None = None,
    swept_substeps: int = 4,
    jacobian_active_margin_m: float | None = None,
    reachable_tube_multiplier: float = 1.0,
    continuous_segment_constraints: bool = False,
    continuous_segment_subdivisions: int = 4,
    command_authority: CommandAuthorityDirective | Mapping[str, Any] | None = None,
) -> tuple[dict[str, float], dict[str, float], np.ndarray, dict[str, float]]:
    """Evaluate execution barriers with local action derivatives.

    This shares the rollout convention of :func:`execution_barrier_values`.
    The returned Jacobian is ordered by the robust-barrier dictionary and is
    used only for sequential linearization; independent nonlinear certificates
    remain the acceptance criterion.
    """

    positions = np.asarray(observation["defender_positions"], dtype=np.float64)
    velocities = np.asarray(observation.get("defender_velocities", np.zeros_like(positions)), dtype=np.float64)
    actions = np.asarray(action, dtype=np.float64)
    if positions.ndim != 2 or positions.shape[-1] != 3 or velocities.shape != positions.shape:
        raise ValueError("defender positions and velocities must have shape [defenders, 3]")
    if actions.shape != positions.shape:
        raise ValueError("action must have shape [defenders, 3]")
    lower = np.asarray(observation["world_lower_bounds"], dtype=np.float64)
    upper = np.asarray(observation["world_upper_bounds"], dtype=np.float64)
    obstacles = list(observation.get("obstacles", ()))
    parameters = parameters_from_observation(observation, dt)
    queue = queue_from_observation(observation, positions.shape[0])
    queue, directive, overridden_slots = apply_command_authority(
        queue,
        command_authority,
        allowed_mode=command_authority_from_observation(observation),
    )
    preview_steps = max(1, len(queue) + 1) if horizon_steps is None else int(horizon_steps)
    if preview_steps <= 0:
        raise ValueError("horizon_steps must be positive")
    if int(swept_substeps) <= 0:
        raise ValueError("swept_substeps must be positive")
    rollout_positions, _rollout_velocities, _steps, position_jacobians, _velocity_jacobians = (
        rollout_execution_with_action_jacobian(
            positions,
            velocities,
            queue,
            actions,
            parameters,
            horizon_steps=preview_steps,
        )
    )
    uncertainty = reachable_tube_radii(
        parameters,
        positions.shape[0],
        preview_steps,
        multiplier=reachable_tube_multiplier,
    )
    if continuous_segment_constraints:
        if int(continuous_segment_subdivisions) <= 0:
            raise ValueError("continuous_segment_subdivisions must be positive")
        internal_samples = int(continuous_segment_subdivisions)
        subsegments = internal_samples + 1
        nominal_values, robust_values, jacobian = _continuous_segment_barrier_data(
            positions,
            rollout_positions,
            uncertainty,
            obstacles,
            lower,
            upper,
            float(drone_radius),
            float(safety_margin_m) + float(robust_margin_m),
            continuous_segment_subdivisions=int(continuous_segment_subdivisions),
            position_jacobians=position_jacobians,
        )
        assert jacobian is not None
        if jacobian_active_margin_m is not None:
            active = np.asarray(
                [robust_values[name] <= float(jacobian_active_margin_m) for name in robust_values],
                dtype=bool,
            )
            jacobian[~active] = 0.0
        assumptions = {
            "dt_seconds": float(dt),
            "horizon_steps": float(preview_steps),
            "action_delay_steps": float(parameters.action_delay_steps),
            "command_noise_bound_mps": float(parameters.command_noise_bound_mps),
            "tracking_alpha": float(parameters.tracking_alpha),
            "drag_gain": float(parameters.drag_gain),
            "max_speed_mps": float(parameters.max_speed_mps),
            "max_acceleration_mps2": float(parameters.max_acceleration_mps2),
            "mass_scale": float(parameters.mass_scale),
            "continuous_segment_constraints": 1.0,
            "continuous_segment_subdivisions": float(internal_samples),
            "continuous_segment_internal_samples": float(internal_samples),
            "continuous_segment_subsegments": float(subsegments),
            "command_authority_mode": float(
                {"immutable": 0, "replace_nonexecuting": 1, "flush_pending": 2}[directive.mode]
            ),
            "emergency_brake_requested": float(directive.emergency_brake),
            "queue_override_slots": float(overridden_slots),
            "jacobian_active_margin_m": float(
                -1.0 if jacobian_active_margin_m is None else jacobian_active_margin_m
            ),
            "reachable_tube_multiplier": float(reachable_tube_multiplier),
        }
        return nominal_values, robust_values, jacobian, assumptions
    nominal_values: dict[str, float] = {}
    robust_values: dict[str, float] = {}
    gradients: list[np.ndarray] = []
    action_dimension = int(actions.size)
    effective_margin = float(safety_margin_m) + float(robust_margin_m)

    def append_value(key: str, nominal: float, robust: float, gradient: np.ndarray) -> None:
        nominal_values[key] = float(nominal)
        robust_values[key] = float(robust)
        if jacobian_active_margin_m is not None and robust > float(jacobian_active_margin_m):
            gradients.append(np.zeros(action_dimension, dtype=np.float64))
        else:
            gradients.append(np.asarray(gradient, dtype=np.float64).reshape(action_dimension))

    for step_index, (future_positions, radii, endpoint_jacobian) in enumerate(
        zip(rollout_positions, uncertainty, position_jacobians), start=1
    ):
        previous_positions = positions if step_index == 1 else rollout_positions[step_index - 2]
        previous_jacobian = (
            np.zeros_like(endpoint_jacobian) if step_index == 1 else position_jacobians[step_index - 2]
        )
        segment_jacobian = endpoint_jacobian - previous_jacobian
        displacement = future_positions - previous_positions
        for subdivision in range(1, int(swept_substeps) + 1):
            fraction = float(subdivision) / float(swept_substeps)
            sample_positions = previous_positions + fraction * displacement
            sample_jacobian = previous_jacobian + fraction * segment_jacobian
            for defender_index, position in enumerate(sample_positions):
                position_gradient = sample_jacobian[
                    defender_index * 3 : defender_index * 3 + 3
                ]
                motion = displacement[defender_index]
                motion_norm = float(np.linalg.norm(motion))
                if motion_norm <= 1.0e-12:
                    motion_gradient = np.zeros(action_dimension, dtype=np.float64)
                else:
                    motion_gradient = (motion / motion_norm) @ segment_jacobian[
                        defender_index * 3 : defender_index * 3 + 3
                    ]
                for obstacle_index, obstacle in enumerate(obstacles):
                    clearance, clearance_gradient = _signed_obstacle_clearance_and_gradient(position, obstacle)
                    nominal = clearance - float(drone_radius) - effective_margin - motion_norm / float(swept_substeps)
                    robust = nominal - float(radii[defender_index])
                    key = f"step[{step_index}]/sweep[{subdivision}]/obstacle[{obstacle_index}]/{defender_index}"
                    append_value(key, nominal, robust, clearance_gradient @ position_gradient - motion_gradient / float(swept_substeps))
                for axis in range(3):
                    lower_nominal = (
                        position[axis] - lower[axis] - float(drone_radius) - effective_margin - motion_norm / float(swept_substeps)
                    )
                    lower_key = f"step[{step_index}]/sweep[{subdivision}]/boundary_lower[{axis}]/{defender_index}"
                    append_value(
                        lower_key,
                        lower_nominal,
                        lower_nominal - float(radii[defender_index]),
                        position_gradient[axis] - motion_gradient / float(swept_substeps),
                    )
                    upper_nominal = (
                        upper[axis] - position[axis] - float(drone_radius) - effective_margin - motion_norm / float(swept_substeps)
                    )
                    upper_key = f"step[{step_index}]/sweep[{subdivision}]/boundary_upper[{axis}]/{defender_index}"
                    append_value(
                        upper_key,
                        upper_nominal,
                        upper_nominal - float(radii[defender_index]),
                        -position_gradient[axis] - motion_gradient / float(swept_substeps),
                    )
            minimum_distance = 2.0 * float(drone_radius) + effective_margin
            for first in range(len(sample_positions)):
                for second in range(first + 1, len(sample_positions)):
                    relative = sample_positions[first] - sample_positions[second]
                    relative_norm = float(np.linalg.norm(relative))
                    normal = _unit(relative, fallback=np.array([1.0, 0.0, 0.0], dtype=np.float64))
                    relative_gradient = normal @ (
                        sample_jacobian[first * 3 : first * 3 + 3]
                        - sample_jacobian[second * 3 : second * 3 + 3]
                    )
                    first_motion = displacement[first]
                    second_motion = displacement[second]
                    first_norm = float(np.linalg.norm(first_motion))
                    second_norm = float(np.linalg.norm(second_motion))
                    first_gradient = (
                        np.zeros(action_dimension, dtype=np.float64)
                        if first_norm <= 1.0e-12
                        else (first_motion / first_norm) @ segment_jacobian[first * 3 : first * 3 + 3]
                    )
                    second_gradient = (
                        np.zeros(action_dimension, dtype=np.float64)
                        if second_norm <= 1.0e-12
                        else (second_motion / second_norm) @ segment_jacobian[second * 3 : second * 3 + 3]
                    )
                    motion_penalty = (first_norm + second_norm) / float(swept_substeps)
                    nominal = relative_norm - minimum_distance - motion_penalty
                    robust = nominal - float(radii[first] + radii[second])
                    key = f"step[{step_index}]/sweep[{subdivision}]/inter_agent[{first},{second}]"
                    append_value(
                        key,
                        nominal,
                        robust,
                        relative_gradient - (first_gradient + second_gradient) / float(swept_substeps),
                    )
    assumptions = {
        "dt_seconds": float(dt),
        "horizon_steps": float(preview_steps),
        "action_delay_steps": float(parameters.action_delay_steps),
        "command_noise_bound_mps": float(parameters.command_noise_bound_mps),
        "tracking_alpha": float(parameters.tracking_alpha),
        "drag_gain": float(parameters.drag_gain),
        "max_speed_mps": float(parameters.max_speed_mps),
        "max_acceleration_mps2": float(parameters.max_acceleration_mps2),
        "mass_scale": float(parameters.mass_scale),
        "swept_substeps": float(swept_substeps),
        "command_authority_mode": float(
            {"immutable": 0, "replace_nonexecuting": 1, "flush_pending": 2}[directive.mode]
        ),
        "emergency_brake_requested": float(directive.emergency_brake),
        "queue_override_slots": float(overridden_slots),
        "jacobian_active_margin_m": float(
            -1.0 if jacobian_active_margin_m is None else jacobian_active_margin_m
        ),
        "reachable_tube_multiplier": float(reachable_tube_multiplier),
    }
    return nominal_values, robust_values, np.stack(gradients, axis=0), assumptions


def check_execution_rollout_safety(
    observation: Mapping[str, Any],
    action: np.ndarray,
    *,
    dt: float,
    drone_radius: float,
    max_speed_mps: float,
    max_acceleration_mps2: float,
    safety_margin_m: float,
    robust_margin_m: float,
    tolerance: float = 1.0e-6,
    action_change_limit_mps: float | None = None,
    horizon_steps: int | None = None,
    reachable_tube_multiplier: float = 1.0,
    continuous_segment_constraints: bool = False,
    continuous_segment_subdivisions: int = 4,
    command_authority: CommandAuthorityDirective | Mapping[str, Any] | None = None,
    enforce_action_change: bool = True,
) -> ExecutionRolloutCertificateResult:
    """Check the actual queued execution model over a finite preview horizon."""

    positions = np.asarray(observation["defender_positions"], dtype=np.float64)
    velocities = np.asarray(observation.get("defender_velocities", np.zeros_like(positions)), dtype=np.float64)
    actions = np.asarray(action, dtype=np.float64)
    current = _barriers(
        positions,
        list(observation.get("obstacles", ())),
        np.asarray(observation["world_lower_bounds"], dtype=np.float64),
        np.asarray(observation["world_upper_bounds"], dtype=np.float64),
        float(drone_radius),
        float(safety_margin_m) + float(robust_margin_m),
    )
    current_minimum = float(min(current.values(), default=float("inf")))
    nominal_values, robust_values, assumptions = execution_barrier_values(
        observation,
        actions,
        dt=dt,
        drone_radius=drone_radius,
        safety_margin_m=safety_margin_m,
        robust_margin_m=robust_margin_m,
        horizon_steps=horizon_steps,
        reachable_tube_multiplier=reachable_tube_multiplier,
        continuous_segment_constraints=continuous_segment_constraints,
        continuous_segment_subdivisions=continuous_segment_subdivisions,
        command_authority=command_authority,
    )
    violations: list[str] = []
    tolerance_value = float(tolerance)
    if current_minimum < -tolerance_value:
        violations.append("current_state_outside_safe_set")
    robust_minimum = float(min(robust_values.values(), default=float("inf")))
    nominal_minimum = float(min(nominal_values.values(), default=float("inf")))
    if robust_minimum < -tolerance_value:
        violations.append("execution_rollout_outside_robust_safe_set")
    if not np.isfinite(actions).all():
        violations.append("non_finite_action")
    action_norm = float(np.max(np.linalg.norm(actions, axis=1), initial=0.0))
    if action_norm > float(max_speed_mps) + tolerance_value:
        violations.append("speed_limit")
    if enforce_action_change:
        change_limit = (
            float(max_acceleration_mps2) * float(dt)
            if action_change_limit_mps is None
            else float(action_change_limit_mps)
        )
        action_change = float(np.max(np.abs(actions - velocities), initial=0.0))
        if action_change > change_limit + tolerance_value:
            violations.append("action_change_limit")
    else:
        change_limit = float("nan")
    valid = not violations
    return ExecutionRolloutCertificateResult(
        valid=valid,
        status="valid" if valid else "invalid",
        current_state_safe=bool(current_minimum >= -tolerance_value),
        rollout_state_safe=bool(robust_minimum >= -tolerance_value),
        horizon_steps=int(assumptions["horizon_steps"]),
        minimum_robust_barrier_m=robust_minimum,
        minimum_nominal_barrier_m=nominal_minimum,
        barrier_values_m=robust_values,
        nominal_barrier_values_m=nominal_values,
        violations=tuple(violations),
        assumptions={
            **assumptions,
            "action_change_check_enabled": float(bool(enforce_action_change)),
            "action_change_limit_mps": float(change_limit),
        },
    )


def check_execution_swept_volume_safety(
    observation: Mapping[str, Any],
    action: np.ndarray,
    *,
    dt: float,
    drone_radius: float,
    safety_margin_m: float,
    robust_margin_m: float,
    horizon_steps: int | None = None,
    subdivisions_per_step: int = 4,
    reachable_tube_multiplier: float = 1.0,
    tolerance: float = 1.0e-6,
    command_authority: CommandAuthorityDirective | Mapping[str, Any] | None = None,
) -> SweptVolumeCertificateResult:
    """Sample each executed motion segment, including obstacle volume crossing."""

    if int(subdivisions_per_step) <= 0:
        raise ValueError("subdivisions_per_step must be positive")
    positions = np.asarray(observation["defender_positions"], dtype=np.float64)
    velocities = np.asarray(observation.get("defender_velocities", np.zeros_like(positions)), dtype=np.float64)
    lower = np.asarray(observation["world_lower_bounds"], dtype=np.float64)
    upper = np.asarray(observation["world_upper_bounds"], dtype=np.float64)
    obstacles = list(observation.get("obstacles", ()))
    parameters = parameters_from_observation(observation, dt)
    queue = queue_from_observation(observation, positions.shape[0])
    queue, directive, overridden_slots = apply_command_authority(
        queue,
        command_authority,
        allowed_mode=command_authority_from_observation(observation),
    )
    preview_steps = max(1, len(queue) + 1) if horizon_steps is None else int(horizon_steps)
    if preview_steps <= 0:
        raise ValueError("horizon_steps must be positive")
    rollout_positions, _rollout_velocities, _steps = rollout_execution(
        positions,
        velocities,
        queue,
        np.asarray(action, dtype=np.float64),
        parameters,
        horizon_steps=preview_steps,
    )
    uncertainty = reachable_tube_radii(
        parameters,
        positions.shape[0],
        preview_steps,
        multiplier=reachable_tube_multiplier,
    )
    initial_barriers = _barriers(
        positions,
        obstacles,
        lower,
        upper,
        float(drone_radius),
        float(safety_margin_m) + float(robust_margin_m),
    )
    nominal_minimum = float(min(initial_barriers.values(), default=float("inf")))
    robust_minimum = nominal_minimum
    sample_count = 1
    for step_index, endpoint in enumerate(rollout_positions):
        start = positions if step_index == 0 else rollout_positions[step_index - 1]
        individual_gaps = np.linalg.norm(endpoint - start, axis=1) / float(subdivisions_per_step)
        for subdivision in range(1, int(subdivisions_per_step) + 1):
            fraction = float(subdivision) / float(subdivisions_per_step)
            sample = start + fraction * (endpoint - start)
            nominal, robust = _robust_barriers(
                sample,
                obstacles,
                lower,
                upper,
                float(drone_radius),
                float(safety_margin_m) + float(robust_margin_m),
                uncertainty[step_index],
            )
            nominal_adjusted: list[float] = []
            robust_adjusted: list[float] = []
            for name, value in nominal.items():
                if name.startswith("inter_agent["):
                    first, second = name.removeprefix("inter_agent[").removesuffix("]").split(",")
                    gap = float(individual_gaps[int(first)] + individual_gaps[int(second)])
                else:
                    gap = float(individual_gaps[int(name.rsplit("/", 1)[-1])])
                nominal_adjusted.append(float(value - gap))
                robust_adjusted.append(float(robust[name] - gap))
            nominal_minimum = min(nominal_minimum, float(min(nominal_adjusted, default=float("inf"))))
            robust_minimum = min(robust_minimum, float(min(robust_adjusted, default=float("inf"))))
            sample_count += 1
    tolerance_value = float(tolerance)
    current_safe = bool(min(initial_barriers.values(), default=float("inf")) >= -tolerance_value)
    swept_safe = bool(robust_minimum >= -tolerance_value)
    violations: list[str] = []
    if not current_safe:
        violations.append("current_state_outside_safe_set")
    if not swept_safe:
        violations.append("swept_volume_outside_robust_safe_set")
    return SweptVolumeCertificateResult(
        valid=not violations,
        status="valid" if not violations else "invalid",
        current_state_safe=current_safe,
        swept_volume_safe=swept_safe,
        horizon_steps=preview_steps,
        subdivisions_per_step=int(subdivisions_per_step),
        sample_count=sample_count,
        minimum_robust_barrier_m=float(robust_minimum),
        minimum_nominal_barrier_m=float(nominal_minimum),
        violations=tuple(violations),
        assumptions={
            "dt_seconds": float(dt),
            "horizon_steps": float(preview_steps),
            "subdivisions_per_step": float(subdivisions_per_step),
            "command_noise_bound_mps": float(parameters.command_noise_bound_mps),
            "tracking_alpha": float(parameters.tracking_alpha),
            "drag_gain": float(parameters.drag_gain),
            "max_speed_mps": float(parameters.max_speed_mps),
                "max_acceleration_mps2": float(parameters.max_acceleration_mps2),
                "command_authority_mode": float(
                    {"immutable": 0, "replace_nonexecuting": 1, "flush_pending": 2}[directive.mode]
                ),
                "emergency_brake_requested": float(directive.emergency_brake),
                "queue_override_slots": float(overridden_slots),
                "reachable_tube_multiplier": float(reachable_tube_multiplier),
        },
    )


def check_execution_continuous_segment_safety(
    observation: Mapping[str, Any],
    action: np.ndarray,
    *,
    dt: float,
    drone_radius: float,
    safety_margin_m: float,
    robust_margin_m: float,
    horizon_steps: int | None = None,
    reachable_tube_multiplier: float = 1.0,
    continuous_segment_subdivisions: int = 4,
    tolerance: float = 1.0e-6,
    command_authority: CommandAuthorityDirective | Mapping[str, Any] | None = None,
) -> ContinuousSegmentCertificateResult:
    """Certify every point on each linear segment of the benchmark rollout.

    Each obstacle/boundary signed clearance is 1-Lipschitz in position. The
    pairwise separation barrier is 1-Lipschitz in relative position. The
    certificate uses the same internal-sample and local Lipschitz contract as
    the execution-aware QP, so the independent audit does not silently apply a
    different continuous-segment bound.
    """

    positions = np.asarray(observation["defender_positions"], dtype=np.float64)
    velocities = np.asarray(observation.get("defender_velocities", np.zeros_like(positions)), dtype=np.float64)
    lower = np.asarray(observation["world_lower_bounds"], dtype=np.float64)
    upper = np.asarray(observation["world_upper_bounds"], dtype=np.float64)
    obstacles = list(observation.get("obstacles", ()))
    parameters = parameters_from_observation(observation, dt)
    queue = queue_from_observation(observation, positions.shape[0])
    queue, directive, overridden_slots = apply_command_authority(
        queue,
        command_authority,
        allowed_mode=command_authority_from_observation(observation),
    )
    preview_steps = max(1, len(queue) + 1) if horizon_steps is None else int(horizon_steps)
    if preview_steps <= 0:
        raise ValueError("horizon_steps must be positive")
    rollout_positions, _rollout_velocities, _steps = rollout_execution(
        positions,
        velocities,
        queue,
        np.asarray(action, dtype=np.float64),
        parameters,
        horizon_steps=preview_steps,
    )
    uncertainty = reachable_tube_radii(
        parameters,
        positions.shape[0],
        preview_steps,
        multiplier=reachable_tube_multiplier,
    )
    effective_margin = float(safety_margin_m) + float(robust_margin_m)
    initial = _barriers(positions, obstacles, lower, upper, float(drone_radius), effective_margin)
    current_minimum = float(min(initial.values(), default=float("inf")))
    nominal_values, robust_values, _ = _continuous_segment_barrier_data(
        positions,
        rollout_positions,
        uncertainty,
        obstacles,
        lower,
        upper,
        float(drone_radius),
        effective_margin,
        continuous_segment_subdivisions=int(continuous_segment_subdivisions),
    )
    nominal_minimum = min(current_minimum, min(nominal_values.values(), default=float("inf")))
    robust_minimum = min(current_minimum, min(robust_values.values(), default=float("inf")))
    tolerance_value = float(tolerance)
    current_safe = bool(current_minimum >= -tolerance_value)
    continuous_safe = bool(robust_minimum >= -tolerance_value)
    violations: list[str] = []
    if not current_safe:
        violations.append("current_state_outside_safe_set")
    if not continuous_safe:
        violations.append("continuous_segment_outside_robust_safe_set")
    return ContinuousSegmentCertificateResult(
        valid=not violations,
        status="valid" if not violations else "invalid",
        current_state_safe=current_safe,
        continuous_segment_safe=continuous_safe,
        horizon_steps=preview_steps,
        segment_count=preview_steps * (int(continuous_segment_subdivisions) + 1),
        minimum_robust_barrier_m=float(robust_minimum),
        minimum_nominal_barrier_m=float(nominal_minimum),
        violations=tuple(violations),
        assumptions={
            "dt_seconds": float(dt),
            "horizon_steps": float(preview_steps),
            "command_noise_bound_mps": float(parameters.command_noise_bound_mps),
            "tracking_alpha": float(parameters.tracking_alpha),
            "drag_gain": float(parameters.drag_gain),
            "max_speed_mps": float(parameters.max_speed_mps),
            "max_acceleration_mps2": float(parameters.max_acceleration_mps2),
            "continuous_interpolation_contract": 1.0,
            "signed_distance_lipschitz_bound": 1.0,
            "continuous_segment_internal_samples": float(continuous_segment_subdivisions),
            "continuous_segment_subsegments": float(int(continuous_segment_subdivisions) + 1),
            "command_authority_mode": float(
                {"immutable": 0, "replace_nonexecuting": 1, "flush_pending": 2}[directive.mode]
            ),
            "emergency_brake_requested": float(directive.emergency_brake),
            "queue_override_slots": float(overridden_slots),
            "reachable_tube_multiplier": float(reachable_tube_multiplier),
        },
    )


__all__ = [
    "ContinuousSegmentCertificateResult",
    "ExecutionRecoverabilityResult",
    "ExecutionRolloutCertificateResult",
    "SafetyCertificateResult",
    "SweptVolumeCertificateResult",
    "check_execution_rollout_safety",
    "check_execution_continuous_segment_safety",
    "check_execution_swept_volume_safety",
    "check_one_step_safety",
    "assess_execution_recoverability",
    "execution_barrier_values",
    "execution_barrier_values_with_action_jacobian",
]
