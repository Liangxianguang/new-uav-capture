"""Controlled mixed-obstacle showcase scenarios for capture-radius replay.

The showcase is deliberately separate from random benchmark sampling. It gives
the renderer a reproducible, solvable central obstacle layout while preserving
the same environment dynamics and policy observation interface.
"""

from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import yaml

from .pursuit_env import CaptureRadiusPursuit3DEnv, CylinderObstacle


@dataclass(frozen=True)
class ShowcaseScenario:
    name: str
    obstacles: tuple[CylinderObstacle, ...]
    defender_positions: np.ndarray
    target_position: np.ndarray
    target_escape_direction: np.ndarray
    obstacle_zone_x: tuple[float, float]
    target_crossing_required: bool = False
    defender_side: str = "left"
    layout_seed: int | None = None
    required_defender_zone_entries: int = 1
    require_target_zone_entry: bool | None = None
    scenario_type: str = "showcase"


@dataclass(frozen=True)
class CentralCaptureProtocol:
    """Frozen parameters for the V4 central bidirectional capture task."""

    name: str
    half_extent_xy: float
    height: float
    minimum_altitude: float
    boundary_buffer: float
    capture_radius: float
    safety_margin: float
    obstacle_zone_x: tuple[float, float]
    layout: str
    defender_side: str
    initial_side_distance: float
    target_crossing_required: bool
    require_target_zone_entry: bool
    required_defender_zone_entries: int
    minimum_initial_target_defender_distance: float
    layout_seed: int
    motion_seed: int
    evaluation_seed_start: int
    detection_range: float
    target_speed_scale: float
    target_motion_mode: str
    policy_obstacle_geometry: str


def load_central_capture_protocol(path: str | Path) -> CentralCaptureProtocol:
    """Load and validate the frozen V4 central-capture task configuration."""
    source = Path(path)
    payload = yaml.safe_load(source.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Central capture protocol must be a YAML mapping.")
    world = payload.get("world")
    task_contract = payload.get("task_contract")
    scenario = payload.get("scenario")
    seed_blocks = payload.get("seed_blocks")
    runtime = payload.get("runtime")
    if not all(isinstance(value, dict) for value in (world, task_contract, scenario, seed_blocks, runtime)):
        raise ValueError(
            "Central capture protocol requires world, task_contract, scenario, seed_blocks, and runtime mappings."
        )
    try:
        protocol = CentralCaptureProtocol(
            name=str(payload["protocol_name"]),
            half_extent_xy=float(world["half_extent_xy"]),
            height=float(world["height"]),
            minimum_altitude=float(world["minimum_altitude"]),
            boundary_buffer=float(world["boundary_buffer"]),
            capture_radius=float(task_contract["capture_radius"]),
            safety_margin=float(task_contract["safety_margin"]),
            obstacle_zone_x=tuple(float(value) for value in task_contract["obstacle_zone_x"]),
            layout=str(scenario["layout"]),
            defender_side=str(scenario["defender_side"]),
            initial_side_distance=float(scenario["initial_side_distance"]),
            target_crossing_required=bool(scenario["target_crossing_required"]),
            require_target_zone_entry=bool(task_contract["require_target_zone_entry"]),
            required_defender_zone_entries=int(task_contract["required_defender_zone_entries"]),
            minimum_initial_target_defender_distance=float(
                scenario["minimum_initial_target_defender_distance"]
            ),
            layout_seed=int(seed_blocks["layout"]),
            motion_seed=int(seed_blocks["motion"]),
            evaluation_seed_start=int(seed_blocks["evaluation_start"]),
            detection_range=float(runtime["detection_range"]),
            target_speed_scale=float(runtime["target_speed_scale"]),
            target_motion_mode=str(runtime["target_motion_mode"]),
            policy_obstacle_geometry=str(runtime["policy_obstacle_geometry"]),
        )
    except (KeyError, TypeError, ValueError) as error:
        raise ValueError(f"Invalid central capture protocol: {error}") from error
    if len(protocol.obstacle_zone_x) != 2 or protocol.obstacle_zone_x[0] >= protocol.obstacle_zone_x[1]:
        raise ValueError("Protocol obstacle_zone_x must contain increasing lower and upper bounds.")
    if protocol.half_extent_xy <= 0.0 or protocol.height <= protocol.minimum_altitude:
        raise ValueError("Protocol world dimensions are invalid.")
    if not 0.0 < protocol.boundary_buffer < protocol.half_extent_xy:
        raise ValueError("Protocol boundary_buffer must lie within the world extent.")
    if protocol.capture_radius <= 0.0 or protocol.safety_margin < 0.0:
        raise ValueError("Protocol capture_radius and safety_margin are invalid.")
    if protocol.layout not in {"open", "cylinder", "box", "wall", "cylinder_box", "mixed"}:
        raise ValueError("Protocol layout is unsupported.")
    if protocol.defender_side not in {"left", "right"}:
        raise ValueError("Protocol defender_side must be left or right.")
    if protocol.initial_side_distance <= protocol.obstacle_zone_x[1]:
        raise ValueError("Protocol initial_side_distance must place agents outside the central obstacle zone.")
    if not 1 <= protocol.required_defender_zone_entries <= 4:
        raise ValueError("Protocol required_defender_zone_entries must lie in [1, 4].")
    if protocol.minimum_initial_target_defender_distance <= 0.0:
        raise ValueError("Protocol minimum initial target-defender distance must be positive.")
    if protocol.detection_range <= 0.0 or protocol.target_speed_scale <= 0.0:
        raise ValueError("Protocol runtime detection_range and target_speed_scale must be positive.")
    if protocol.target_motion_mode not in {"flee_persistence", "s_curve"}:
        raise ValueError("Protocol target_motion_mode is unsupported.")
    if protocol.policy_obstacle_geometry not in {"legacy", "shape_extents_and_type"}:
        raise ValueError("Protocol policy_obstacle_geometry is unsupported.")
    return protocol


def central_capture_protocol_metadata(protocol: CentralCaptureProtocol) -> dict[str, Any]:
    """Return a JSON-safe record of a frozen central-capture protocol."""
    metadata = asdict(protocol)
    metadata["obstacle_zone_x"] = list(protocol.obstacle_zone_x)
    return metadata


def validate_central_capture_protocol_environment(
    env: CaptureRadiusPursuit3DEnv,
    protocol: CentralCaptureProtocol,
) -> None:
    """Reject evaluations whose environment does not match frozen V4 parameters."""
    expected = (
        ("world.half_extent_xy", float(env.world["half_extent_xy"]), protocol.half_extent_xy),
        ("world.height", float(env.world["height"]), protocol.height),
        ("world.minimum_altitude", float(env.world["minimum_altitude"]), protocol.minimum_altitude),
        ("pursuit.capture_radius", float(env.pursuit["capture_radius"]), protocol.capture_radius),
        ("pursuit.safety_margin", float(env.pursuit["safety_margin"]), protocol.safety_margin),
        ("task.policy_obstacle_geometry", str(env.task.get("policy_obstacle_geometry", "legacy")), protocol.policy_obstacle_geometry),
    )
    for field, actual, required in expected:
        matches = bool(np.isclose(actual, required)) if isinstance(required, float) else actual == required
        if not matches:
            raise ValueError(f"V4 protocol mismatch for {field}: expected {required}, got {actual}.")
    if env.n_defenders < protocol.required_defender_zone_entries:
        raise ValueError("V4 protocol requires more defender zone entries than the environment provides.")


def target_crossing_pursuit_overrides() -> dict[str, float]:
    """Return the controlled target profile used by crossing-required tasks.

    The profile keeps obstacle avoidance active but makes the target's planned
    transit direction persistent enough for the pursuers to intercept it in
    the central zone.  It is a task-definition parameter, not an action hint
    exposed to the policy.
    """
    return {
        "target_heading_persistence": 4.0,
        "target_flee_gain": 0.05,
        "target_defender_avoidance_distance": 4.0,
        "target_defender_avoidance_gain": 8.0,
        # Crossing-required adaptive targets retain finite-horizon evasion,
        # but their candidate score must respect the declared transit intent.
        # This is simulator-private and is not exposed to defenders.
        "target_maneuver_crossing_gain": 12.0,
    }


def configure_target_crossing_episode(env: CaptureRadiusPursuit3DEnv) -> None:
    """Apply the frozen crossing-required target profile to one environment."""
    env.pursuit.update(target_crossing_pursuit_overrides())


def central_mixed_obstacle_scenario(
    initial_side_distance: float = 5.0,
    target_crossing_required: bool = False,
    layout: str = "mixed",
    defender_side: str = "left",
    required_defender_zone_entries: int = 1,
    require_target_zone_entry: bool | None = None,
) -> ShowcaseScenario:
    """Return a fixed, solvable S1/S2-style central obstacle layout."""
    if initial_side_distance < 4.0:
        raise ValueError("initial_side_distance must be at least 4.0 m.")
    if layout not in {"open", "cylinder", "box", "wall", "cylinder_box", "mixed"}:
        raise ValueError("layout must be one of: open, cylinder, box, wall, cylinder_box, mixed.")
    if defender_side not in {"left", "right"}:
        raise ValueError("defender_side must be either 'left' or 'right'.")
    if not 1 <= int(required_defender_zone_entries) <= 4:
        raise ValueError("required_defender_zone_entries must lie in [1, 4].")
    all_obstacles = (
        CylinderObstacle(
            center_xy=np.array([0.0, 0.0], dtype=np.float64),
            radius=1.0,
            height=5.2,
            shape="cylinder",
        ),
        CylinderObstacle(
            center_xy=np.array([0.8, 3.6], dtype=np.float64),
            radius=1.0,
            height=4.8,
            shape="box",
            half_extents_xy=np.array([1.0, 0.8], dtype=np.float64),
        ),
        CylinderObstacle(
            center_xy=np.array([0.5, -3.2], dtype=np.float64),
            radius=0.35,
            height=4.2,
            shape="wall",
            half_extents_xy=np.array([2.1, 0.35], dtype=np.float64),
        ),
    )
    obstacle_layouts = {
        "open": (),
        "cylinder": (all_obstacles[0],),
        "box": (all_obstacles[1],),
        "wall": (all_obstacles[2],),
        "cylinder_box": all_obstacles[:2],
        "mixed": all_obstacles,
    }
    obstacles = obstacle_layouts[layout]
    left_x = -float(initial_side_distance)
    right_x = float(initial_side_distance)
    defender_x = left_x if defender_side == "left" else right_x
    target_x = right_x if defender_side == "left" else left_x
    escape_sign = 1.0 if defender_side == "left" else -1.0
    # In the ordinary showcase the target escapes away from the defenders.  A
    # crossing-required scenario reverses that direction so that the target
    # must also traverse the central obstacle zone and reach the opposite side.
    target_direction_sign = -escape_sign if target_crossing_required else escape_sign
    defender_positions = np.array(
        [
            [defender_x, -2.4, 2.8],
            [defender_x, -0.8, 3.2],
            [defender_x, 0.8, 3.6],
            [defender_x, 2.4, 4.0],
        ],
        dtype=np.float64,
    )
    target_position = np.array([target_x, 0.0, 4.2], dtype=np.float64)
    direction_name = "target_crossing" if target_crossing_required else "target_evading"
    return ShowcaseScenario(
        name=f"central_{layout}_obstacles_{defender_side}_{direction_name}",
        obstacles=obstacles,
        defender_positions=defender_positions,
        target_position=target_position,
        target_escape_direction=np.array([target_direction_sign, 0.12, 0.0], dtype=np.float64),
        obstacle_zone_x=(-2.5, 3.0),
        target_crossing_required=bool(target_crossing_required),
        defender_side=defender_side,
        required_defender_zone_entries=int(required_defender_zone_entries),
        require_target_zone_entry=require_target_zone_entry,
    )


def central_capture_v4_scenario(protocol: CentralCaptureProtocol) -> ShowcaseScenario:
    """Build the fixed V4 S2 mixed-obstacle scene from its frozen protocol."""
    scenario = central_mixed_obstacle_scenario(
        initial_side_distance=protocol.initial_side_distance,
        target_crossing_required=protocol.target_crossing_required,
        layout=protocol.layout,
        defender_side=protocol.defender_side,
        required_defender_zone_entries=protocol.required_defender_zone_entries,
        require_target_zone_entry=protocol.require_target_zone_entry,
    )
    if scenario.obstacle_zone_x != protocol.obstacle_zone_x:
        raise ValueError("V4 protocol obstacle_zone_x does not match the implemented central scene.")
    positions = np.vstack([scenario.defender_positions, scenario.target_position[None, :]])
    lower = np.array(
        [-protocol.half_extent_xy, -protocol.half_extent_xy, protocol.minimum_altitude], dtype=np.float64
    )
    upper = np.array([protocol.half_extent_xy, protocol.half_extent_xy, protocol.height], dtype=np.float64)
    if np.any(positions < lower[None, :] + protocol.boundary_buffer) or np.any(
        positions > upper[None, :] - protocol.boundary_buffer
    ):
        raise ValueError("V4 initial positions violate the frozen world-boundary buffer.")
    closest_initial_distance = float(
        np.min(np.linalg.norm(scenario.defender_positions - scenario.target_position[None, :], axis=1))
    )
    if closest_initial_distance < protocol.minimum_initial_target_defender_distance:
        raise ValueError("V4 initial target-defender separation is below the frozen minimum.")
    return scenario


def _opposite_side_positions(initial_side_distance: float, defender_side: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    if initial_side_distance < 4.0:
        raise ValueError("initial_side_distance must be at least 4.0 m.")
    if defender_side not in {"left", "right"}:
        raise ValueError("defender_side must be either 'left' or 'right'.")
    defender_x = -float(initial_side_distance) if defender_side == "left" else float(initial_side_distance)
    target_x = -defender_x
    escape_sign = 1.0 if defender_side == "left" else -1.0
    return (
        np.array(
            [
                [defender_x, -2.4, 2.8],
                [defender_x, -0.8, 3.2],
                [defender_x, 0.8, 3.6],
                [defender_x, 2.4, 4.0],
            ],
            dtype=np.float64,
        ),
        np.array([target_x, 0.0, 4.2], dtype=np.float64),
        np.array([escape_sign, 0.12, 0.0], dtype=np.float64),
    )


def _random_central_obstacle(
    rng: np.random.Generator,
    shape: str,
    obstacle_zone_x: tuple[float, float],
) -> CylinderObstacle:
    """Sample one axis-aligned central obstacle with a physically recorded orientation.

    The current collision model handles axis-aligned boxes exactly.  Therefore
    a wall orientation means either 0 or 90 degrees in the x-y plane; arbitrary
    yaw is intentionally deferred until collision, clearance, sensing, and
    rendering all support it consistently.
    """
    if shape not in {"cylinder", "box", "wall"}:
        raise ValueError(f"Unsupported S3 obstacle shape: {shape}")
    height = float(rng.uniform(3.8, 6.2))
    half_extents_xy: np.ndarray | None = None
    if shape == "cylinder":
        radius = float(rng.uniform(0.72, 1.08))
        half_x = half_y = radius
    elif shape == "box":
        half_extents_xy = rng.uniform(0.70, 1.25, size=2).astype(np.float64)
        radius = float(np.max(half_extents_xy))
        half_x, half_y = map(float, half_extents_xy)
    else:
        long_extent = float(rng.uniform(1.65, 2.35))
        short_extent = float(rng.uniform(0.28, 0.42))
        half_extents_xy = (
            np.array([long_extent, short_extent], dtype=np.float64)
            if bool(rng.integers(0, 2))
            else np.array([short_extent, long_extent], dtype=np.float64)
        )
        radius = short_extent
        half_x, half_y = map(float, half_extents_xy)
    x_low, x_high = map(float, obstacle_zone_x)
    center_x = float(rng.uniform(x_low + half_x + 0.15, x_high - half_x - 0.15))
    center_y = float(rng.uniform(-6.0 + half_y, 6.0 - half_y))
    return CylinderObstacle(
        center_xy=np.array([center_x, center_y], dtype=np.float64),
        radius=radius,
        height=height,
        shape=shape,
        half_extents_xy=half_extents_xy,
    )


def random_central_mixed_obstacle_scenario(
    env: CaptureRadiusPursuit3DEnv,
    layout_seed: int,
    initial_side_distance: float = 5.0,
    defender_side: str = "left",
    target_crossing_required: bool = False,
    obstacle_count_range: tuple[int, int] = (3, 5),
    max_attempts: int = 500,
    required_defender_zone_entries: int = 1,
) -> ShowcaseScenario:
    """Sample a reproducible, valid S3 map with cylinder/box/wall obstacles.

    Every accepted map contains each required geometry at least once, stays in
    the central zone, clears all spawn positions, and has a conservative route
    for every defender to the target's initial side.  The seed fully determines
    the accepted layout, including any rejected candidate maps.
    """
    if layout_seed < 0:
        raise ValueError("layout_seed must be non-negative.")
    minimum_count, maximum_count = map(int, obstacle_count_range)
    if minimum_count < 3 or maximum_count < minimum_count:
        raise ValueError("S3 obstacle_count_range must satisfy 3 <= minimum <= maximum.")
    if max_attempts <= 0:
        raise ValueError("max_attempts must be positive.")
    if not 1 <= int(required_defender_zone_entries) <= env.n_defenders:
        raise ValueError("required_defender_zone_entries must lie in [1, n_defenders].")
    defender_positions, target_position, target_escape_direction = _opposite_side_positions(
        initial_side_distance, defender_side
    )
    if target_crossing_required:
        target_escape_direction = -target_escape_direction
    obstacle_zone_x = (-2.5, 3.0)
    protected_points = np.vstack([defender_positions, target_position[None, :]])
    rng = np.random.default_rng(layout_seed)
    for _ in range(max_attempts):
        obstacle_count = int(rng.integers(minimum_count, maximum_count + 1))
        shapes = ["cylinder", "box", "wall"]
        rng.shuffle(shapes)
        shapes.extend(str(rng.choice(["cylinder", "box", "wall"])) for _ in range(obstacle_count - 3))
        obstacles: list[CylinderObstacle] = []
        for shape in shapes:
            for _candidate_attempt in range(100):
                candidate = _random_central_obstacle(rng, shape, obstacle_zone_x)
                if not env._obstacle_clear_of_points(candidate, protected_points):
                    continue
                if any(env._obstacle_horizontal_separation(candidate, current) < 0.70 for current in obstacles):
                    continue
                obstacles.append(candidate)
                break
            else:
                break
        if len(obstacles) != obstacle_count:
            continue
        scenario = ShowcaseScenario(
            name=f"s3_random_central_mixed_{layout_seed}",
            obstacles=tuple(obstacles),
            defender_positions=defender_positions,
            target_position=target_position,
            target_escape_direction=target_escape_direction,
            obstacle_zone_x=obstacle_zone_x,
            target_crossing_required=bool(target_crossing_required),
            defender_side=defender_side,
            layout_seed=int(layout_seed),
            required_defender_zone_entries=int(required_defender_zone_entries),
        )
        try:
            validate_showcase_scenario(env, scenario)
        except ValueError:
            continue
        return scenario
    raise RuntimeError(f"Unable to sample a valid S3 map after {max_attempts} attempts (seed={layout_seed}).")


def s4_adaptive_branching_scenario(
    env: CaptureRadiusPursuit3DEnv,
    layout_seed: int,
    defender_bias: str,
    variation: dict[str, Any] | None = None,
) -> ShowcaseScenario:
    """Build a reproducible two-exit S4 pursuit-evasion scene.

    Defenders begin behind the target on the left of a near-ceiling wall. Two
    equally sized exits exist at positive and negative y. A controlled
    defender-side bias makes one exit more interceptable; the target must
    select the other from the current defender geometry rather than follow a
    pre-announced branch label. ``defender_bias`` has a mirrored companion,
    which permits paired counterfactual evaluation.
    """

    if layout_seed < 0:
        raise ValueError("S4 layout_seed must be non-negative.")
    if defender_bias not in {"upper", "lower"}:
        raise ValueError("S4 defender_bias must be 'upper' or 'lower'.")
    variation = {} if variation is None else dict(variation)
    default_ranges = {
        "wall_half_extent_x_m": (0.55, 0.55),
        "wall_half_extent_y_m": (4.25, 4.25),
        "wall_height_m": (9.45, 9.45),
        "target_initial_x_m": (-3.80, -3.80),
        "target_initial_y_m": (0.0, 0.0),
        "target_altitude_m": (5.0, 5.0),
        "defender_x_offset_m": (0.0, 0.0),
        "defender_y_scale": (1.0, 1.0),
        "defender_z_offset_m": (0.0, 0.0),
    }
    unknown_variation = sorted(set(variation).difference(default_ranges))
    if unknown_variation:
        raise ValueError("Unsupported S4 variation fields: " + ", ".join(unknown_variation))

    def sample_range(name: str, rng: np.random.Generator) -> float:
        configured = variation.get(name, default_ranges[name])
        if not isinstance(configured, (tuple, list)) or len(configured) != 2:
            raise ValueError(f"S4 variation {name} must contain exactly two values.")
        low, high = float(configured[0]), float(configured[1])
        if not np.isfinite([low, high]).all() or high < low:
            raise ValueError(f"S4 variation {name} must be finite with low <= high.")
        return float(rng.uniform(low, high))

    rng = np.random.default_rng(layout_seed)
    mirror = 1.0 if defender_bias == "upper" else -1.0
    jitter = rng.uniform(-0.16, 0.16, size=(4, 2))
    if variation:
        # The fixed S4 staging layout intentionally uses most of the left
        # workspace. Keep randomized layouts inside the same 1 m buffer.
        jitter[:, 0] = np.maximum(jitter[:, 0], -0.08)
    wall_half_x = sample_range("wall_half_extent_x_m", rng)
    wall_half_y = sample_range("wall_half_extent_y_m", rng)
    wall_height = sample_range("wall_height_m", rng)
    target_x = sample_range("target_initial_x_m", rng)
    target_y = mirror * sample_range("target_initial_y_m", rng)
    target_altitude = sample_range("target_altitude_m", rng)
    defender_x_offset = sample_range("defender_x_offset_m", rng)
    defender_y_scale = sample_range("defender_y_scale", rng)
    defender_z_offset = sample_range("defender_z_offset_m", rng)
    base_defenders = np.array(
        [
            [-8.20, 2.70, 3.50],
            [-8.55, 3.80, 6.50],
            [-8.60, -0.80, 4.00],
            [-8.85, 0.50, 6.00],
        ],
        dtype=np.float64,
    )
    defender_positions = base_defenders.copy()
    defender_positions[:, 0] += defender_x_offset + jitter[:, 0]
    defender_positions[:, 1] = mirror * (defender_positions[:, 1] * defender_y_scale + jitter[:, 1])
    defender_positions[:, 2] += defender_z_offset
    target_position = np.array([target_x, target_y, target_altitude], dtype=np.float64)
    obstacle = CylinderObstacle(
        center_xy=np.array([0.0, 0.0], dtype=np.float64),
        radius=wall_half_x,
        height=wall_height,
        shape="wall",
        half_extents_xy=np.array([wall_half_x, wall_half_y], dtype=np.float64),
    )
    scenario = ShowcaseScenario(
        name=f"s4_adaptive_branching_{defender_bias}_{layout_seed}",
        obstacles=(obstacle,),
        defender_positions=defender_positions,
        target_position=target_position,
        target_escape_direction=np.array([1.0, 0.0, 0.0], dtype=np.float64),
        obstacle_zone_x=(-wall_half_x, wall_half_x),
        defender_side="left",
        layout_seed=int(layout_seed),
        scenario_type="s4_branching",
    )
    validate_s4_branching_scenario(env, scenario)
    return scenario


def scenario_metadata(scenario: ShowcaseScenario) -> dict[str, Any]:
    """Return JSON-safe geometry and protocol metadata for a showcase scenario."""
    return {
        "name": scenario.name,
        "scenario_type": scenario.scenario_type,
        "layout_seed": scenario.layout_seed,
        "defender_side": scenario.defender_side,
        "target_crossing_required": scenario.target_crossing_required,
        "required_defender_zone_entries": scenario.required_defender_zone_entries,
        "require_target_zone_entry": scenario.require_target_zone_entry,
        "obstacle_zone_x": list(scenario.obstacle_zone_x),
        "defender_positions": scenario.defender_positions.tolist(),
        "target_position": scenario.target_position.tolist(),
        "target_escape_direction": scenario.target_escape_direction.tolist(),
        "obstacles": [
            {
                "shape": obstacle.shape,
                "center_xy": obstacle.center_xy.tolist(),
                "radius": float(obstacle.radius),
                "height": float(obstacle.height),
                "half_extents_xy": None if obstacle.half_extents_xy is None else obstacle.half_extents_xy.tolist(),
                "orientation_degrees": (
                    0.0
                    if obstacle.half_extents_xy is None or obstacle.half_extents_xy[0] >= obstacle.half_extents_xy[1]
                    else 90.0
                ),
            }
            for obstacle in scenario.obstacles
        ],
    }


def scenario_from_metadata(metadata: dict[str, Any]) -> ShowcaseScenario:
    """Restore a previously frozen scenario without re-sampling its geometry."""

    try:
        obstacles = tuple(
            CylinderObstacle(
                center_xy=np.asarray(item["center_xy"], dtype=np.float64),
                radius=float(item["radius"]),
                height=float(item["height"]),
                shape=str(item["shape"]),
                half_extents_xy=(
                    None
                    if item.get("half_extents_xy") is None
                    else np.asarray(item["half_extents_xy"], dtype=np.float64)
                ),
            )
            for item in metadata["obstacles"]
        )
        return ShowcaseScenario(
            name=str(metadata["name"]),
            obstacles=obstacles,
            defender_positions=np.asarray(metadata["defender_positions"], dtype=np.float64),
            target_position=np.asarray(metadata["target_position"], dtype=np.float64),
            target_escape_direction=np.asarray(metadata["target_escape_direction"], dtype=np.float64),
            obstacle_zone_x=tuple(float(value) for value in metadata["obstacle_zone_x"]),
            target_crossing_required=bool(metadata.get("target_crossing_required", False)),
            defender_side=str(metadata["defender_side"]),
            layout_seed=(None if metadata.get("layout_seed") is None else int(metadata["layout_seed"])),
            required_defender_zone_entries=int(metadata.get("required_defender_zone_entries", 1)),
            require_target_zone_entry=(
                None
                if metadata.get("require_target_zone_entry") is None
                else bool(metadata["require_target_zone_entry"])
            ),
            scenario_type=str(metadata.get("scenario_type", "showcase")),
        )
    except (KeyError, TypeError, ValueError) as error:
        raise ValueError("Invalid frozen showcase scenario metadata.") from error


def sample_training_episode(
    env: CaptureRadiusPursuit3DEnv,
    settings: dict[str, Any],
    rng: np.random.Generator,
    seed: int,
    progress: float,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Sample an original random episode or a staged central-layout episode.

    ``progress`` is normalized to ``[0, 1]``.  This permits the same curriculum
    definition to drive behavior cloning (episode progress) and MAPPO
    fine-tuning (environment-step progress).
    """
    if not 0.0 <= progress <= 1.0:
        raise ValueError("training progress must lie in [0, 1].")
    # A MAPPO environment is reused across episodes. Restore its frozen base
    # sensing contract before applying the current curriculum-stage overrides,
    # so a late noisy stage cannot leak into an earlier or fallback episode.
    base_pursuit = getattr(env, "_training_base_pursuit", None)
    if base_pursuit is None:
        base_pursuit = dict(env.pursuit)
        setattr(env, "_training_base_pursuit", base_pursuit)
    env.pursuit.clear()
    env.pursuit.update(base_pursuit)

    stage: dict[str, Any] = {}
    stages = settings.get("training_showcase_stages", [])
    if stages:
        if not isinstance(stages, list) or not all(isinstance(item, dict) for item in stages):
            raise ValueError("training_showcase_stages must be a list of mappings.")
        selected = next((item for item in stages if progress <= float(item["until_progress"])), None)
        if selected is None:
            selected = stages[-1]
        stage = dict(selected)
    probability = float(stage.get("showcase_probability", settings.get("training_showcase_probability", 0.0)))
    if not 0.0 <= probability <= 1.0:
        raise ValueError("showcase_probability must lie in [0, 1].")
    layouts = stage.get("layouts", settings.get("training_showcase_layouts", ["mixed"]))
    distances = stage.get(
        "initial_side_distances", settings.get("training_showcase_initial_side_distances", [5.0])
    )
    defender_sides = stage.get("defender_sides", settings.get("training_showcase_defender_sides", ["left"]))
    speeds = stage.get("target_speed_scales", settings.get("training_target_speed_scales", [0.55]))
    crossing_speeds = stage.get(
        "target_crossing_speed_scales",
        settings.get("training_target_crossing_speed_scales", speeds),
    )
    target_motion_modes = stage.get("target_motion_modes", settings.get("training_target_motion_modes", ["flee_persistence"]))
    randomized_probability = float(
        stage.get("randomized_central_probability", settings.get("training_randomized_central_probability", 0.0))
    )
    randomized_obstacle_count_range = tuple(
        int(value)
        for value in stage.get(
            "randomized_obstacle_count_range",
            settings.get("training_randomized_obstacle_count_range", [3, 5]),
        )
    )
    target_crossing_probability = float(stage.get("target_crossing_probability", 0.0))
    pursuit_overrides = stage.get("pursuit_overrides", {})
    layout_overrides = stage.get("layout_overrides", {})
    required_defender_zone_entries = int(
        stage.get("required_defender_zone_entries", settings.get("training_required_defender_zone_entries", 1))
    )
    if not isinstance(layouts, list) or not layouts:
        raise ValueError("Showcase layouts must be a non-empty list.")
    if not isinstance(distances, list) or not distances:
        raise ValueError("Showcase initial_side_distances must be a non-empty list.")
    if not isinstance(defender_sides, list) or not defender_sides:
        raise ValueError("Showcase defender_sides must be a non-empty list.")
    if not isinstance(speeds, list) or not speeds:
        raise ValueError("Showcase target_speed_scales must be a non-empty list.")
    if not isinstance(crossing_speeds, list) or not crossing_speeds:
        raise ValueError("Showcase target_crossing_speed_scales must be a non-empty list.")
    if not isinstance(target_motion_modes, list) or not target_motion_modes:
        raise ValueError("Showcase target_motion_modes must be a non-empty list.")
    if not 0.0 <= target_crossing_probability <= 1.0:
        raise ValueError("target_crossing_probability must lie in [0, 1].")
    if not 0.0 <= randomized_probability <= 1.0:
        raise ValueError("randomized_central_probability must lie in [0, 1].")
    if not isinstance(pursuit_overrides, dict):
        raise ValueError("pursuit_overrides must be a mapping when provided.")
    if not isinstance(layout_overrides, dict):
        raise ValueError("layout_overrides must be a mapping when provided.")
    unknown_layouts = sorted(set(layout_overrides).difference(str(layout) for layout in layouts))
    if unknown_layouts:
        raise ValueError("layout_overrides contains layouts not enabled by this stage: " + ", ".join(unknown_layouts))
    allowed_layout_override_fields = {
        "initial_side_distances",
        "defender_sides",
        "target_speed_scales",
        "target_motion_modes",
        "target_crossing_probability",
        "target_crossing_speed_scales",
    }
    for layout_name, override in layout_overrides.items():
        if not isinstance(override, dict):
            raise ValueError(f"layout_overrides.{layout_name} must be a mapping.")
        unknown_fields = sorted(set(override).difference(allowed_layout_override_fields))
        if unknown_fields:
            raise ValueError(
                f"layout_overrides.{layout_name} contains unsupported field(s): " + ", ".join(unknown_fields)
            )
        for field in (
            "initial_side_distances",
            "defender_sides",
            "target_speed_scales",
            "target_motion_modes",
            "target_crossing_speed_scales",
        ):
            if field in override and (not isinstance(override[field], list) or not override[field]):
                raise ValueError(f"layout_overrides.{layout_name}.{field} must be a non-empty list.")
        if "target_crossing_probability" in override and not 0.0 <= float(override["target_crossing_probability"]) <= 1.0:
            raise ValueError(f"layout_overrides.{layout_name}.target_crossing_probability must lie in [0, 1].")
    unknown_pursuit_keys = sorted(set(pursuit_overrides).difference(env.pursuit))
    if unknown_pursuit_keys:
        raise ValueError(
            "pursuit_overrides contains unknown pursuit setting(s): "
            + ", ".join(unknown_pursuit_keys)
        )
    if not 1 <= required_defender_zone_entries <= env.n_defenders:
        raise ValueError("required_defender_zone_entries must lie in [1, n_defenders].")
    if len(randomized_obstacle_count_range) != 2 or not 3 <= randomized_obstacle_count_range[0] <= randomized_obstacle_count_range[1]:
        raise ValueError("randomized_obstacle_count_range must satisfy 3 <= low <= high.")
    env.pursuit.update(pursuit_overrides)
    if rng.random() < randomized_probability:
        side_distance = float(rng.choice(np.asarray(distances, dtype=np.float64)))
        defender_side = str(rng.choice(defender_sides))
        target_speed_scale = float(rng.choice(np.asarray(speeds, dtype=np.float64)))
        target_motion_mode = str(rng.choice(target_motion_modes))
        target_crossing_required = bool(rng.random() < target_crossing_probability)
        if target_crossing_required:
            target_speed_scale = float(rng.choice(np.asarray(crossing_speeds, dtype=np.float64)))
        layout_seed = int(seed) + 1_000_000 + int(rng.integers(0, 100_000))
        scenario = random_central_mixed_obstacle_scenario(
            env,
            layout_seed=layout_seed,
            initial_side_distance=side_distance,
            defender_side=defender_side,
            target_crossing_required=target_crossing_required,
            obstacle_count_range=randomized_obstacle_count_range,
            required_defender_zone_entries=required_defender_zone_entries,
        )
        env.obstacle_count = len(scenario.obstacles)
        env.target_speed_scale = target_speed_scale
        env.pursuit["target_motion_mode"] = target_motion_mode
        if scenario.target_crossing_required:
            configure_target_crossing_episode(env)
        observation = prepare_showcase_episode(env, scenario, seed=seed, record_history=False)
        return observation, {
            "episode_kind": "randomized_showcase",
            "layout": "random_mixed",
            "layout_seed": layout_seed,
            "obstacle_count": len(scenario.obstacles),
            "defender_side": defender_side,
            "target_crossing_required": scenario.target_crossing_required,
            "initial_side_distance": side_distance,
            "target_speed_scale": target_speed_scale,
            "target_motion_mode": target_motion_mode,
            "required_defender_zone_entries": required_defender_zone_entries,
            "obstacle_zone_x": list(scenario.obstacle_zone_x),
            "pursuit_overrides": dict(pursuit_overrides),
            "progress": progress,
        }
    if rng.random() < probability:
        layout = str(rng.choice(layouts))
        layout_override = dict(layout_overrides.get(layout, {}))
        layout_distances = layout_override.get("initial_side_distances", distances)
        layout_speeds = layout_override.get("target_speed_scales", speeds)
        layout_defender_sides = layout_override.get("defender_sides", defender_sides)
        layout_motion_modes = layout_override.get("target_motion_modes", target_motion_modes)
        layout_crossing_probability = float(
            layout_override.get("target_crossing_probability", target_crossing_probability)
        )
        layout_crossing_speeds = layout_override.get("target_crossing_speed_scales", crossing_speeds)
        side_distance = float(rng.choice(np.asarray(layout_distances, dtype=np.float64)))
        target_speed_scale = float(rng.choice(np.asarray(layout_speeds, dtype=np.float64)))
        defender_side = str(rng.choice(layout_defender_sides))
        target_motion_mode = str(rng.choice(layout_motion_modes))
        target_crossing_required = bool(rng.random() < layout_crossing_probability)
        if target_crossing_required:
            target_speed_scale = float(rng.choice(np.asarray(layout_crossing_speeds, dtype=np.float64)))
        scenario = central_mixed_obstacle_scenario(
            side_distance,
            target_crossing_required=target_crossing_required,
            layout=layout,
            defender_side=defender_side,
            required_defender_zone_entries=required_defender_zone_entries,
        )
        env.obstacle_count = len(scenario.obstacles)
        env.target_speed_scale = target_speed_scale
        env.pursuit["target_motion_mode"] = target_motion_mode
        if scenario.target_crossing_required:
            configure_target_crossing_episode(env)
        observation = prepare_showcase_episode(env, scenario, seed=seed, record_history=False)
        return observation, {
            "episode_kind": "showcase",
            "layout": layout,
            "defender_side": defender_side,
            "target_crossing_required": scenario.target_crossing_required,
            "layout_seed": None,
            "obstacle_count": len(scenario.obstacles),
            "initial_side_distance": side_distance,
            "target_speed_scale": target_speed_scale,
            "target_motion_mode": target_motion_mode,
            "required_defender_zone_entries": required_defender_zone_entries,
            "obstacle_zone_x": list(scenario.obstacle_zone_x),
            "pursuit_overrides": dict(pursuit_overrides),
            "layout_sampling_override": layout_override,
            "progress": progress,
        }
    env.obstacle_count = int(rng.choice(np.asarray(settings["training_obstacle_counts"], dtype=np.int64)))
    env.target_speed_scale = float(rng.choice(np.asarray(settings["training_target_speed_scales"], dtype=np.float64)))
    env.pursuit["target_motion_mode"] = str(rng.choice(target_motion_modes))
    return env.reset(seed=seed), {
        "episode_kind": "random",
        "layout": str(env.pursuit["obstacle_profile"]),
        "defender_side": None,
        "target_crossing_required": None,
        "layout_seed": None,
        "obstacle_count": int(env.obstacle_count),
        "initial_side_distance": None,
        "target_speed_scale": env.target_speed_scale,
        "target_motion_mode": str(env.pursuit["target_motion_mode"]),
        "required_defender_zone_entries": None,
        "obstacle_zone_x": None,
        "pursuit_overrides": dict(pursuit_overrides),
        "progress": progress,
    }


def _within_bounds(env: CaptureRadiusPursuit3DEnv, positions: np.ndarray) -> bool:
    return bool(np.all(positions >= env.lower[None, :]) and np.all(positions <= env.upper[None, :]))


def _obstacle_x_extent(obstacle: CylinderObstacle) -> tuple[float, float]:
    """Return the full axis-aligned horizontal x extent used by collision checks."""
    half_x = float(obstacle.radius) if obstacle.half_extents_xy is None else float(obstacle.half_extents_xy[0])
    return float(obstacle.center_xy[0] - half_x), float(obstacle.center_xy[0] + half_x)


def _planar_route(
    env: CaptureRadiusPursuit3DEnv,
    start: np.ndarray,
    goal: np.ndarray,
    obstacles: tuple[CylinderObstacle, ...],
    grid_step: float = 0.5,
) -> list[np.ndarray] | None:
    """Plan a conservative horizontal route at the shared route altitude.

    The planner intentionally reasons with the same obstacle-clearance routine
    as the environment and inflates every obstacle by the drone radius plus
    safety margin.  It is used only to reject invalid central showcase maps;
    it is not exposed to an actor or used as a pursuit action.
    """
    half_extent = float(env.world["half_extent_xy"])
    minimum_clearance = float(env.pursuit["safety_margin"]) + float(env.agents["drone_radius"])
    low = -half_extent + minimum_clearance
    high = half_extent - minimum_clearance
    count = int(round((high - low) / grid_step)) + 1

    def to_index(value: float) -> int:
        return int(np.clip(round((value - low) / grid_step), 0, count - 1))

    def to_point(index: tuple[int, int]) -> np.ndarray:
        return np.array([low + index[0] * grid_step, low + index[1] * grid_step, goal[2]], dtype=np.float64)

    def segment_is_clear(first: np.ndarray, second: np.ndarray) -> bool:
        distance = float(np.linalg.norm(second - first))
        samples = max(int(np.ceil(distance / max(grid_step * 0.25, 1e-9))), 1)
        for fraction in np.linspace(0.0, 1.0, samples + 1):
            point = first + float(fraction) * (second - first)
            if any(env._obstacle_clearance(point, obstacle) < minimum_clearance for obstacle in obstacles):
                return False
        return True

    start_index = (to_index(float(start[0])), to_index(float(start[1])))
    goal_index = (to_index(float(goal[0])), to_index(float(goal[1])))
    blocked: set[tuple[int, int]] = set()
    for ix in range(count):
        for iy in range(count):
            point = to_point((ix, iy))
            if any(env._obstacle_clearance(point, obstacle) < minimum_clearance for obstacle in obstacles):
                blocked.add((ix, iy))
    if start_index in blocked or goal_index in blocked:
        return None
    if not segment_is_clear(start, to_point(start_index)) or not segment_is_clear(to_point(goal_index), goal):
        return None
    queue: deque[tuple[int, int]] = deque([start_index])
    parents: dict[tuple[int, int], tuple[int, int] | None] = {start_index: None}
    while queue:
        current = queue.popleft()
        if current == goal_index:
            indices: list[tuple[int, int]] = []
            while current is not None:
                indices.append(current)
                current = parents[current]
            points = [start.copy(), *(to_point(index) for index in reversed(indices)), goal.copy()]
            route: list[np.ndarray] = []
            for point in points:
                if not route or not np.allclose(point, route[-1]):
                    route.append(point)
            return route
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)):
            neighbor = (current[0] + dx, current[1] + dy)
            if not (0 <= neighbor[0] < count and 0 <= neighbor[1] < count):
                continue
            if neighbor in parents or neighbor in blocked:
                continue
            if not segment_is_clear(to_point(current), to_point(neighbor)):
                continue
            parents[neighbor] = current
            queue.append(neighbor)
    return None


def _planar_route_exists(
    env: CaptureRadiusPursuit3DEnv,
    start: np.ndarray,
    goal: np.ndarray,
    obstacles: tuple[CylinderObstacle, ...],
    grid_step: float = 0.5,
) -> bool:
    """Return whether the conservative grid planner can connect two points."""
    return _planar_route(env, start, goal, obstacles, grid_step=grid_step) is not None


def transit_endpoints(scenario: ShowcaseScenario) -> tuple[np.ndarray, np.ndarray]:
    """Return opposite-side endpoints for independent agent transit checks."""
    defender_goals = scenario.defender_positions.copy()
    defender_goals[:, 0] = float(scenario.target_position[0])
    target_goal = scenario.target_position.copy()
    target_goal[0] = float(np.mean(scenario.defender_positions[:, 0]))
    return defender_goals, target_goal


def transit_route_metrics(
    env: CaptureRadiusPursuit3DEnv,
    scenario: ShowcaseScenario,
    grid_step: float = 0.5,
) -> dict[str, Any]:
    """Verify independent, conservative left-to-right and right-to-left routes.

    This is deliberately separate from a capture rollout.  A capture episode
    terminates as soon as an interceptor reaches the target, so it cannot also
    prove that every participant would later reach the far side.  These route
    checks establish that the generated map has safe traversable paths for the
    target and for each defender without changing the pursuit objective.
    """
    defender_goals, target_goal = transit_endpoints(scenario)
    defender_routes = [
        _planar_route(env, start, goal, scenario.obstacles, grid_step=grid_step)
        for start, goal in zip(scenario.defender_positions, defender_goals, strict=True)
    ]
    target_route = _planar_route(
        env,
        scenario.target_position,
        target_goal,
        scenario.obstacles,
        grid_step=grid_step,
    )

    def route_length(route: list[np.ndarray] | None) -> float | None:
        if route is None:
            return None
        if len(route) < 2:
            return 0.0
        return float(np.sum(np.linalg.norm(np.diff(np.asarray(route), axis=0), axis=1)))

    def route_min_clearance(route: list[np.ndarray] | None) -> float | None:
        if route is None:
            return None
        clearances = [
            float(env._obstacle_clearance(point, obstacle))
            for point in route
            for obstacle in scenario.obstacles
        ]
        return float(min(clearances)) if clearances else float("inf")

    defender_feasible = [route is not None for route in defender_routes]
    return {
        "transit_grid_step_m": float(grid_step),
        "defender_transit_route_feasible": defender_feasible,
        "all_defenders_transit_route_feasible": bool(all(defender_feasible)),
        "target_transit_route_feasible": bool(target_route is not None),
        "transit_route_feasible": bool(all(defender_feasible) and target_route is not None),
        "defender_transit_route_length_m": [route_length(route) for route in defender_routes],
        "target_transit_route_length_m": route_length(target_route),
        "defender_transit_min_clearance_m": [route_min_clearance(route) for route in defender_routes],
        "target_transit_min_clearance_m": route_min_clearance(target_route),
        "defender_transit_goals": defender_goals.tolist(),
        "target_transit_goal": target_goal.tolist(),
    }


def _execute_transit_route(
    env: CaptureRadiusPursuit3DEnv,
    route: list[np.ndarray] | None,
    *,
    max_speed: float,
    max_acceleration: float,
) -> dict[str, Any]:
    """Execute one planned route under the benchmark's velocity kinematics.

    The subject is simulated independently.  This intentionally tests whether
    a single drone/target can traverse the central map, not whether five
    bodies can negotiate the same narrow channel simultaneously.  Multi-agent
    separation remains a separate requirement of the capture rollout and CBF.
    """
    if route is None:
        return {
            "success": False,
            "reason": "no_conservative_route",
            "steps": 0,
            "minimum_clearance_m": None,
            "boundary_violation": False,
        }
    if len(route) < 2:
        return {
            "success": True,
            "reason": "completed",
            "steps": 0,
            "minimum_clearance_m": float("inf"),
            "boundary_violation": False,
        }
    position = route[0].copy()
    velocity = np.zeros(3, dtype=np.float64)
    radius = float(env.agents["drone_radius"])
    safety_margin = float(env.pursuit["safety_margin"])
    clearance_limit = radius + safety_margin
    waypoint_index = 1
    step_limit = max(100, int(np.ceil(sum(np.linalg.norm(second - first) for first, second in zip(route, route[1:])) / max(max_speed * env.dt, 1e-9))) * 8)
    minimum_clearance = float("inf")
    boundary_violation = False

    def segment_clearance(first: np.ndarray, second: np.ndarray) -> float:
        distance = float(np.linalg.norm(second - first))
        samples = max(int(np.ceil(distance / max(0.05, max_speed * env.dt * 0.25))), 1)
        values = [
            float(env._obstacle_clearance(first + float(fraction) * (second - first), obstacle))
            for fraction in np.linspace(0.0, 1.0, samples + 1)
            for obstacle in env.obstacles
        ]
        return float(min(values)) if values else float("inf")

    for step in range(1, step_limit + 1):
        target_waypoint = route[waypoint_index]
        delta = target_waypoint - position
        distance = float(np.linalg.norm(delta))
        desired = np.zeros(3, dtype=np.float64) if distance < 1e-9 else delta / distance * max_speed
        velocity = env._move_toward_velocity(
            velocity[None, :], desired[None, :], max_delta=max_acceleration * env.dt
        )[0]
        candidate = position + velocity * env.dt
        # Clamp only after the finite-acceleration motion would overshoot a
        # waypoint. The segment leading to that waypoint is checked below.
        if float(np.dot(candidate - target_waypoint, position - target_waypoint)) <= 0.0:
            candidate = target_waypoint.copy()
            velocity.fill(0.0)
        minimum_clearance = min(minimum_clearance, segment_clearance(position, candidate))
        if np.any(candidate < env.lower + radius + safety_margin) or np.any(
            candidate > env.upper - radius - safety_margin
        ):
            boundary_violation = True
            return {
                "success": False,
                "reason": "boundary_violation",
                "steps": step,
                "minimum_clearance_m": float(minimum_clearance),
                "boundary_violation": True,
            }
        if minimum_clearance < clearance_limit:
            return {
                "success": False,
                "reason": "obstacle_clearance_violation",
                "steps": step,
                "minimum_clearance_m": float(minimum_clearance),
                "boundary_violation": boundary_violation,
            }
        position = candidate
        if np.allclose(position, target_waypoint, atol=1e-9):
            waypoint_index += 1
            if waypoint_index == len(route):
                return {
                    "success": True,
                    "reason": "completed",
                    "steps": step,
                    "minimum_clearance_m": float(minimum_clearance),
                    "boundary_violation": boundary_violation,
                }
    return {
        "success": False,
        "reason": "timeout",
        "steps": step_limit,
        "minimum_clearance_m": float(minimum_clearance),
        "boundary_violation": boundary_violation,
    }


def transit_execution_metrics(
    env: CaptureRadiusPursuit3DEnv,
    scenario: ShowcaseScenario,
    grid_step: float = 0.5,
) -> dict[str, Any]:
    """Run reproducible independent transit rollouts for all five subjects."""
    defender_goals, target_goal = transit_endpoints(scenario)
    defender_routes = [
        _planar_route(env, start, goal, scenario.obstacles, grid_step=grid_step)
        for start, goal in zip(scenario.defender_positions, defender_goals, strict=True)
    ]
    target_route = _planar_route(
        env,
        scenario.target_position,
        target_goal,
        scenario.obstacles,
        grid_step=grid_step,
    )
    defender_runs = [
        _execute_transit_route(
            env,
            route,
            max_speed=float(env.agents["defender_max_speed"]),
            max_acceleration=float(env.agents["defender_max_acceleration"]),
        )
        for route in defender_routes
    ]
    target_run = _execute_transit_route(
        env,
        target_route,
        max_speed=float(env.agents["target_max_speed"]),
        max_acceleration=float(env.agents["target_max_acceleration"]),
    )
    defender_success = [bool(run["success"]) for run in defender_runs]
    return {
        "defender_transit_success": defender_success,
        "all_defenders_transit_success": bool(all(defender_success)),
        "target_transit_success": bool(target_run["success"]),
        "transit_success": bool(all(defender_success) and target_run["success"]),
        "defender_transit_steps": [int(run["steps"]) for run in defender_runs],
        "target_transit_steps": int(target_run["steps"]),
        "defender_transit_reasons": [str(run["reason"]) for run in defender_runs],
        "target_transit_reason": str(target_run["reason"]),
        "defender_transit_execution_min_clearance_m": [run["minimum_clearance_m"] for run in defender_runs],
        "target_transit_execution_min_clearance_m": target_run["minimum_clearance_m"],
    }


def s4_branch_route_metrics(
    env: CaptureRadiusPursuit3DEnv,
    scenario: ShowcaseScenario,
    grid_step: float = 0.5,
) -> dict[str, Any]:
    """Check conservative access to both S4 exits for all participants."""

    waypoint_x = float(env.pursuit["target_branch_waypoint_x"])
    exit_offset_y = float(env.pursuit["target_branch_exit_offset_y"])
    goal_x = float(env.pursuit["target_branch_goal_x"])

    def route_through_waypoints(start: np.ndarray, waypoints: list[np.ndarray]) -> list[list[np.ndarray] | None]:
        current = np.asarray(start, dtype=np.float64)
        routes: list[list[np.ndarray] | None] = []
        for waypoint in waypoints:
            route = _planar_route(env, current, waypoint, scenario.obstacles, grid_step=grid_step)
            routes.append(route)
            if route is None:
                break
            current = waypoint
        return routes

    target_routes: dict[str, list[list[np.ndarray] | None]] = {}
    defender_routes: dict[str, list[list[list[np.ndarray] | None]]] = {}
    for sign, name in ((-1, "lower"), (1, "upper")):
        target_waypoints = [
            np.array([-waypoint_x, sign * exit_offset_y, scenario.target_position[2]], dtype=np.float64),
            np.array([waypoint_x, sign * exit_offset_y, scenario.target_position[2]], dtype=np.float64),
            np.array([goal_x, sign * exit_offset_y, scenario.target_position[2]], dtype=np.float64),
        ]
        target_routes[name] = route_through_waypoints(scenario.target_position, target_waypoints)
        defender_routes[name] = []
        for defender_position in scenario.defender_positions:
            defender_waypoints = [
                np.array([-waypoint_x, sign * exit_offset_y, defender_position[2]], dtype=np.float64),
                np.array([waypoint_x, sign * exit_offset_y, defender_position[2]], dtype=np.float64),
            ]
            defender_routes[name].append(route_through_waypoints(defender_position, defender_waypoints))

    def routes_complete(routes: list[list[np.ndarray] | None], expected_count: int) -> bool:
        return len(routes) == expected_count and all(route is not None for route in routes)

    def route_length(routes: list[list[np.ndarray] | None]) -> float | None:
        if not all(route is not None for route in routes):
            return None
        return float(
            sum(
                np.sum(np.linalg.norm(np.diff(np.asarray(route), axis=0), axis=1))
                for route in routes
                if route is not None and len(route) > 1
            )
        )

    target_feasible = {name: routes_complete(routes, 3) for name, routes in target_routes.items()}
    defender_feasible = {
        name: [routes_complete(routes, 2) for routes in per_defender]
        for name, per_defender in defender_routes.items()
    }
    return {
        "branch_grid_step_m": float(grid_step),
        "target_branch_route_feasible": target_feasible,
        "defender_branch_route_feasible": defender_feasible,
        "target_branch_route_length_m": {
            name: route_length(routes) for name, routes in target_routes.items()
        },
        "defender_branch_route_length_m": {
            name: [route_length(routes) for routes in per_defender]
            for name, per_defender in defender_routes.items()
        },
        "branch_route_feasible": bool(
            all(target_feasible.values())
            and all(all(values) for values in defender_feasible.values())
        ),
    }


def validate_s4_branching_scenario(env: CaptureRadiusPursuit3DEnv, scenario: ShowcaseScenario) -> None:
    """Reject an S4 wall layout unless both exits are safely traversable."""

    if scenario.scenario_type != "s4_branching":
        raise ValueError("S4 branching validation requires scenario_type='s4_branching'.")
    if scenario.defender_positions.shape != (env.n_defenders, 3):
        raise ValueError("S4 scenario must provide one 3D position per defender.")
    if scenario.target_position.shape != (3,):
        raise ValueError("S4 scenario target_position must have shape (3,).")
    low, high = map(float, scenario.obstacle_zone_x)
    if not low < high:
        raise ValueError("S4 obstacle zone must have increasing bounds.")
    if np.any(scenario.defender_positions[:, 0] >= low) or scenario.target_position[0] >= low:
        raise ValueError("S4 defenders and target must start left of the central wall.")
    all_positions = np.vstack([scenario.defender_positions, scenario.target_position[None, :]])
    if not _within_bounds(env, all_positions):
        raise ValueError("S4 initial positions must stay inside the world bounds.")
    boundary_buffer = 1.0
    if np.any(all_positions < env.lower[None, :] + boundary_buffer) or np.any(
        all_positions > env.upper[None, :] - boundary_buffer
    ):
        raise ValueError("S4 initial positions must preserve the 1.0 m world-boundary buffer.")
    pairwise = np.linalg.norm(
        scenario.defender_positions[:, None, :] - scenario.defender_positions[None, :, :], axis=2
    ) + np.eye(env.n_defenders) * 1e6
    if float(np.min(pairwise)) < 2.0 * float(env.agents["drone_radius"]):
        raise ValueError("S4 defenders overlap at initialization.")
    walls = [obstacle for obstacle in scenario.obstacles if obstacle.shape == "wall"]
    if len(walls) != 1 or len(scenario.obstacles) != 1:
        raise ValueError("S4 requires exactly one central wall obstacle.")
    wall = walls[0]
    wall_low, wall_high = _obstacle_x_extent(wall)
    if wall_low < low - 1e-9 or wall_high > high + 1e-9:
        raise ValueError("S4 wall must remain inside its declared central zone.")
    if wall.half_extents_xy is None or float(wall.half_extents_xy[1]) <= 0.0:
        raise ValueError("S4 wall must define a positive y half extent.")
    if float(wall.height) < float(env.upper[2]) - boundary_buffer:
        raise ValueError("S4 wall must be high enough to prevent a boundary-buffered overflight.")
    clearance_limit = float(env.agents["drone_radius"]) + float(env.pursuit["safety_margin"])
    if any(env._obstacle_clearance(position, wall) < clearance_limit for position in all_positions):
        raise ValueError("S4 wall is too close to an initial agent position.")
    if float(env.pursuit["target_branch_exit_offset_y"]) <= float(wall.half_extents_xy[1]) + clearance_limit:
        raise ValueError("S4 exits do not clear the wall and safety margin.")
    if abs(float(env.pursuit["target_branch_exit_offset_y"])) > float(env.upper[1]) - boundary_buffer:
        raise ValueError("S4 exits violate the world-boundary buffer.")
    if float(env.pursuit["target_branch_goal_x"]) <= wall_high + clearance_limit:
        raise ValueError("S4 target goal must lie beyond the central wall.")
    routes = s4_branch_route_metrics(env, scenario)
    if not bool(routes["branch_route_feasible"]):
        raise ValueError("S4 does not provide conservative routes through both exits for all participants.")


def validate_showcase_scenario(env: CaptureRadiusPursuit3DEnv, scenario: ShowcaseScenario) -> None:
    """Reject out-of-bounds, overlapping, or unreachable showcase maps."""
    if scenario.defender_positions.shape != (env.n_defenders, 3):
        raise ValueError("Showcase scenario must provide one 3D position per defender.")
    if scenario.target_position.shape != (3,):
        raise ValueError("Showcase scenario target_position must have shape (3,).")
    if not 1 <= scenario.required_defender_zone_entries <= env.n_defenders:
        raise ValueError("Showcase scenario required_defender_zone_entries is invalid.")
    low, high = map(float, scenario.obstacle_zone_x)
    if not low < high:
        raise ValueError("Showcase obstacle zone must have increasing bounds.")
    if scenario.defender_side == "left":
        if np.any(scenario.defender_positions[:, 0] >= low) or scenario.target_position[0] <= high:
            raise ValueError("Left-side defender scenario must place defenders and target on opposite obstacle-zone sides.")
    elif scenario.defender_side == "right":
        if np.any(scenario.defender_positions[:, 0] <= high) or scenario.target_position[0] >= low:
            raise ValueError("Right-side defender scenario must place defenders and target on opposite obstacle-zone sides.")
    else:
        raise ValueError("Showcase scenario defender_side is invalid.")
    all_positions = np.vstack([scenario.defender_positions, scenario.target_position[None, :]])
    if not _within_bounds(env, all_positions):
        raise ValueError("Showcase initial positions must stay inside the world bounds.")
    boundary_buffer = 1.0
    if np.any(all_positions < env.lower[None, :] + boundary_buffer) or np.any(
        all_positions > env.upper[None, :] - boundary_buffer
    ):
        raise ValueError("Showcase initial positions must preserve the 1.0 m world-boundary buffer.")
    if np.min(np.linalg.norm(scenario.defender_positions[:, None, :] - scenario.defender_positions[None, :, :], axis=2) + np.eye(env.n_defenders) * 1e6) < 2.0 * float(env.agents["drone_radius"]):
        raise ValueError("Showcase defenders overlap at initialization.")
    for obstacle in scenario.obstacles:
        obstacle_low, obstacle_high = _obstacle_x_extent(obstacle)
        if obstacle_low < low or obstacle_high > high:
            raise ValueError("Showcase obstacles must remain entirely inside the central obstacle zone.")
        if any(env._obstacle_clearance(position, obstacle) < float(env.pursuit["safety_margin"]) + float(env.agents["drone_radius"]) for position in all_positions):
            raise ValueError("Showcase obstacle is too close to an initial agent position.")
    for defender_index, defender_position in enumerate(scenario.defender_positions):
        if not _planar_route_exists(env, defender_position, scenario.target_position, scenario.obstacles):
            raise ValueError(f"Showcase map has no conservative route for defender {defender_index}.")
    transit = transit_route_metrics(env, scenario)
    if not bool(transit["transit_route_feasible"]):
        raise ValueError("Showcase map does not provide independent conservative transit routes for all participants.")


def prepare_showcase_episode(
    env: CaptureRadiusPursuit3DEnv,
    scenario: ShowcaseScenario,
    seed: int,
    record_history: bool = True,
    validate_scenario: bool = True,
) -> dict[str, Any]:
    """Reset an environment and replace its random map with a fixed scenario."""
    env.reset(seed=seed, record_history=False)
    if validate_scenario:
        if scenario.scenario_type == "s4_branching":
            validate_s4_branching_scenario(env, scenario)
        elif scenario.scenario_type == "showcase":
            validate_showcase_scenario(env, scenario)
        else:
            raise ValueError(f"Unsupported showcase scenario type: {scenario.scenario_type}")
    env.defender_positions = scenario.defender_positions.copy()
    env.defender_velocities.fill(0.0)
    env.target_position = scenario.target_position.copy()
    env.target_velocity.fill(0.0)
    env.target_escape_direction = scenario.target_escape_direction / max(
        np.linalg.norm(scenario.target_escape_direction), 1e-9
    )
    env.target_branch_sign = None
    env.target_branch_decision_step = None
    env.target_branch_scores.fill(np.nan)
    env.obstacles = list(scenario.obstacles)
    env.step_count = 0
    env.history = []
    env.target_belief_positions.fill(0.0)
    env.target_belief_velocities.fill(0.0)
    env.target_observation_confidence.fill(0.0)
    env.target_observation_timestamps.fill(-1)
    env.target_observation_covariance[:] = np.eye(3, dtype=np.float64)[None, :, :] * float(
        env.pursuit["observation_covariance_growth"]
    )
    env.message_age_steps[:] = int(env.pursuit["maximum_message_age_steps"])
    env.detection_loss_burst_remaining.fill(0)
    env._belief_history = []
    env._update_target_beliefs()
    if record_history:
        env._record_history()
    return env.observe()


def crossing_metrics(
    env: CaptureRadiusPursuit3DEnv,
    obstacle_zone_x: tuple[float, float],
) -> dict[str, Any]:
    """Measure zone entry and completion of a start-to-opposite-side crossing.

    A trajectory is only marked as ``crossed`` after it reaches beyond the
    opposite edge of the central zone.  This prevents a short incursion into
    the zone from being reported as a completed obstacle traversal.
    """
    if not env.history:
        raise ValueError("Cannot compute crossing metrics without trajectory history.")
    low, high = map(float, obstacle_zone_x)
    defender_trace = np.asarray([frame["defender_positions"] for frame in env.history], dtype=np.float64)
    target_trace = np.asarray([frame["target_position"] for frame in env.history], dtype=np.float64)
    defender_initial_x = defender_trace[0, :, 0]
    defender_in_zone = (defender_trace[:, :, 0] >= low) & (defender_trace[:, :, 0] <= high)
    defender_zone_entered = np.any(defender_in_zone, axis=0)
    defender_zone_entry_count = int(np.sum(defender_zone_entered))
    defender_crossed = np.where(
        defender_initial_x <= low,
        np.any(defender_trace[:, :, 0] > high, axis=0),
        np.any(defender_trace[:, :, 0] < low, axis=0),
    )
    target_initial_x = float(target_trace[0, 0])
    target_in_zone = (target_trace[:, 0] >= low) & (target_trace[:, 0] <= high)
    target_zone_entered = bool(np.any(target_in_zone))
    target_crossed = bool(
        np.any(target_trace[:, 0] > high)
        if target_initial_x <= low
        else np.any(target_trace[:, 0] < low)
    )
    steps = np.asarray([int(frame.get("step", index)) for index, frame in enumerate(env.history)], dtype=np.int64)

    def first_step(mask: np.ndarray) -> int | None:
        indices = np.flatnonzero(mask)
        return int(steps[indices[0]]) if indices.size else None

    return {
        "obstacle_zone_x": [low, high],
        "defender_zone_entered": defender_zone_entered.astype(bool).tolist(),
        "defender_crossed": defender_crossed.astype(bool).tolist(),
        "defender_zone_entry_rate": float(np.mean(defender_zone_entered)),
        "defender_zone_entry_count": defender_zone_entry_count,
        "defender_crossing_rate": float(np.mean(defender_crossed)),
        "any_defender_zone_entered": bool(np.any(defender_zone_entered)),
        "all_defenders_zone_entered": bool(np.all(defender_zone_entered)),
        "all_defenders_crossed": bool(np.all(defender_crossed)),
        "defender_first_zone_entry_steps": [first_step(defender_in_zone[:, index]) for index in range(env.n_defenders)],
        "target_zone_entered": target_zone_entered,
        "target_crossed": target_crossed,
        "target_zone_entry_rate": float(target_zone_entered),
        "target_crossing_rate": float(target_crossed),
        "target_first_zone_entry_step": first_step(target_in_zone),
    }


def capture_contract_metrics(
    final_info: dict[str, Any],
    crossing: dict[str, Any],
    *,
    target_collision: bool = False,
    target_crossing_required: bool = False,
    required_defender_zone_entries: int = 1,
    require_target_zone_entry: bool | None = None,
) -> dict[str, Any]:
    """Apply a central-obstacle capture contract to one finished rollout."""
    if required_defender_zone_entries < 1:
        raise ValueError("required_defender_zone_entries must be positive.")
    capture_event = bool(final_info.get("capture_event", False))
    safe_capture = bool(final_info.get("safe_capture_success", False)) and not target_collision
    defender_zone_entry_count = int(
        crossing.get(
            "defender_zone_entry_count",
            sum(bool(value) for value in crossing.get("defender_zone_entered", [])),
        )
    )
    if not defender_zone_entry_count and bool(crossing.get("any_defender_zone_entered", False)):
        defender_zone_entry_count = 1
    target_zone_entry_required = (
        bool(target_crossing_required) if require_target_zone_entry is None else bool(require_target_zone_entry)
    )
    defender_requirement_met = defender_zone_entry_count >= required_defender_zone_entries
    target_requirement_met = not target_zone_entry_required or bool(crossing.get("target_zone_entered", False))
    central_encounter = bool(
        defender_requirement_met and target_requirement_met
    )
    safe_capture_in_pursuit = bool(safe_capture and central_encounter)
    if target_collision:
        task_termination_reason = "target_safety_failure"
    elif safe_capture_in_pursuit:
        task_termination_reason = "safe_capture_in_pursuit"
    elif capture_event:
        task_termination_reason = "capture_without_zone_entry"
    else:
        task_termination_reason = str(final_info.get("termination_reason", "running"))
    return {
        "central_encounter": central_encounter,
        "safe_capture_in_pursuit": safe_capture_in_pursuit,
        "cooperative_safe_capture": safe_capture_in_pursuit,
        "capture_without_zone_entry": bool(capture_event and not central_encounter),
        "target_crossing_required": bool(target_crossing_required),
        "target_zone_entry_required": target_zone_entry_required,
        "defender_zone_entry_count": defender_zone_entry_count,
        "required_defender_zone_entries": int(required_defender_zone_entries),
        "defender_zone_entry_requirement_met": defender_requirement_met,
        "task_termination_reason": task_termination_reason,
    }


def target_min_clearance(env: CaptureRadiusPursuit3DEnv) -> float:
    """Return the minimum target-to-obstacle clearance over the recorded run."""
    if not env.history:
        raise ValueError("Cannot compute target clearance without trajectory history.")
    clearances = []
    for frame in env.history:
        position = np.asarray(frame["target_position"], dtype=np.float64)
        clearances.extend(float(env._obstacle_clearance(position, obstacle)) for obstacle in env.obstacles)
    return float(min(clearances)) if clearances else float("inf")
