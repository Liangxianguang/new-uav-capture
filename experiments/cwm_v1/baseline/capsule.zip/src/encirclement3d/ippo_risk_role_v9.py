"""Per-agent risk attribution and reachable local-belief waypoints."""
import numpy as np
from .ippo_risk_role_repair import slots as nominal_slots
from .observation_encoding import policy_observations as original_observations
from .pursuit_env import CaptureRadiusPursuit3DEnv

def point_clearance(env, position):
    erosion=float(env.agents['drone_radius'])+float(env.pursuit['defender_boundary_margin'])
    boundary=min(np.min(position-env.lower-erosion),np.min(env.upper-erosion-position))
    obstacle=min((env._obstacle_clearance(position,o)-float(env.agents['drone_radius']) for o in env.obstacles),default=float('inf'))
    return min(boundary,obstacle)

def segment_safe(env,start,end):
    count=max(2,int(np.ceil(np.linalg.norm(end-start)/.25))+1)
    return all(point_clearance(env,x)>=.15 for x in np.linspace(start,end,count))

def slots(env,obs):
    desired=nominal_slots(env,obs); positions=np.asarray(obs['defender_positions']); result=[]
    directions=np.array([(x,y,z) for x in [-1,0,1] for y in [-1,0,1] for z in [-1,0,1] if (x,y,z)!=(0,0,0)],dtype=float)
    directions/=np.linalg.norm(directions,axis=1)[:,None]
    for start,goal in zip(positions,desired):
        if segment_safe(env,start,goal): result.append(goal); continue
        candidates=[start+d*radius for radius in [1.5,3.] for d in directions]
        viable=[x for x in candidates if segment_safe(env,start,x)]
        # A local waypoint reduces goal distance; it never commands an action.
        result.append(min(viable,key=lambda x:np.linalg.norm(x-goal)+.15*np.linalg.norm(x-start)) if viable else start)
    return np.asarray(result)

def policy_observations(env,observation=None,*,route_helper=None):
    obs=env.observe() if observation is None else observation
    base=original_observations(env,obs,route_helper=route_helper)
    return np.concatenate([base,(slots(env,obs)-np.asarray(obs['defender_positions']))/float(env.world['half_extent_xy']),np.eye(4)],axis=1).astype(np.float32)

class RepairEnv(CaptureRadiusPursuit3DEnv):
    def step(self,defender_actions,*args,**kwargs):
        before=self.observe(); positions=self.defender_positions.copy()
        velocities=self._clip_rows(np.asarray(defender_actions,dtype=float),float(self.agents['defender_max_speed']))
        old=-np.minimum(np.linalg.norm(positions-slots(self,before),axis=1),16.)/16.
        risks=np.zeros((4,3)); erosion=float(self.agents['drone_radius'])+float(self.pursuit['defender_boundary_margin'])
        for t in np.linspace(0.,.5,6):
            future=positions+t*velocities
            for i in range(4):
                clearance=min(np.min(future[i]-self.lower-erosion),np.min(self.upper-erosion-future[i]))
                risks[i,0]=max(risks[i,0],float(np.clip(1.-clearance,0,1)))
                for j in range(4):
                    if j!=i:
                        net=np.linalg.norm(future[i]-future[j])-2*float(self.agents['drone_radius'])
                        risks[i,1]=max(risks[i,1],float(np.clip(1.-net,0,1)))
                for obstacle in self.obstacles:
                    net=self._obstacle_clearance(future[i],obstacle)-float(self.agents['drone_radius'])
                    risks[i,2]=max(risks[i,2],float(np.clip(1.-net,0,1)))
        obs,reward,terminated,truncated,info=super().step(defender_actions,*args,**kwargs)
        new=np.zeros(4) if terminated else -np.minimum(np.linalg.norm(self.defender_positions-slots(self,obs),axis=1),16.)/16.
        progress=2*(.99*new-old); shaping=-.5*risks.sum(axis=1)+progress
        info['agent_rewards']=(reward+shaping).tolist()
        info['agent_predictive_risks']=risks.tolist()
        info['reward_components'].update({
            'predictive_boundary':float(-.5*risks[:,0].mean()),'predictive_team':float(-.5*risks[:,1].mean()),
            'predictive_obstacle':float(-.5*risks[:,2].mean()),'role_progress':float(progress.mean())})
        return obs,float(reward+shaping.mean()),terminated,truncated,info
