"""Exact sampled-action likelihood and post-update diagnostics for V9."""
import math
import torch
from torch.distributions import Normal
from .learning import RecurrentSharedActorCritic


class ExactRecurrentIPPO(RecurrentSharedActorCritic):
    @staticmethod
    def _squashed_log_probability(distribution, raw_actions):
        jacobian = 2 * (math.log(2) - raw_actions - torch.nn.functional.softplus(-2 * raw_actions))
        return distribution.log_prob(raw_actions) - jacobian

    def evaluate_actions_sequence(self, local_observations, initial_hidden, reset_masks,
                                  scaled_actions, action_scale, pre_tanh_actions=None):
        if pre_tanh_actions is None:
            raise ValueError('V9 requires original pre-tanh samples; inverse-tanh is forbidden.')
        frames, entropies, means = [], [], []
        # Exactly match rollout's four-agent CUDA matrix shape for every episode.
        for episode in range(local_observations.shape[0]):
            hidden = initial_hidden[episode]
            lp, ent, mu = [], [], []
            for t in range(local_observations.shape[1]):
                distribution, hidden = self.distribution_step(
                    local_observations[episode, t], hidden, reset_masks[episode, t])
                lp.append(self._squashed_log_probability(distribution, pre_tanh_actions[episode, t]).sum(-1))
                ent.append(distribution.entropy().sum(-1))
                mu.append(distribution.mean)
            frames.append(torch.stack(lp)); entropies.append(torch.stack(ent)); means.append(torch.stack(mu))
        return torch.stack(frames), torch.stack(entropies), torch.stack(means)


@torch.no_grad()
def snapshot(policy, batch, action_scale):
    local = batch['local']
    initial = torch.zeros((local.shape[0], local.shape[2], policy.hidden_dim), device=local.device)
    reset = torch.zeros(local.shape[:2], device=local.device)
    lp, _, means = policy.evaluate_actions_sequence(
        local, initial, reset, batch['action'], action_scale,
        pre_tanh_actions=batch['pre_tanh_action'])
    return lp, means, policy.log_std.detach().clone()


def update_with_kl(update_fn, policy, optimizer, batch, algorithm, action_scale,
                   epochs, minibatch, clip_range, recurrent=False, entropy_coef=.01, diagnostics=None):
    if not recurrent:
        raise ValueError('V9 requires recurrent policies.')
    diagnostics = {} if diagnostics is None else diagnostics
    old_lp, old_mean, old_logstd = snapshot(policy, batch, action_scale)
    valid = batch['valid']
    frame_valid = valid[..., 0] if valid.ndim == 3 else valid
    reproduced = old_lp if algorithm == 'ippo' else old_lp.sum(-1)
    error = ((reproduced - batch['old_log_prob']).abs() * valid).max()
    diagnostics['old_logp_reproduction_max_abs'] = float(error)
    if not torch.isfinite(error) or error > .01:
        raise RuntimeError(f'V9 pre-update reproduction failed: {float(error):.9g} > 0.01; optimizer untouched.')
    ratio=(reproduced-batch['old_log_prob']).exp()
    count_valid=valid.sum().clamp_min(1)
    diagnostics.update(ratio_mean=float((ratio*valid).sum()/count_valid),
                       ratio_max_abs_delta=float(((ratio-1).abs()*valid).max()),
                       approx_kl=float(((batch['old_log_prob']-reproduced)*valid).sum()/count_valid),
                       clip_fraction=float((((ratio-1).abs()>clip_range)*valid).sum()/count_valid))
    loss = update_fn(policy, optimizer, batch, algorithm, action_scale, epochs, minibatch,
                     clip_range, recurrent=recurrent, entropy_coef=entropy_coef, diagnostics=diagnostics)
    new_lp, new_mean, new_logstd = snapshot(policy, batch, action_scale)
    # Exact KL of Gaussian policies; tanh is a common invertible transform.
    kl = (new_logstd-old_logstd +
          (old_logstd.exp().square()+(old_mean-new_mean).square()) /
          (2*new_logstd.exp().square()) - .5).sum(-1)
    count = frame_valid.sum().clamp_min(1)
    diagnostics['post_update_kl_joint_mean'] = float((kl.sum(-1)*frame_valid).sum()/count)
    diagnostics['post_update_kl_per_agent_mean'] = float((kl*frame_valid[..., None]).sum()/(count*local_agents(batch)))
    diagnostics['post_update_kl_joint_max'] = float((kl.sum(-1)*frame_valid).max())
    delta = new_lp.sum(-1)-old_lp.sum(-1)
    agent_delta = new_lp-old_lp
    diagnostics['post_update_clip_fraction_per_agent'] = float((((agent_delta.exp()-1).abs()>clip_range)*frame_valid[...,None]).sum()/(count*local_agents(batch)))
    diagnostics['post_update_log_ratio_abs_max'] = float((delta.abs()*frame_valid).max())
    diagnostics['post_update_clip_fraction'] = float((((delta.exp()-1).abs()>clip_range)*frame_valid).sum()/count)
    if not all(math.isfinite(v) for k,v in diagnostics.items() if k.startswith('post_update_')):
        raise RuntimeError('Non-finite post-update policy diagnostics; stop before next rollout.')
    return loss


def local_agents(batch):
    return batch['local'].shape[2]
