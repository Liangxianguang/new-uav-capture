"""Small, dependency-light adapters for GitHub MARL compatibility smokes.

These implementations intentionally exercise the defining optimization and
network contracts of MAT, HAPPO, MACPO, and MASAC without pretending to be
full benchmark training runs.  They use only PyTorch so the repository's
existing CUDA environment does not need the upstream projects' legacy
MuJoCo/Gym dependency stacks.
"""

from __future__ import annotations

import copy
import math
from dataclasses import dataclass
from typing import Any, Callable

import numpy as np
import torch
from torch import nn
from torch.distributions import Normal
from torch.nn import functional as F


Tensor = torch.Tensor


@dataclass
class RolloutBatch:
    """Transitions collected from frozen Phase86 scene records."""

    local: Tensor
    state: Tensor
    action: Tensor
    old_log_prob: Tensor
    reward: Tensor
    cost: Tensor
    next_local: Tensor
    next_state: Tensor
    done: Tensor
    # Preserve the sampled pre-tanh action: in float32, tanh can round to +/-1,
    # so reconstructing it later with atanh is not a faithful likelihood check.
    raw_action: Tensor | None = None
    # MAT conditions later agents on earlier sampled actions. Keep those proposals
    # distinct from any action transformed by an optional safety filter.
    policy_action: Tensor | None = None


def _mlp(input_dim: int, hidden_dim: int, output_dim: int) -> nn.Sequential:
    return nn.Sequential(
        nn.Linear(input_dim, hidden_dim),
        nn.ReLU(),
        nn.Linear(hidden_dim, hidden_dim),
        nn.ReLU(),
        nn.Linear(hidden_dim, output_dim),
    )


def _finite_float(value: Tensor | float) -> float:
    result = float(value.detach().cpu()) if isinstance(value, Tensor) else float(value)
    if not math.isfinite(result):
        raise RuntimeError(f"Non-finite optimization diagnostic: {result}")
    return result


def parameter_vector(module: nn.Module) -> Tensor:
    return torch.cat([parameter.detach().reshape(-1) for parameter in module.parameters()])


def parameter_delta(before: Tensor, module: nn.Module) -> float:
    return _finite_float(torch.linalg.vector_norm(parameter_vector(module) - before))


def grad_norm(module: nn.Module) -> float:
    gradients = [
        parameter.grad.detach().reshape(-1)
        for parameter in module.parameters()
        if parameter.grad is not None
    ]
    if not gradients:
        return 0.0
    return _finite_float(torch.linalg.vector_norm(torch.cat(gradients)))


def generalized_advantage(
    reward: Tensor,
    value: Tensor,
    next_value: Tensor,
    done: Tensor,
    *,
    gamma: float = 0.99,
    gae_lambda: float = 0.95,
) -> tuple[Tensor, Tensor]:
    advantage = torch.zeros_like(reward)
    running = torch.zeros((), dtype=reward.dtype, device=reward.device)
    for index in range(reward.shape[0] - 1, -1, -1):
        nonterminal = 1.0 - done[index]
        delta = reward[index] + gamma * nonterminal * next_value[index] - value[index]
        running = delta + gamma * gae_lambda * nonterminal * running
        advantage[index] = running
    return advantage, advantage + value


def normalize(values: Tensor) -> Tensor:
    return (values - values.mean()) / (values.std(unbiased=False) + 1.0e-6)


class SquashedGaussianActor(nn.Module):
    """Continuous local actor shared by the HAPPO and MACPO adapters."""

    def __init__(self, observation_dim: int, action_dim: int = 3, hidden_dim: int = 128) -> None:
        super().__init__()
        self.body = _mlp(observation_dim, hidden_dim, hidden_dim)
        self.mean = nn.Linear(hidden_dim, action_dim)
        self.log_std = nn.Parameter(torch.full((action_dim,), -1.0))
        nn.init.uniform_(self.mean.weight, -0.01, 0.01)
        nn.init.zeros_(self.mean.bias)

    def distribution(self, observation: Tensor) -> Normal:
        latent = self.body(observation)
        mean = self.mean(latent)
        std = self.log_std.clamp(-5.0, 2.0).exp().expand_as(mean)
        return Normal(mean, std)

    @staticmethod
    def _log_prob(distribution: Normal, raw_action: Tensor, action_scale: float) -> Tensor:
        squashed = torch.tanh(raw_action)
        correction = torch.log(torch.clamp(1.0 - squashed.square(), min=1.0e-6))
        scale_term = math.log(max(action_scale, 1.0e-8))
        return (distribution.log_prob(raw_action) - correction - scale_term).sum(dim=-1)

    def sample(self, observation: Tensor, action_scale: float) -> tuple[Tensor, Tensor]:
        action, log_prob, _raw_action = self.sample_with_raw_action(observation, action_scale)
        return action, log_prob

    def sample_with_raw_action(
        self, observation: Tensor, action_scale: float
    ) -> tuple[Tensor, Tensor, Tensor]:
        distribution = self.distribution(observation)
        raw_action = distribution.rsample()
        return (
            torch.tanh(raw_action) * action_scale,
            self._log_prob(distribution, raw_action, action_scale),
            raw_action,
        )

    def log_prob_from_raw(
        self, observation: Tensor, raw_action: Tensor, action_scale: float
    ) -> Tensor:
        return self._log_prob(self.distribution(observation), raw_action, action_scale)

    def log_prob(self, observation: Tensor, action: Tensor, action_scale: float) -> Tensor:
        normalized = torch.clamp(action / action_scale, -0.999999, 0.999999)
        raw_action = torch.atanh(normalized)
        return self._log_prob(self.distribution(observation), raw_action, action_scale)

    def entropy(self, observation: Tensor) -> Tensor:
        return self.distribution(observation).entropy().sum(dim=-1)


class ValueNetwork(nn.Module):
    def __init__(self, state_dim: int, hidden_dim: int = 128) -> None:
        super().__init__()
        self.net = _mlp(state_dim, hidden_dim, 1)

    def forward(self, state: Tensor) -> Tensor:
        return self.net(state).squeeze(-1)


class MultiAgentTransformer(nn.Module):
    """MAT-style encoder plus autoregressive continuous-action decoder."""

    def __init__(
        self,
        observation_dim: int,
        n_agents: int = 4,
        action_dim: int = 3,
        hidden_dim: int = 128,
        heads: int = 4,
    ) -> None:
        super().__init__()
        self.n_agents = n_agents
        self.action_dim = action_dim
        self.observation_projection = nn.Linear(observation_dim, hidden_dim)
        self.agent_embedding = nn.Embedding(n_agents, hidden_dim)
        encoder_layer = nn.TransformerEncoderLayer(
            hidden_dim,
            heads,
            dim_feedforward=2 * hidden_dim,
            dropout=0.0,
            batch_first=True,
            norm_first=True,
        )
        decoder_layer = nn.TransformerDecoderLayer(
            hidden_dim,
            heads,
            dim_feedforward=2 * hidden_dim,
            dropout=0.0,
            batch_first=True,
            norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=2)
        self.action_projection = nn.Linear(action_dim, hidden_dim)
        self.decoder = nn.TransformerDecoder(decoder_layer, num_layers=2)
        self.action_mean = nn.Linear(hidden_dim, action_dim)
        self.action_log_std = nn.Parameter(torch.full((action_dim,), -1.0))
        self.value_head = nn.Linear(hidden_dim, 1)
        nn.init.uniform_(self.action_mean.weight, -0.01, 0.01)
        nn.init.zeros_(self.action_mean.bias)

    def encode(self, observation: Tensor) -> Tensor:
        if observation.ndim != 3 or observation.shape[1] != self.n_agents:
            raise ValueError("MAT expects observations shaped [batch, agents, features].")
        agent_ids = torch.arange(self.n_agents, device=observation.device)
        tokens = self.observation_projection(observation) + self.agent_embedding(agent_ids)[None]
        return self.encoder(tokens)

    def _distribution(self, memory: Tensor, shifted_action: Tensor) -> Normal:
        agent_ids = torch.arange(self.n_agents, device=memory.device)
        decoder_tokens = self.action_projection(shifted_action) + self.agent_embedding(agent_ids)[None]
        causal_mask = torch.triu(
            torch.full((self.n_agents, self.n_agents), float("-inf"), device=memory.device),
            diagonal=1,
        )
        decoded = self.decoder(decoder_tokens, memory, tgt_mask=causal_mask)
        mean = self.action_mean(decoded)
        std = self.action_log_std.clamp(-5.0, 2.0).exp().view(1, 1, -1).expand_as(mean)
        return Normal(mean, std)

    def value(self, observation: Tensor) -> Tensor:
        return self.value_head(self.encode(observation)).squeeze(-1).mean(dim=1)

    def sample(self, observation: Tensor, action_scale: float) -> tuple[Tensor, Tensor]:
        actions, log_probs, _raw_actions = self.sample_with_raw_action(observation, action_scale)
        return actions, log_probs

    def sample_with_raw_action(
        self, observation: Tensor, action_scale: float
    ) -> tuple[Tensor, Tensor, Tensor]:
        memory = self.encode(observation)
        actions = torch.zeros(
            observation.shape[0], self.n_agents, self.action_dim, device=observation.device
        )
        raw_actions = torch.zeros_like(actions)
        log_probs: list[Tensor] = []
        for agent_index in range(self.n_agents):
            shifted = torch.zeros_like(actions)
            if agent_index > 0:
                shifted[:, 1 : agent_index + 1] = actions[:, :agent_index] / action_scale
            distribution = self._distribution(memory, shifted)
            raw_action = distribution.rsample()[:, agent_index]
            action = torch.tanh(raw_action) * action_scale
            actions[:, agent_index] = action
            raw_actions[:, agent_index] = raw_action
            log_probs.append(
                SquashedGaussianActor._log_prob(
                    Normal(distribution.loc[:, agent_index], distribution.scale[:, agent_index]),
                    raw_action,
                    action_scale,
                )
            )
        return actions, torch.stack(log_probs, dim=1), raw_actions

    def evaluate_actions(
        self,
        observation: Tensor,
        action: Tensor,
        action_scale: float,
        raw_action: Tensor | None = None,
    ) -> tuple[Tensor, Tensor]:
        memory = self.encode(observation)
        shifted = torch.zeros_like(action)
        shifted[:, 1:] = action[:, :-1] / action_scale
        distribution = self._distribution(memory, shifted)
        if raw_action is None:
            raw_action = torch.atanh(torch.clamp(action / action_scale, -0.999999, 0.999999))
        log_prob = SquashedGaussianActor._log_prob(distribution, raw_action, action_scale)
        entropy = distribution.entropy().sum(dim=-1)
        return log_prob, entropy


def update_mat(
    policy: MultiAgentTransformer,
    batch: RolloutBatch,
    action_scale: float,
    *,
    learning_rate: float = 3.0e-4,
    optimizer: torch.optim.Optimizer | None = None,
) -> dict[str, Any]:
    before = parameter_vector(policy)
    if optimizer is None:
        optimizer = torch.optim.Adam(policy.parameters(), lr=learning_rate)
    with torch.no_grad():
        values = policy.value(batch.local)
        next_values = policy.value(batch.next_local)
        advantage, returns = generalized_advantage(
            batch.reward, values, next_values, batch.done
        )
    normalized_advantage = normalize(advantage)
    behavior_action = batch.policy_action if batch.policy_action is not None else batch.action
    log_prob, entropy = policy.evaluate_actions(
        batch.local, behavior_action, action_scale, raw_action=batch.raw_action
    )
    joint_log_prob = log_prob.sum(dim=1)
    old_joint_log_prob = batch.old_log_prob.sum(dim=1)
    old_logp_reproduction_error = _finite_float(
        (joint_log_prob.detach() - old_joint_log_prob).abs().max()
    )
    if old_logp_reproduction_error > 1.0e-2:
        raise RuntimeError(
            "MAT sampled and recomputed joint log probabilities disagree: "
            f"max_abs_error={old_logp_reproduction_error:.6g}."
        )
    ratio = torch.exp(joint_log_prob - old_joint_log_prob)
    clipped = torch.clamp(ratio, 0.8, 1.2) * normalized_advantage
    actor_loss = -torch.minimum(ratio * normalized_advantage, clipped).mean()
    critic_loss = F.mse_loss(policy.value(batch.local), returns)
    loss = actor_loss + 0.5 * critic_loss - 0.01 * entropy.sum(dim=1).mean()
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    torch.nn.utils.clip_grad_norm_(policy.parameters(), 0.5)
    update_grad_norm = grad_norm(policy)
    optimizer.step()
    return {
        "loss": _finite_float(loss),
        "actor_loss": _finite_float(actor_loss),
        "critic_loss": _finite_float(critic_loss),
        "entropy": _finite_float(entropy.sum(dim=1).mean()),
        "grad_norm": update_grad_norm,
        "parameter_delta_l2": parameter_delta(before, policy),
        "old_logp_reproduction_max_abs": old_logp_reproduction_error,
        "ratio_mean": _finite_float(ratio.mean()),
        "architecture_contract": "attention_encoder_autoregressive_continuous_decoder",
    }


class HAPPOPolicy(nn.Module):
    def __init__(self, observation_dim: int, state_dim: int, n_agents: int = 4) -> None:
        super().__init__()
        self.actors = nn.ModuleList(
            [SquashedGaussianActor(observation_dim) for _ in range(n_agents)]
        )
        self.critic = ValueNetwork(state_dim)

    def sample(self, observation: Tensor, action_scale: float) -> tuple[Tensor, Tensor]:
        actions, log_probs, _raw_actions = self.sample_with_raw_action(observation, action_scale)
        return actions, log_probs

    def sample_with_raw_action(
        self, observation: Tensor, action_scale: float
    ) -> tuple[Tensor, Tensor, Tensor]:
        samples = [
            actor.sample_with_raw_action(observation[:, index], action_scale)
            for index, actor in enumerate(self.actors)
        ]
        return (
            torch.stack([item[0] for item in samples], dim=1),
            torch.stack([item[1] for item in samples], dim=1),
            torch.stack([item[2] for item in samples], dim=1),
        )


def update_happo(
    policy: HAPPOPolicy,
    batch: RolloutBatch,
    action_scale: float,
    *,
    seed: int,
    learning_rate: float = 3.0e-4,
    actor_optimizers: list[torch.optim.Optimizer] | None = None,
    critic_optimizer: torch.optim.Optimizer | None = None,
) -> dict[str, Any]:
    before = parameter_vector(policy)
    with torch.no_grad():
        values = policy.critic(batch.state)
        next_values = policy.critic(batch.next_state)
        advantage, returns = generalized_advantage(
            batch.reward, values, next_values, batch.done
        )
    normalized_advantage = normalize(advantage)
    if critic_optimizer is None:
        critic_optimizer = torch.optim.Adam(policy.critic.parameters(), lr=learning_rate)
    critic_loss = F.mse_loss(policy.critic(batch.state), returns)
    critic_optimizer.zero_grad(set_to_none=True)
    critic_loss.backward()
    critic_gradient = grad_norm(policy.critic)
    critic_optimizer.step()

    generator = torch.Generator(device="cpu").manual_seed(seed)
    order = torch.randperm(len(policy.actors), generator=generator).tolist()
    factor = torch.ones_like(normalized_advantage)
    actor_losses: list[float] = []
    actor_gradients: list[float] = []
    ratio_means: list[float] = []
    if actor_optimizers is None:
        actor_optimizers = [
            torch.optim.Adam(actor.parameters(), lr=learning_rate)
            for actor in policy.actors
        ]
    if len(actor_optimizers) != len(policy.actors):
        raise ValueError("HAPPO requires one persistent optimizer per agent actor.")
    for agent_index in order:
        actor = policy.actors[agent_index]
        optimizer = actor_optimizers[agent_index]
        actor_log_prob = (
            (lambda: actor.log_prob_from_raw(
                batch.local[:, agent_index], batch.raw_action[:, agent_index], action_scale
            ))
            if batch.raw_action is not None
            else (lambda: actor.log_prob(
                batch.local[:, agent_index], batch.action[:, agent_index], action_scale
            ))
        )
        with torch.no_grad():
            before_log_prob = actor_log_prob()
        new_log_prob = actor_log_prob()
        ratio = torch.exp(new_log_prob - batch.old_log_prob[:, agent_index])
        surrogate = torch.minimum(
            ratio * normalized_advantage,
            torch.clamp(ratio, 0.8, 1.2) * normalized_advantage,
        )
        entropy = actor.entropy(batch.local[:, agent_index]).mean()
        actor_loss = -(factor * surrogate).mean() - 0.01 * entropy
        optimizer.zero_grad(set_to_none=True)
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(actor.parameters(), 0.5)
        actor_gradients.append(grad_norm(actor))
        optimizer.step()
        with torch.no_grad():
            after_log_prob = actor_log_prob()
            factor = factor * torch.exp(after_log_prob - before_log_prob)
        actor_losses.append(_finite_float(actor_loss))
        ratio_means.append(_finite_float(ratio.mean()))

    return {
        "loss": float(np.mean(actor_losses)) + _finite_float(critic_loss),
        "actor_loss": float(np.mean(actor_losses)),
        "critic_loss": _finite_float(critic_loss),
        "grad_norm": float(max(actor_gradients + [critic_gradient])),
        "parameter_delta_l2": parameter_delta(before, policy),
        "agent_update_order": order,
        "sequential_factor_min": _finite_float(factor.min()),
        "sequential_factor_max": _finite_float(factor.max()),
        "ratio_mean": float(np.mean(ratio_means)),
        "optimization_contract": "sequential_agent_ppo_with_multiplicative_factor",
    }


def _flat_grad(
    output: Tensor,
    parameters: list[nn.Parameter],
    *,
    retain_graph: bool = False,
    create_graph: bool = False,
) -> Tensor:
    gradients = torch.autograd.grad(
        output,
        parameters,
        retain_graph=retain_graph,
        create_graph=create_graph,
        allow_unused=True,
    )
    return torch.cat(
        [
            (torch.zeros_like(parameter) if gradient is None else gradient).reshape(-1)
            for parameter, gradient in zip(parameters, gradients)
        ]
    )


def _set_parameter_vector(module: nn.Module, vector: Tensor) -> None:
    offset = 0
    with torch.no_grad():
        for parameter in module.parameters():
            count = parameter.numel()
            parameter.copy_(vector[offset : offset + count].view_as(parameter))
            offset += count


def _conjugate_gradient(
    matrix_vector: Callable[[Tensor], Tensor],
    right_hand_side: Tensor,
    *,
    steps: int = 10,
) -> Tensor:
    solution = torch.zeros_like(right_hand_side)
    residual = right_hand_side.clone()
    direction = residual.clone()
    residual_dot = torch.dot(residual, residual)
    for _ in range(steps):
        product = matrix_vector(direction)
        alpha = residual_dot / (torch.dot(direction, product) + 1.0e-8)
        solution = solution + alpha * direction
        residual = residual - alpha * product
        next_residual_dot = torch.dot(residual, residual)
        if next_residual_dot < 1.0e-12:
            break
        direction = residual + (next_residual_dot / (residual_dot + 1.0e-8)) * direction
        residual_dot = next_residual_dot
    return solution


class MACPOPolicy(nn.Module):
    def __init__(self, observation_dim: int, state_dim: int) -> None:
        super().__init__()
        self.actor = SquashedGaussianActor(observation_dim)
        self.reward_critic = ValueNetwork(state_dim)
        self.cost_critic = ValueNetwork(state_dim)

    def sample(self, observation: Tensor, action_scale: float) -> tuple[Tensor, Tensor]:
        action, log_prob, _raw_action = self.sample_with_raw_action(observation, action_scale)
        return action, log_prob

    def sample_with_raw_action(
        self, observation: Tensor, action_scale: float
    ) -> tuple[Tensor, Tensor, Tensor]:
        shape = observation.shape
        action, log_prob, raw_action = self.actor.sample_with_raw_action(
            observation.reshape(-1, shape[-1]), action_scale
        )
        return (
            action.reshape(shape[0], shape[1], -1),
            log_prob.reshape(shape[0], shape[1]),
            raw_action.reshape(shape[0], shape[1], -1),
        )


def update_macpo(
    policy: MACPOPolicy,
    batch: RolloutBatch,
    action_scale: float,
    *,
    learning_rate: float = 3.0e-4,
    cost_limit: float = 0.25,
    max_kl: float = 0.01,
    critic_optimizer: torch.optim.Optimizer | None = None,
) -> dict[str, Any]:
    before_all = parameter_vector(policy)
    if critic_optimizer is None:
        critic_optimizer = torch.optim.Adam(
            list(policy.reward_critic.parameters()) + list(policy.cost_critic.parameters()),
            lr=learning_rate,
        )
    with torch.no_grad():
        reward_values = policy.reward_critic(batch.state)
        next_reward_values = policy.reward_critic(batch.next_state)
        reward_advantage, reward_returns = generalized_advantage(
            batch.reward, reward_values, next_reward_values, batch.done
        )
        cost_values = policy.cost_critic(batch.state)
        next_cost_values = policy.cost_critic(batch.next_state)
        cost_advantage, cost_returns = generalized_advantage(
            batch.cost, cost_values, next_cost_values, batch.done
        )
    reward_critic_loss = F.mse_loss(policy.reward_critic(batch.state), reward_returns)
    cost_critic_loss = F.mse_loss(policy.cost_critic(batch.state), cost_returns)
    critic_loss = reward_critic_loss + cost_critic_loss
    critic_optimizer.zero_grad(set_to_none=True)
    critic_loss.backward()
    critic_gradient = max(grad_norm(policy.reward_critic), grad_norm(policy.cost_critic))
    critic_optimizer.step()

    actor = policy.actor
    old_actor = copy.deepcopy(actor).requires_grad_(False)
    actor_parameters = list(actor.parameters())
    flattened_local = batch.local.reshape(-1, batch.local.shape[-1])
    flattened_action = batch.action.reshape(-1, batch.action.shape[-1])
    flattened_raw_action = (
        batch.raw_action.reshape(-1, batch.raw_action.shape[-1])
        if batch.raw_action is not None
        else None
    )

    def actor_log_prob() -> Tensor:
        if flattened_raw_action is not None:
            return actor.log_prob_from_raw(flattened_local, flattened_raw_action, action_scale)
        return actor.log_prob(flattened_local, flattened_action, action_scale)

    new_joint_log_prob = actor_log_prob().reshape(
        batch.local.shape[0], batch.local.shape[1]
    ).sum(dim=1)
    old_joint_log_prob = batch.old_log_prob.sum(dim=1)
    ratio = torch.exp(new_joint_log_prob - old_joint_log_prob)
    normalized_reward_advantage = normalize(reward_advantage)
    normalized_cost_advantage = normalize(cost_advantage)
    reward_loss = -(ratio * normalized_reward_advantage).mean()
    cost_loss = (ratio * normalized_cost_advantage).mean()
    reward_gradient = _flat_grad(reward_loss, actor_parameters, retain_graph=True)
    cost_gradient = _flat_grad(cost_loss, actor_parameters, retain_graph=True)

    def mean_kl() -> Tensor:
        old_distribution = old_actor.distribution(flattened_local)
        new_distribution = actor.distribution(flattened_local)
        old_mean = old_distribution.loc.detach()
        old_std = old_distribution.scale.detach()
        new_mean = new_distribution.loc
        new_std = new_distribution.scale
        kl = torch.log(new_std / old_std) + (
            old_std.square() + (old_mean - new_mean).square()
        ) / (2.0 * new_std.square()) - 0.5
        return kl.sum(dim=-1).mean()

    def fisher_vector_product(vector: Tensor) -> Tensor:
        kl_gradient = _flat_grad(
            mean_kl(), actor_parameters, retain_graph=True, create_graph=True
        )
        kl_vector = torch.dot(kl_gradient, vector)
        hessian_vector = _flat_grad(kl_vector, actor_parameters, retain_graph=True)
        return hessian_vector.detach() + 0.1 * vector

    reward_step = _conjugate_gradient(fisher_vector_product, reward_gradient.detach())
    cost_step = _conjugate_gradient(fisher_vector_product, cost_gradient.detach())
    q_value = max(_finite_float(torch.dot(reward_gradient, reward_step)), 1.0e-8)
    r_value = _finite_float(torch.dot(reward_gradient, cost_step))
    s_value = max(_finite_float(torch.dot(cost_gradient, cost_step)), 1.0e-8)
    constraint = (_finite_float(batch.cost.mean()) - cost_limit) * (1.0 - 0.99)
    cauchy = max(q_value - (r_value * r_value) / s_value, 0.0)
    intersection = 2.0 * max_kl - (constraint * constraint) / s_value
    if constraint < 0.0 and intersection < 0.0:
        optimization_case = 3
    elif constraint < 0.0 and intersection >= 0.0:
        optimization_case = 2
    elif constraint >= 0.0 and intersection >= 0.0:
        optimization_case = 1
    else:
        optimization_case = 0

    if optimization_case in (3,):
        lagrange = math.sqrt(q_value / (2.0 * max_kl))
        multiplier = 0.0
    elif optimization_case in (1, 2):
        lagrange = math.sqrt(max(cauchy / max(intersection, 1.0e-8), 1.0e-8))
        multiplier = max(0.0, lagrange * constraint - r_value) / s_value
    else:
        lagrange = 0.0
        multiplier = math.sqrt(2.0 * max_kl / s_value)
    if optimization_case > 0:
        full_step = (reward_step + multiplier * cost_step) / max(lagrange, 1.0e-8)
    else:
        full_step = multiplier * cost_step

    old_parameters = parameter_vector(actor)
    old_cost_surrogate = _finite_float(cost_loss)
    line_search_accepted = False
    accepted_fraction = 0.0
    final_kl = 0.0
    for fraction in (1.0, 0.5, 0.25, 0.125, 0.0625):
        _set_parameter_vector(actor, old_parameters - fraction * full_step)
        candidate_log_prob = actor_log_prob().reshape(
            batch.local.shape[0], batch.local.shape[1]
        ).sum(dim=1)
        candidate_ratio = torch.exp(candidate_log_prob - old_joint_log_prob)
        candidate_reward_loss = -(candidate_ratio * normalized_reward_advantage).mean()
        candidate_cost_loss = (candidate_ratio * normalized_cost_advantage).mean()
        candidate_kl = _finite_float(mean_kl())
        reward_improved = _finite_float(candidate_reward_loss) <= _finite_float(reward_loss) + 1.0e-6
        cost_allowed = _finite_float(candidate_cost_loss) <= old_cost_surrogate + max(-constraint, 0.0) + 1.0e-6
        if math.isfinite(candidate_kl) and candidate_kl <= max_kl and reward_improved and cost_allowed:
            line_search_accepted = True
            accepted_fraction = fraction
            final_kl = candidate_kl
            break
    if not line_search_accepted:
        _set_parameter_vector(actor, old_parameters)
        final_kl = 0.0

    return {
        "loss": _finite_float(reward_loss + critic_loss),
        "actor_reward_loss": _finite_float(reward_loss),
        "actor_cost_loss": _finite_float(cost_loss),
        "reward_critic_loss": _finite_float(reward_critic_loss),
        "cost_critic_loss": _finite_float(cost_critic_loss),
        "grad_norm": float(
            max(
                _finite_float(torch.linalg.vector_norm(reward_gradient)),
                _finite_float(torch.linalg.vector_norm(cost_gradient)),
                critic_gradient,
            )
        ),
        "parameter_delta_l2": parameter_delta(before_all, policy),
        "actor_parameter_delta_l2": parameter_delta(old_parameters, actor),
        "mean_safety_cost": _finite_float(batch.cost.mean()),
        "cost_limit": cost_limit,
        "constraint_residual": constraint,
        "optimization_case": optimization_case,
        "line_search_accepted": line_search_accepted,
        "accepted_fraction": accepted_fraction,
        "kl_after_update": final_kl,
        "reward_natural_gradient_quadratic": q_value,
        "cost_natural_gradient_quadratic": s_value,
        "optimization_contract": "reward_and_cost_critics_cpo_natural_gradient_line_search",
    }


class MASACActor(nn.Module):
    """Shared actor conditioned on the scalar agent ID, as in ffelten/MASAC."""

    def __init__(self, observation_dim: int, action_dim: int = 3, hidden_dim: int = 256) -> None:
        super().__init__()
        self.body = _mlp(observation_dim + 1, hidden_dim, hidden_dim)
        self.mean = nn.Linear(hidden_dim, action_dim)
        self.log_std = nn.Linear(hidden_dim, action_dim)

    def sample(self, observation_with_id: Tensor, action_scale: float) -> tuple[Tensor, Tensor, Tensor]:
        latent = self.body(observation_with_id)
        mean = self.mean(latent)
        bounded_log_std = torch.tanh(self.log_std(latent))
        log_std = -5.0 + 0.5 * (2.0 - (-5.0)) * (bounded_log_std + 1.0)
        distribution = Normal(mean, log_std.exp())
        raw_action = distribution.rsample()
        action = torch.tanh(raw_action) * action_scale
        log_prob = SquashedGaussianActor._log_prob(distribution, raw_action, action_scale)
        deterministic = torch.tanh(mean) * action_scale
        return action, log_prob, deterministic


class SoftQNetwork(nn.Module):
    def __init__(self, state_dim: int, joint_action_dim: int, hidden_dim: int = 256) -> None:
        super().__init__()
        self.net = _mlp(state_dim + joint_action_dim, hidden_dim, 1)

    def forward(self, state: Tensor, joint_action: Tensor) -> Tensor:
        return self.net(torch.cat([state, joint_action], dim=-1)).squeeze(-1)


class MASACPolicy(nn.Module):
    def __init__(self, observation_dim: int, state_dim: int, n_agents: int = 4, action_dim: int = 3) -> None:
        super().__init__()
        self.n_agents = n_agents
        self.action_dim = action_dim
        self.actor = MASACActor(observation_dim, action_dim)
        joint_action_dim = n_agents * action_dim
        self.q1 = SoftQNetwork(state_dim, joint_action_dim)
        self.q2 = SoftQNetwork(state_dim, joint_action_dim)
        self.target_q1 = copy.deepcopy(self.q1).requires_grad_(False)
        self.target_q2 = copy.deepcopy(self.q2).requires_grad_(False)
        self.log_alpha = nn.Parameter(torch.zeros(()))

    def with_agent_id(self, observation: Tensor) -> Tensor:
        batch_size = observation.shape[0]
        ids = torch.arange(
            self.n_agents, dtype=observation.dtype, device=observation.device
        ).view(1, self.n_agents, 1)
        ids = ids.expand(batch_size, -1, -1)
        return torch.cat([observation, ids], dim=-1)

    def sample(self, observation: Tensor, action_scale: float) -> tuple[Tensor, Tensor]:
        with_id = self.with_agent_id(observation)
        shape = with_id.shape
        action, log_prob, _ = self.actor.sample(with_id.reshape(-1, shape[-1]), action_scale)
        return action.reshape(shape[0], self.n_agents, -1), log_prob.reshape(shape[0], self.n_agents)


def update_masac(
    policy: MASACPolicy,
    batch: RolloutBatch,
    action_scale: float,
    *,
    learning_rate: float = 3.0e-4,
    gamma: float = 0.99,
    tau: float = 0.005,
    actor_optimizer: torch.optim.Optimizer | None = None,
    q_optimizer: torch.optim.Optimizer | None = None,
    alpha_optimizer: torch.optim.Optimizer | None = None,
) -> dict[str, Any]:
    before = parameter_vector(policy)
    if actor_optimizer is None:
        actor_optimizer = torch.optim.Adam(policy.actor.parameters(), lr=learning_rate)
    if q_optimizer is None:
        q_optimizer = torch.optim.Adam(
            list(policy.q1.parameters()) + list(policy.q2.parameters()), lr=1.0e-3
        )
    if alpha_optimizer is None:
        alpha_optimizer = torch.optim.Adam([policy.log_alpha], lr=1.0e-3)
    batch_size = batch.local.shape[0]
    joint_action = batch.action.reshape(batch_size, -1)
    with torch.no_grad():
        next_action, next_log_prob = policy.sample(batch.next_local, action_scale)
        next_joint_action = next_action.reshape(batch_size, -1)
        next_joint_log_prob = next_log_prob.sum(dim=1)
        alpha = policy.log_alpha.exp()
        target_q = torch.minimum(
            policy.target_q1(batch.next_state, next_joint_action),
            policy.target_q2(batch.next_state, next_joint_action),
        ) - alpha * next_joint_log_prob
        bellman_target = batch.reward + gamma * (1.0 - batch.done) * target_q
    q1_value = policy.q1(batch.state, joint_action)
    q2_value = policy.q2(batch.state, joint_action)
    q1_loss = F.mse_loss(q1_value, bellman_target)
    q2_loss = F.mse_loss(q2_value, bellman_target)
    q_loss = q1_loss + q2_loss
    q_optimizer.zero_grad(set_to_none=True)
    q_loss.backward()
    q_gradient = max(grad_norm(policy.q1), grad_norm(policy.q2))
    q_optimizer.step()

    for critic in (policy.q1, policy.q2):
        critic.requires_grad_(False)
    sampled_action, log_prob = policy.sample(batch.local, action_scale)
    sampled_joint_action = sampled_action.reshape(batch_size, -1)
    joint_log_prob = log_prob.sum(dim=1)
    alpha = policy.log_alpha.exp().detach()
    actor_loss = (
        alpha * joint_log_prob
        - torch.minimum(
            policy.q1(batch.state, sampled_joint_action),
            policy.q2(batch.state, sampled_joint_action),
        )
    ).mean()
    actor_optimizer.zero_grad(set_to_none=True)
    actor_loss.backward()
    actor_gradient = grad_norm(policy.actor)
    actor_optimizer.step()
    for critic in (policy.q1, policy.q2):
        critic.requires_grad_(True)

    # The reference implementation uses the per-agent action dimension as its
    # target entropy even though joint log probabilities are summed.
    target_entropy = -float(policy.action_dim)
    alpha_loss = -(
        policy.log_alpha * (joint_log_prob.detach() + target_entropy)
    ).mean()
    alpha_optimizer.zero_grad(set_to_none=True)
    alpha_loss.backward()
    alpha_optimizer.step()

    with torch.no_grad():
        for source, target in zip(policy.q1.parameters(), policy.target_q1.parameters()):
            target.mul_(1.0 - tau).add_(source, alpha=tau)
        for source, target in zip(policy.q2.parameters(), policy.target_q2.parameters()):
            target.mul_(1.0 - tau).add_(source, alpha=tau)

    return {
        "loss": _finite_float(q_loss + actor_loss + alpha_loss),
        "q1_loss": _finite_float(q1_loss),
        "q2_loss": _finite_float(q2_loss),
        "actor_loss": _finite_float(actor_loss),
        "alpha_loss": _finite_float(alpha_loss),
        "alpha": _finite_float(policy.log_alpha.exp()),
        "q1_mean": _finite_float(q1_value.mean()),
        "q2_mean": _finite_float(q2_value.mean()),
        "grad_norm": float(max(q_gradient, actor_gradient)),
        "parameter_delta_l2": parameter_delta(before, policy),
        "optimization_contract": "shared_id_conditioned_actor_twin_q_entropy_soft_targets",
    }


METHOD_SOURCES: dict[str, dict[str, Any]] = {
    "mat": {
        "name": "Multi-Agent Transformer (MAT)",
        "url": "https://github.com/PKU-MARL/Multi-Agent-Transformer",
        "commit": "be3ff49c8264d454c1fe2c41582aa2bfc98498c8",
        "license": "MIT",
        "reference_files": [
            "mat/algorithms/mat/algorithm/ma_transformer.py",
            "mat/algorithms/mat/mat_trainer.py",
        ],
    },
    "happo": {
        "name": "Heterogeneous-Agent PPO (HAPPO)",
        "url": "https://github.com/PKU-MARL/HARL",
        "commit": "b1af98b0dbab72a2eee9d160751cd09aedbb8ce2",
        "license": "MIT",
        "reference_files": ["harl/algorithms/actors/happo.py"],
    },
    "macpo": {
        "name": "Multi-Agent Constrained Policy Optimisation (MACPO)",
        "url": "https://github.com/chauncygu/Multi-Agent-Constrained-Policy-Optimisation",
        "commit": "b80a9f5b4a0049125a827be8fb9c477f69ae021b",
        "license": "MIT",
        "reference_files": [
            "MACPO/macpo/algorithms/r_mappo/r_macpo.py",
            "MACPO/macpo/algorithms/r_mappo/algorithm/r_actor_critic.py",
        ],
    },
    "masac": {
        "name": "Multi-Agent Soft Actor-Critic (MASAC)",
        "url": "https://github.com/ffelten/MASAC",
        "commit": "7936aa9a4ffd40bc7dee68778a038eba69e3e06c",
        "license": "MIT",
        "reference_files": ["masac/masac.py", "masac/ma_buffer.py"],
    },
}
