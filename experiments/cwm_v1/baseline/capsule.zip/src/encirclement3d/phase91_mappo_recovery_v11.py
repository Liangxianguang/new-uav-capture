"""KL-bounded Adam updates with recoverable, explicitly recorded learning rate."""
import copy
import math
import torch
from .phase91_probability_v9 import update_with_kl as diagnostic_update
from .phase91_mappo_stability_v10 import validation_regression


def clip_with_diagnostics(policy, diagnostics, limit=.5):
    """Retain the original global clipping rule and expose its actual effect."""
    norms = {}
    for group in ['actor', 'critic']:
        grads = [p.grad for n,p in policy.named_parameters()
                 if p.grad is not None and n.startswith('critic') == (group == 'critic')]
        norms[group] = float(torch.stack([g.detach().square().sum() for g in grads]).sum().sqrt()) if grads else 0.
    total = float(torch.nn.utils.clip_grad_norm_(policy.parameters(), limit))
    if diagnostics is not None:
        scale = min(1., limit/(total+1e-6))
        diagnostics.update(gradient_norm_actor=norms['actor'], gradient_norm_critic=norms['critic'],
                           gradient_norm_global=total, gradient_clip_scale=scale,
                           gradient_norm_actor_clipped=norms['actor']*scale,
                           gradient_norm_critic_clipped=norms['critic']*scale)
    return total


def initialize_recovery(optimizer, *, ceiling=5e-5, bootstrap=1e-6):
    if not 0 < bootstrap <= ceiling:
        raise ValueError('Recovery LR must be positive and <= ceiling')
    for group in optimizer.param_groups:
        # Restarting V11 resumes its controller; only V10 migration bootstraps.
        if 'recovery_lr_ceiling' not in group:
            group['lr'] = min(ceiling, max(group['lr'], bootstrap))
        group['recovery_lr_ceiling'] = ceiling


def parameter_change(policy, weights):
    result = {}
    for group in ['actor', 'critic']:
        selected = [(n,p) for n,p in policy.named_parameters() if n.startswith('critic') == (group == 'critic')]
        delta = torch.stack([(p.detach()-weights[n]).double().square().sum() for n,p in selected]).sum().sqrt()
        norm = torch.stack([weights[n].double().square().sum() for n,p in selected]).sum().sqrt()
        result['parameter_delta_'+group] = float(delta)
        result['parameter_relative_delta_'+group] = float(delta/norm.clamp_min(1e-12))
    return result


def guarded_update(update_fn, policy, optimizer, batch, algorithm, action_scale,
                   epochs, minibatch, clip_range, recurrent=False, entropy_coef=.01,
                   diagnostics=None, *, joint_mean_limit=.02, joint_max_limit=1., attempts=8):
    """Backtrack on this batch; recover from small accepted steps on later batches.

    Rejected candidates restore weights, Adam moments and rollout RNG. All-rejected
    batches restore their original LR as well. Accepted LR is logged separately
    from the next rollout's LR. Low-KL accepted updates grow the next LR by 2,
    bounded by the launch ceiling. No performance gate is relaxed.
    """
    if algorithm != 'mappo' or not recurrent or attempts < 1:
        raise ValueError('V11 requires recurrent MAPPO and positive attempts')
    if joint_mean_limit <= 0 or joint_max_limit <= 0:
        raise ValueError('Invalid KL limits')
    diagnostics = {} if diagnostics is None else diagnostics
    weights = copy.deepcopy(policy.state_dict())
    moments = copy.deepcopy(optimizer.state_dict())
    cpu_rng = torch.get_rng_state()
    cuda_rng = torch.cuda.get_rng_state_all() if next(policy.parameters()).is_cuda else None
    original_lrs = [g['lr'] for g in optimizer.param_groups]
    if any(not math.isfinite(lr) or lr <= 0 for lr in original_lrs):
        raise ValueError('Invalid optimizer LR')

    def restore():
        policy.load_state_dict(weights)
        optimizer.load_state_dict(moments)
        optimizer.zero_grad(set_to_none=True)
        torch.set_rng_state(cpu_rng)
        if cuda_rng is not None:
            torch.cuda.set_rng_state_all(cuda_rng)

    rejected = []
    for attempt in range(attempts):
        restore()
        scale = .5 ** attempt
        for group,lr in zip(optimizer.param_groups,original_lrs):
            group['lr'] = lr*scale
        current = {}
        try:
            loss = diagnostic_update(update_fn, policy, optimizer, batch, algorithm,
                                     action_scale, epochs, minibatch, clip_range,
                                     recurrent=recurrent, entropy_coef=entropy_coef, diagnostics=current)
        except Exception:
            restore()
            raise
        finite = math.isfinite(loss) and all(torch.isfinite(x).all().item()
                 for x in policy.state_dict().values() if x.is_floating_point())
        finite = finite and all(torch.isfinite(x).all().item()
                 for s in optimizer.state.values() for x in s.values()
                 if isinstance(x,torch.Tensor) and x.is_floating_point())
        accepted = finite and current['post_update_kl_joint_mean'] <= joint_mean_limit and current['post_update_kl_joint_max'] <= joint_max_limit
        if accepted:
            used_lr = optimizer.param_groups[0]['lr']
            recover = current['post_update_kl_joint_mean'] < .1*joint_mean_limit and current['post_update_kl_joint_max'] < .25*joint_max_limit
            for group in optimizer.param_groups:
                group['lr'] = min(group.get('recovery_lr_ceiling',5e-5), group['lr']*(2. if recover else 1.))
            diagnostics.update(current, **parameter_change(policy,weights))
            diagnostics.update(update_accepted=1.,update_rejected_attempts=float(attempt),update_lr_scale=scale,
                               update_lr_start=original_lrs[0], update_lr_used=used_lr,
                               update_lr_next=optimizer.param_groups[0]['lr'], learning_rate_recovered=float(recover),
                               rejected_kl_joint_mean=max((x[0] for x in rejected),default=0.),
                               rejected_kl_joint_max=max((x[1] for x in rejected),default=0.))
            return loss
        rejected.append((current['post_update_kl_joint_mean'],current['post_update_kl_joint_max']))
    restore()
    diagnostics.update(current, **parameter_change(policy,weights))
    for key in list(diagnostics):
        if key.startswith('post_update_'):
            diagnostics[key] = 0.
    diagnostics.update(update_accepted=0.,update_rejected_attempts=float(attempts),update_lr_scale=0.,
                       update_lr_start=original_lrs[0], update_lr_used=0., update_lr_next=original_lrs[0],
                       learning_rate_recovered=0., rejected_kl_joint_mean=max(x[0] for x in rejected),
                       rejected_kl_joint_max=max(x[1] for x in rejected))
    return 0.
