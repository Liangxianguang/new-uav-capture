"""Learnable directional avoidance context and bounded approach-risk rewards.

Does not project, filter, or alter actions. Original collision/termination rules
and sampled-action likelihoods remain in force.
"""
import copy
import numpy as np
import torch
from .ippo_risk_role_v9 import RepairEnv as OriginalIPPOEnv, policy_observations as original_ippo_observations
from .pursuit_env import CaptureRadiusPursuit3DEnv
from .observation_encoding import policy_observations as original_mappo_observations
from .pursuit_first_policy import PursuitFirstActorCritic
from .phase91_mappo_recovery_v11 import guarded_update as original_guard, initialize_recovery, clip_with_diagnostics
from .phase91_probability_v9 import update_with_kl as ippo_update

EXTRA_DIM=12

def directional_context(env, observation=None, velocities=None):
    obs=env.observe() if observation is None else observation
    positions=np.asarray(obs['defender_positions'],dtype=float)
    velocities=np.asarray(obs['defender_velocities'] if velocities is None else velocities,dtype=float)
    maximum=float(env.agents['defender_max_speed']);radius=float(env.agents['drone_radius'])
    erosion=radius+float(env.pursuit['defender_boundary_margin'])
    features=[];costs=[];hazards=[]
    settings=env.task.get('directional_avoidance',{})
    horizon=float(settings.get('warning_seconds',1.0));obstacle_weight=float(settings.get('obstacle_weight',1.0));boundary_weight=float(settings.get('boundary_weight',1.0))
    for position,velocity in zip(positions,velocities):
        obstacle_candidates=[env._cylinder_clearance_and_normal(position,o) for o in env.obstacles]
        obstacle_clearance,obstacle_normal=min(obstacle_candidates,key=lambda x:x[0]) if obstacle_candidates else (3.,np.zeros(3))
        obstacle_clearance-=radius if obstacle_candidates else 0.
        face_clearances=np.concatenate([position-env.lower-erosion,env.upper-erosion-position])
        face=int(np.argmin(face_clearances));boundary_clearance=float(face_clearances[face]);boundary_normal=np.zeros(3);boundary_normal[face%3]=1. if face<3 else -1.
        row=[];penalties=[];danger=False
        for clearance,normal,weight in [(obstacle_clearance,obstacle_normal,obstacle_weight),(boundary_clearance,boundary_normal,boundary_weight)]:
            closing=-float(velocity@normal)
            # Penalize continuing toward danger. Tangential/retreating motion costs zero.
            urgency=float(np.clip(1.-max(clearance,0.)/max(max(closing,0.)*horizon,.1),0.,1.))
            approach=float(np.clip(closing/maximum,0.,1.))
            row.extend([*normal.tolist(),float(np.clip(clearance/3.,-1.,1.)),float(np.clip(closing/maximum,-1.,1.)),urgency])
            penalties.append(-weight*urgency*approach)
            danger=danger or (clearance<1. and closing>0.)
        features.append(row);costs.append(penalties);hazards.append(danger)
    return np.asarray(features,dtype=np.float32),np.asarray(costs),np.asarray(hazards,dtype=bool)

def ippo_observations(env,observation=None,*,route_helper=None):
    return np.concatenate([original_ippo_observations(env,observation,route_helper=route_helper),directional_context(env,observation)[0]],axis=1)

def mappo_observations(env,observation=None,*,route_helper=None):
    return np.concatenate([original_mappo_observations(env,observation,route_helper=route_helper),directional_context(env,observation)[0]],axis=1)

class DirectionalReward:
    def step(self,actions,*args,**kwargs):
        command=self._clip_rows(np.asarray(actions,dtype=float),float(self.agents['defender_max_speed']))
        _,costs,hazards=directional_context(self,self.observe(),command)
        obs,reward,terminated,truncated,info=super().step(actions,*args,**kwargs)
        extra=costs.sum(axis=1)
        info['agent_rewards']=(np.asarray(info.get('agent_rewards',[reward]*4))+extra).tolist()
        info['reward_components'].update(directional_obstacle=float(costs[:,0].mean()),directional_boundary=float(costs[:,1].mean()))
        speed=np.linalg.norm(self.last_executed_actions,axis=1)/float(self.agents['defender_max_speed'])
        info['avoidance_metrics']={'executed_speed_fraction':float(speed.mean()),'executed_speed_cap_fraction':float((speed>.9998).mean()),'hazard_fraction':float(hazards.mean()),'hazard_speed_sum_fraction':float((speed*hazards).mean()),'command_norm_clipped_fraction':float((np.linalg.norm(np.asarray(actions),axis=1)>float(self.agents['defender_max_speed'])+1e-5).mean())}
        return obs,float(reward+extra.mean()),terminated,truncated,info

class IPPODirectionalEnv(DirectionalReward,OriginalIPPOEnv):pass
class MAPPODirectionalEnv(DirectionalReward,CaptureRadiusPursuit3DEnv):pass

class DirectionalPursuitActorCritic(PursuitFirstActorCritic):
    architecture='pursuit_first_directional_risk_v12'
    def configure(self,environment,settings):
        super().configure(environment,settings)
        self.original_team_clearance_index=self.local_observation_dim-EXTRA_DIM-1
        self.mask_original_team_clearance=self.has_team_clearance
        # Appended risk context moves the old nearest-teammate clearance away from -1.
        self.has_team_clearance=False
    def _actor_step(self,local,hidden):
        main=local.clone()
        if self.mask_original_team_clearance:main[:,self.original_team_clearance_index]=0
        return super()._actor_step(main,hidden)

def migrate_checkpoint(checkpoint,policy,config_sha256):
    """Zero-extend only observation input weights and corresponding Adam moments."""
    c=copy.deepcopy(checkpoint);old_dim=int(c['local_observation_dim']);new_dim=int(policy.local_observation_dim)
    if new_dim!=old_dim+EXTRA_DIM:raise ValueError('Unexpected directional observation dimensions')
    template=policy.state_dict();expanded={}
    for name,value in c['state_dict'].items():
        target=template[name]
        if value.shape==target.shape:expanded[name]=value
        elif value.ndim==2 and value.shape[1]==old_dim and target.shape==(value.shape[0],new_dim):
            expanded[name]=torch.cat([value,torch.zeros((value.shape[0],EXTRA_DIM),dtype=value.dtype)],dim=1)
        else:raise ValueError('Unsupported migration shape '+name)
    if set(expanded)!=set(template):raise ValueError('Migration parameter names differ')
    opt=c['optimizer_state_dict'];ids=[i for g in opt['param_groups'] for i in g['params']];named=list(policy.named_parameters())
    if len(ids)!=len(named):raise ValueError('Adam parameter count differs')
    for ident,(name,parameter) in zip(ids,named):
        for key,value in opt['state'].get(ident,{}).items():
            if isinstance(value,torch.Tensor) and value.ndim==2 and value.shape!=parameter.shape:
                if value.shape==checkpoint['state_dict'][name].shape and name in expanded:
                    opt['state'][ident][key]=torch.cat([value,torch.zeros((value.shape[0],EXTRA_DIM),dtype=value.dtype)],dim=1)
                else:raise ValueError('Unsupported Adam migration '+name)
    c['state_dict']=expanded;c['local_observation_dim']=new_dim;c['config_sha256']=config_sha256
    c['policy_architecture']=getattr(policy,'architecture','ippo_directional_risk_v10')
    for key in ['consecutive_gate_passes','consecutive_validation_passes']:c['curriculum_state'][key]=0
    c['curriculum_state']['recent']=[]
    policy.load_state_dict(expanded,strict=True)
    return c
