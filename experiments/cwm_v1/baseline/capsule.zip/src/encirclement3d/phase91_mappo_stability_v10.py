"""Isolated MAPPO update protection; V9 and historical policies stay intact."""
import copy
import math
import torch
from .phase91_probability_v9 import update_with_kl as diagnostic_update
from .pursuit_first_policy import PursuitFirstActorCritic


def validation_regression(previous, current, *, margin=.15):
    """Compare only fresh fixed windows at the same curriculum stage."""
    stage = current.get('active_curriculum_level')
    if stage is None:
        return None
    same = [x for x in previous if x.get('active_curriculum_level') == stage
            and x.get('updates', -1) < current.get('updates', 0)]
    if not same:
        return None
    reference = max(same, key=lambda x: x['safe_capture_rate'])
    capture_drop = reference['safe_capture_rate'] - current['safe_capture_rate']
    safety_growth = (current['collision_rate'] + current['boundary_violation_rate']
                     - reference['collision_rate'] - reference['boundary_violation_rate'])
    if capture_drop > margin or safety_growth > margin:
        return {'reference_update': reference['updates'],
                'reference_stage': stage, 'capture_drop': capture_drop,
                'collision_boundary_sum_growth': safety_growth, 'margin': margin}
    return None


class StablePursuitFirstActorCritic(PursuitFirstActorCritic):
    """Bound the teammate residual in Gaussian space before the common tanh.

    Unlike action-space addition followed by clamp/atanh, this has no inverse
    singularity. Weight loading is compatible; executed behavior changes and
    must be evaluated before adopting this architecture.
    """
    architecture = "pursuit_first_latent_team_v10"

    def _actor_step(self, local, hidden):
        main = local.clone()
        main[:, self.team_start:self.team_start + 18] = 0
        if self.has_team_clearance:
            main[:, -1] = 0
        next_hidden = self.actor_gru(self.actor_gru_encoder(main), hidden)
        mean = self.actor_base_mean(self.actor_base_body(main)) + self.actor_residual_mean(next_hidden)
        team = local[:, self.team_start:self.team_start + 18]
        position = team[:, :9].reshape(-1, 3, 3) * self.extent
        velocity = team[:, 9:].reshape(-1, 3, 3) * self.speed
        closest_time = (-(position * velocity).sum(-1) /
                        velocity.square().sum(-1).clamp_min(1e-6)).clamp(0, self.lookahead)
        distance = (position + closest_time[..., None] * velocity).norm(dim=-1)
        gate = ((self.warning_distance - distance) /
                (self.warning_distance - 2 * self.drone_radius)).clamp(0, 1).amax(-1, keepdim=True)
        correction = torch.tanh(self.team_correction(team))
        correction = correction / correction.norm(dim=-1, keepdim=True).clamp_min(1)
        # A scalar shift d changes tanh by at most 2*tanh(abs(d)/2).
        # This budget bounds each normalized action correction by fraction.
        budget = 2 * math.atanh(self.correction_fraction / 2)
        return mean + budget * gate * correction, next_hidden


def guarded_update(update_fn, policy, optimizer, batch, algorithm, action_scale,
                   epochs, minibatch, clip_range, recurrent=False, entropy_coef=.01,
                   diagnostics=None, *, joint_mean_limit=.02, joint_max_limit=1.,
                   attempts=4):
    """Accept only a finite bounded update, restoring Adam as well as weights.

    Each retry starts from identical weights, optimizer moments and random
    ordering. A failed attempt halves the learning rate. Exhausting retries
    skips this update; no rejected policy is used by the next rollout.
    Thresholds are engineering limits, not a validated performance guarantee.
    """
    if algorithm != 'mappo' or not recurrent:
        raise ValueError('V10 guard requires recurrent MAPPO')
    if joint_mean_limit <= 0 or joint_max_limit <= 0 or attempts < 1:
        raise ValueError('Invalid update protection settings')
    diagnostics = {} if diagnostics is None else diagnostics
    weights = copy.deepcopy(policy.state_dict())
    moments = copy.deepcopy(optimizer.state_dict())
    cpu_rng = torch.get_rng_state()
    cuda_rng = torch.cuda.get_rng_state_all() if next(policy.parameters()).is_cuda else None
    original_lrs = [group['lr'] for group in optimizer.param_groups]
    rejected = []
    for attempt in range(attempts):
        policy.load_state_dict(weights)
        optimizer.load_state_dict(moments)
        torch.set_rng_state(cpu_rng)
        if cuda_rng is not None:
            torch.cuda.set_rng_state_all(cuda_rng)
        for group, lr in zip(optimizer.param_groups, original_lrs):
            group['lr'] = lr * .5 ** attempt
        current = {}
        try:
            loss = diagnostic_update(update_fn, policy, optimizer, batch, algorithm,
                                     action_scale, epochs, minibatch, clip_range,
                                     recurrent=recurrent, entropy_coef=entropy_coef,
                                     diagnostics=current)
        except Exception:
            # Never leave partially changed parameters/moments on any error.
            policy.load_state_dict(weights)
            optimizer.load_state_dict(moments)
            optimizer.zero_grad(set_to_none=True)
            raise
        finite = math.isfinite(loss) and all(torch.isfinite(x).all().item()
                   for x in policy.state_dict().values() if x.is_floating_point())
        finite = finite and all(torch.isfinite(x).all().item()
                   for state in optimizer.state.values() for x in state.values()
                   if isinstance(x, torch.Tensor) and x.is_floating_point())
        accepted = (finite and current['post_update_kl_joint_mean'] <= joint_mean_limit
                    and current['post_update_kl_joint_max'] <= joint_max_limit)
        if accepted:
            diagnostics.update(current)
            diagnostics.update(update_accepted=1., update_rejected_attempts=float(attempt),
                               update_lr_scale=.5 ** attempt)
            diagnostics['rejected_kl_joint_mean'] = max((x[0] for x in rejected), default=0.)
            diagnostics['rejected_kl_joint_max'] = max((x[1] for x in rejected), default=0.)
            return loss
        rejected.append((current['post_update_kl_joint_mean'], current['post_update_kl_joint_max']))
    policy.load_state_dict(weights)
    optimizer.load_state_dict(moments)
    optimizer.zero_grad(set_to_none=True)
    for group, lr in zip(optimizer.param_groups, original_lrs):
        group['lr'] = lr * .5 ** attempts
    diagnostics.update(current)
    diagnostics['rejected_kl_joint_mean'] = max(x[0] for x in rejected)
    diagnostics['rejected_kl_joint_max'] = max(x[1] for x in rejected)
    # Post-update describes the restored policy, not the rejected candidate.
    for key in list(diagnostics):
        if key.startswith('post_update_'):
            diagnostics[key] = 0.
    diagnostics.update(update_accepted=0., update_rejected_attempts=float(attempts),
                       update_lr_scale=.5 ** attempts)
    return 0.
