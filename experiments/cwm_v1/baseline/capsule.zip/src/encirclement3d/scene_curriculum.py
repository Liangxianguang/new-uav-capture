"""Shared scene-level curriculum for the Phase90 RL comparisons."""

from __future__ import annotations

from collections import deque
from collections.abc import Sequence
from typing import Any

import numpy as np


def _capture_feasible_certified(record: dict[str, Any]) -> bool:
    certificate = record.get("capture_feasibility_certificate")
    return bool(
        record.get("capture_feasible_certified", False)
        or (
            isinstance(certificate, dict)
            and certificate.get("capture_feasible") is True
            and certificate.get("certificate_status") == "passed"
        )
    )


class InterceptionCurriculumSampler:
    """Unlock harder scene variants on competence and replay certified failures.

    The curriculum changes which frozen records are sampled. It never alters a
    scene record or its environment parameters. Failed scenes enter the replay
    pool only when an independent capture-feasibility certificate is present.
    """

    def __init__(
        self,
        records: Sequence[dict[str, Any]],
        curriculum: dict[str, Any],
        *,
        seed: int,
    ) -> None:
        stage_entries = curriculum.get("variants_by_level", [])
        if not stage_entries:
            raise ValueError("Curriculum must define variants_by_level.")
        self.variant_level: dict[str, int] = {}
        for level, entry in enumerate(stage_entries):
            variants = entry.get("variants", [])
            if not variants:
                raise ValueError(f"Curriculum level {level} has no scene variants.")
            for variant in variants:
                name = str(variant)
                if name in self.variant_level:
                    raise ValueError(f"Scene variant {name!r} appears in multiple levels.")
                self.variant_level[name] = level
        self.indices_by_level: list[list[int]] = [
            [] for _ in stage_entries
        ]
        self.record_index_by_episode: dict[int, int] = {}
        self.capture_feasible_indices: set[int] = set()
        for index, record in enumerate(records):
            variant = str(record.get("variant", ""))
            if variant not in self.variant_level:
                raise ValueError(
                    f"Training scene variant {variant!r} is not in the curriculum."
                )
            self.indices_by_level[self.variant_level[variant]].append(index)
            if "episode_index" in record:
                self.record_index_by_episode[int(record["episode_index"])] = index
            if _capture_feasible_certified(record):
                self.capture_feasible_indices.add(index)
        empty = [level for level, items in enumerate(self.indices_by_level) if not items]
        if empty:
            raise ValueError(f"Training scene split is missing curriculum levels: {empty}.")

        gates = curriculum.get("unlock_gate", {})
        self.window_size = int(gates.get("rolling_episodes", 100))
        self.gate_source = str(gates.get("source", "training_episodes"))
        if self.gate_source not in {"training_episodes", "fixed_stage_validation"}:
            raise ValueError(f"Unsupported curriculum gate source: {self.gate_source}")
        self.advancement_mode = str(curriculum.get("advancement_mode", "progress_and_gate"))
        if self.advancement_mode not in {"progress_and_gate", "gate_only"}:
            raise ValueError(f"Unsupported curriculum advancement mode: {self.advancement_mode}")
        self.required_consecutive_gate_windows = max(
            1, int(gates.get("required_consecutive_windows", 1))
        )
        self.minimum_capture = float(gates.get("minimum_safe_capture_rate", 0.70))
        self.maximum_collision = float(gates.get("maximum_collision_rate", 0.10))
        self.maximum_boundary = float(gates.get("maximum_boundary_violation_rate", 0.05))
        self.maximum_target_boundary = float(gates.get("maximum_target_boundary_violation_rate", 1.0))
        self.maximum_target_obstacle = float(gates.get("maximum_target_obstacle_violation_rate", 1.0))
        self.maximum_target_invalid = float(gates.get("maximum_target_invalid_rate", 1.0))
        self.recent: deque[tuple[float, float, float, float]] = deque(maxlen=self.window_size)
        self.consecutive_gate_passes = 0
        self.consecutive_validation_passes = 0
        self.failure_counts: dict[int, int] = {}
        self.stage = 0
        self.rng = np.random.default_rng(seed)
        self.current_fraction = float(curriculum.get("uniform_current_level_fraction", 0.50))
        self.previous_fraction = float(curriculum.get("retain_previous_levels_fraction", 0.25))

        self.hard_fraction = float(curriculum.get("hard_case_replay_fraction", 0.25))
        if min(self.current_fraction, self.previous_fraction, self.hard_fraction) < 0:
            raise ValueError("Curriculum sampling fractions must be non-negative.")
        if not np.isclose(self.current_fraction + self.previous_fraction + self.hard_fraction, 1.0):
            raise ValueError("Curriculum sampling fractions must sum to one.")
        self.hard_replay_requires_certificate = bool(
            curriculum.get("hard_case_replay_requires", "")
            == "independent_capture_feasibility_certificate"
        )

    def gate_thresholds(self) -> dict[str, float]:
        return {
            "minimum_safe_capture_rate": self.minimum_capture,
            "maximum_collision_rate": self.maximum_collision,
            "maximum_boundary_violation_rate": self.maximum_boundary,
            "maximum_target_boundary_violation_rate": self.maximum_target_boundary,
            "maximum_target_obstacle_violation_rate": self.maximum_target_obstacle,
            "maximum_target_invalid_rate": self.maximum_target_invalid,
        }

    @property
    def active_level(self) -> int:
        return self.stage

    def _gate_passed(self) -> bool:
        count = (
            self.consecutive_validation_passes
            if self.gate_source == "fixed_stage_validation"
            else self.consecutive_gate_passes
        )
        return count >= self.required_consecutive_gate_windows

    def _finish_gate_window(self) -> None:
        values = np.asarray(self.recent, dtype=np.float64)
        passed = bool(
            values[:, 0].mean() >= self.minimum_capture
            and values[:, 1].mean() <= self.maximum_collision
            and values[:, 2].mean() <= self.maximum_boundary
            and values[:, 3].mean() <= self.maximum_target_invalid
        )
        self.consecutive_gate_passes = self.consecutive_gate_passes + 1 if passed else 0
        self.recent.clear()

    def _advance(self, progress: float) -> None:
        scheduled_level = (
            len(self.indices_by_level) - 1
            if self.advancement_mode == "gate_only"
            else min(
                len(self.indices_by_level) - 1,
                int(np.clip(progress, 0.0, 0.999999) * len(self.indices_by_level)),
            )
        )
        if self.stage < scheduled_level and self._gate_passed():
            self.stage += 1
            self.consecutive_gate_passes = 0
            self.consecutive_validation_passes = 0
            self.recent.clear()

    def sample_indices(self, count: int, *, progress: float) -> list[int]:
        if count <= 0:
            raise ValueError("Sample count must be positive.")
        self._advance(progress)
        current = self.indices_by_level[self.stage]
        previous = [
            index
            for level in range(self.stage)
            for index in self.indices_by_level[level]
        ]
        hard = [
            index
            for index, failures in self.failure_counts.items()
            if failures > 0 and index in self.capture_feasible_indices
        ]
        if not self.hard_replay_requires_certificate and not self.capture_feasible_indices:
            hard = [index for index, failures in self.failure_counts.items() if failures > 0]

        current_fraction = self.current_fraction
        previous_fraction = self.previous_fraction if previous else 0.0
        hard_fraction = self.hard_fraction if hard else 0.0
        remainder = 1.0 - previous_fraction - hard_fraction
        if current:
            current_fraction = remainder
        elif previous:
            previous_fraction += remainder
        else:
            raise RuntimeError("No eligible scenes are available at the active level.")
        fractions = np.asarray([current_fraction, previous_fraction, hard_fraction])
        fractions /= fractions.sum()
        pools = [current, previous, hard]
        selected: list[int] = []
        for _ in range(count):
            available = [position for position, pool in enumerate(pools) if pool]
            probabilities = fractions[available]
            probabilities = probabilities / probabilities.sum()
            bucket = available[int(self.rng.choice(len(available), p=probabilities))]
            pool = pools[bucket]
            if bucket == 2:
                weights = np.asarray([self.failure_counts.get(index, 1) for index in pool], dtype=np.float64)
                weights /= weights.sum()
                selected.append(int(self.rng.choice(pool, p=weights)))
            else:
                selected.append(int(self.rng.choice(pool)))
        return selected

    def observe(
        self,
        records: Sequence[dict[str, Any]],
        outcomes: Sequence[dict[str, Any]],
    ) -> None:
        for record, outcome in zip(records, outcomes):
            captured = float(bool(outcome.get("safe_capture", outcome.get("safe_capture_success", False))))
            collision = float(
                bool(
                    outcome.get(
                        "defender_physical_collision",
                        outcome.get("collision", outcome.get("defender_safety_failure", False)),
                    )
                )
            )
            boundary = float(
                bool(
                    outcome.get(
                        "defender_boundary_violation",
                        outcome.get("boundary_violation", False),
                    )
                )
            )
            target_invalid = float(bool(outcome.get("target_invalid_episode", outcome.get("target_invalid", False))))
            variant = str(record.get("variant", ""))
            if (
                self.gate_source == "training_episodes"
                and self.variant_level.get(variant) == self.stage
            ):
                self.recent.append((captured, collision, boundary, target_invalid))
                if len(self.recent) >= self.window_size:
                    self._finish_gate_window()
            index = self.record_index_by_episode.get(int(record.get("episode_index", -1)))
            if index is None or (self.hard_replay_requires_certificate and index not in self.capture_feasible_indices):
                continue
            if captured:
                self.failure_counts.pop(index, None)
            else:
                self.failure_counts[index] = min(100, self.failure_counts.get(index, 0) + 1)

    def observe_validation(self, by_variant: dict[str, dict[str, Any]]) -> dict[str, Any]:
        """Apply one fixed validation check to the active curriculum level."""
        if self.gate_source != "fixed_stage_validation":
            raise RuntimeError("observe_validation requires gate_source='fixed_stage_validation'.")
        variants = [name for name, level in self.variant_level.items() if level == self.stage]
        rows = [by_variant[name] for name in variants if name in by_variant]
        required_metrics = {
            "safe_capture_rate",
            "collision_rate",
            "boundary_violation_rate",
            "target_boundary_violation_rate",
            "target_obstacle_violation_rate",
            "target_invalid_episode_rate",
        }
        if (
            len(rows) != len(variants)
            or any(int(row.get("episodes", 0)) <= 0 for row in rows)
            or any(not required_metrics.issubset(row) for row in rows)
        ):
            self.consecutive_validation_passes = 0
            return {
                "active_level": self.stage,
                "variants": variants,
                "complete": False,
                "passed": False,
                "safe_capture_rate": 0.0,
                "collision_rate": 0.0,
                "boundary_violation_rate": 0.0,
                "target_boundary_violation_rate": 0.0,
                "target_obstacle_violation_rate": 0.0,
                "target_invalid_episode_rate": 1.0,
                "validation_metrics_complete": False,
                "gate_thresholds": self.gate_thresholds(),
                "consecutive_passes": 0,
                "required_consecutive_passes": self.required_consecutive_gate_windows,
            }
        episode_count = sum(int(row["episodes"]) for row in rows)

        def weighted_rate(*keys: str) -> float:
            return float(
                sum(
                    float(next((row[key] for key in keys if key in row), 0.0))
                    * int(row["episodes"])
                    for row in rows
                )
                / max(episode_count, 1)
            )

        safe_capture = weighted_rate("safe_capture_rate")
        collision = weighted_rate("collision_rate")
        boundary = weighted_rate("boundary_violation_rate")
        target_boundary = weighted_rate("target_boundary_violation_rate")
        target_obstacle = weighted_rate("target_obstacle_violation_rate")
        target_invalid = weighted_rate(
            "target_invalid_episode_rate",
            "target_invalid_rate",
        )
        passed = bool(
            safe_capture >= self.minimum_capture
            and collision <= self.maximum_collision
            and boundary <= self.maximum_boundary
            and target_boundary <= self.maximum_target_boundary
            and target_obstacle <= self.maximum_target_obstacle
            and target_invalid <= self.maximum_target_invalid
        )
        self.consecutive_validation_passes = (
            self.consecutive_validation_passes + 1 if passed else 0
        )
        return {
            "active_level": self.stage,
            "variants": variants,
            "episodes": episode_count,
            "safe_capture_rate": safe_capture,
            "collision_rate": collision,
            "boundary_violation_rate": boundary,
            "target_boundary_violation_rate": target_boundary,
            "target_obstacle_violation_rate": target_obstacle,
            "target_invalid_episode_rate": target_invalid,
            "validation_metrics_complete": True,
            "gate_thresholds": self.gate_thresholds(),
            "passed": passed,
            "consecutive_passes": self.consecutive_validation_passes,
            "required_consecutive_passes": self.required_consecutive_gate_windows,
            "ready_to_unlock": self._gate_passed(),
        }

    def state_dict(self) -> dict[str, Any]:
        return {
            "stage": self.stage,
            "recent": list(self.recent),
            "failure_counts": self.failure_counts,
            "rng_state": self.rng.bit_generator.state,
            "window_size": self.window_size,
            "consecutive_gate_passes": self.consecutive_gate_passes,
            "required_consecutive_gate_windows": self.required_consecutive_gate_windows,
            "consecutive_validation_passes": self.consecutive_validation_passes,
            "gate_source": self.gate_source,
            "advancement_mode": self.advancement_mode,
            "gate_thresholds": self.gate_thresholds(),
        }

    def load_state_dict(
        self,
        state: dict[str, Any],
        *,
        allow_gate_threshold_override: bool = False,
    ) -> None:
        if int(state.get("window_size", -1)) != self.window_size:
            raise ValueError("Curriculum outcome window differs from the checkpoint.")
        if int(
            state.get("required_consecutive_gate_windows", self.required_consecutive_gate_windows)
        ) != self.required_consecutive_gate_windows:
            raise ValueError("Curriculum consecutive-gate setting differs from the checkpoint.")
        if str(state.get("gate_source", self.gate_source)) != self.gate_source:
            raise ValueError("Curriculum gate source differs from the checkpoint.")
        saved_mode = state.get("advancement_mode")
        if saved_mode is not None and str(saved_mode) != self.advancement_mode:
            raise ValueError("Curriculum advancement mode differs from the checkpoint.")
        saved_thresholds = state.get("gate_thresholds")
        thresholds_changed = False
        if isinstance(saved_thresholds, dict):
            current_thresholds = self.gate_thresholds()
            thresholds_changed = any(
                key not in saved_thresholds
                or not np.isclose(float(saved_thresholds[key]), value)
                for key, value in current_thresholds.items()
            ) or any(key not in current_thresholds for key in saved_thresholds)
            if thresholds_changed and not allow_gate_threshold_override:
                raise ValueError("Curriculum gate thresholds differ from the checkpoint.")
        elif allow_gate_threshold_override:
            # Older checkpoints did not store the complete gate contract. Reset
            # the streak so progress earned under that unrecorded contract is
            # never credited to an explicitly overridden gate.
            thresholds_changed = True
        else:
            saved_target_invalid = state.get("maximum_target_invalid_rate")
            if saved_target_invalid is not None and not np.isclose(
                float(saved_target_invalid), self.maximum_target_invalid
            ):
                raise ValueError("Curriculum target-invalid gate differs from the checkpoint.")
        stage = int(state["stage"])
        if not 0 <= stage < len(self.indices_by_level):
            raise ValueError("Checkpoint curriculum stage is outside configured levels.")
        self.stage = stage
        self.recent.clear()
        self.recent.extend(
            tuple(map(float, row))
            if len(row) == 4
            else (*tuple(map(float, row)), 0.0)
            for row in state["recent"]
        )
        self.consecutive_gate_passes = (
            0 if thresholds_changed else int(state.get("consecutive_gate_passes", 0))
        )
        self.consecutive_validation_passes = (
            0
            if thresholds_changed
            else int(state.get("consecutive_validation_passes", 0))
        )
        self.failure_counts = {
            int(index): int(count) for index, count in state["failure_counts"].items()
        }
        self.rng.bit_generator.state = state["rng_state"]
